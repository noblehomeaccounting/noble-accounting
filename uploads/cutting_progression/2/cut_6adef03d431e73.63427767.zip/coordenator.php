<?php
// coordenator.php  —  Project Coordinator (Operations) workspace
// Pumapasok ang proyekto dito pagkatapos ng transmittal. Bawat tab = isang bahagi ng Operations flow.

include ROOT_PATH . '/network/connect.php';
include ROOT_PATH . '/admin/authentication/index-authguard.php';
include ROOT_PATH . '/admin/authentication/index-roles.php';

$allowedRoles = [ROLE_PC];
include ROOT_PATH . '/admin/authentication/index-roleguard.php';

$pcAjaxUrl = BASE_URL . '/coordenatorajax';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PC Dashboard</title>
    <?php include ROOT_PATH . '/link/top.php'; ?>
    <?php include ROOT_PATH . '/admin/navigation/sidebar.php'; ?>
    <?php include __DIR__ . '/coordenator/pc-style.php'; ?>
</head>

<body class="bg-slate-100">
    <main id="main-content" class="md:ml-56 pt-20 md:pt-5 min-h-screen p-4 md:p-8 transition-all duration-300">

        <!-- ===================== HEADER ===================== -->
        <div class="flex flex-wrap items-end justify-between gap-3 mb-5">
            <div>
                <p class="text-amber-700 text-[10px] font-semibold tracking-[0.15em] uppercase mb-0.5">Operations · Project Coordinator</p>
                <h1 class="text-gray-900 text-xl font-semibold">Project Coordination</h1>
                <p class="text-gray-400 text-xs mt-0.5">Projects arrive here once their transmittal is delivered. Plan the timeline and track each step until turnover.</p>
            </div>
            <div class="grid grid-cols-3 gap-2">
                <div class="bg-white border border-gray-200 rounded-xl px-4 py-2.5 min-w-[96px]"><p class="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Ongoing</p><p id="pcStatOngoing" class="text-lg font-bold text-gray-900 tabular-nums">—</p></div>
                <div class="bg-white border border-gray-200 rounded-xl px-4 py-2.5 min-w-[96px]"><p class="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Delayed</p><p id="pcStatDelayed" class="text-lg font-bold text-red-600 tabular-nums">—</p></div>
                <div class="bg-white border border-gray-200 rounded-xl px-4 py-2.5 min-w-[96px]"><p class="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Turnover</p><p id="pcStatTurnover" class="text-lg font-bold text-green-600 tabular-nums">—</p></div>
            </div>
        </div>

        <div class="grid grid-cols-1 xl:grid-cols-[300px_minmax(0,1fr)] gap-4 items-start">

            <!-- ===================== PROJECT LIST ===================== -->
            <aside class="bg-white border border-gray-200 rounded-xl overflow-hidden xl:sticky xl:top-5">
                <div class="p-3 border-b border-gray-100 space-y-2">
                    <div class="relative">
                        <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-300 text-[11px]"></i>
                        <input type="text" id="pcSearch" placeholder="Search client, BOM, location…"
                            class="w-full border border-gray-200 rounded-lg pl-8 pr-3 py-2 text-xs outline-none focus:border-amber-600">
                    </div>
                    <div id="pcStatusFilter" class="flex gap-1 bg-gray-50 border border-gray-200 rounded-lg p-1"></div>
                </div>
                <ul id="pcList" class="max-h-[calc(100vh-260px)] overflow-y-auto divide-y divide-gray-100">
                    <li class="px-4 py-10 text-center text-xs text-gray-400"><i class="fa-solid fa-spinner fa-spin mr-1"></i> Loading…</li>
                </ul>
            </aside>

            <!-- ===================== WORKSPACE ===================== -->
            <section id="pcWorkspace" class="min-w-0">
                <div class="bg-white border border-gray-200 rounded-xl px-6 py-16 text-center">
                    <i class="fa-solid fa-helmet-safety text-3xl text-gray-300 mb-3"></i>
                    <p class="text-sm font-semibold text-gray-700">Select a project</p>
                    <p class="text-xs text-gray-400 mt-1">Choose a project on the left to open its workspace.</p>
                </div>
            </section>
        </div>

        <div id="crmToastContainer" class="fixed bottom-4 right-4 z-[10000] flex flex-col gap-2.5 pointer-events-none w-[340px] max-w-[calc(100vw-2rem)]"></div>
    </main>

    <?php include __DIR__ . '/coordenator/pc-modals.php'; ?>

    <?php
    // ── JS: core muna, tapos ang Overview at bawat hakbang (sunod sa F. Operations 1–8) ──
    $pcParts = [
        'pc-core.php',           // state, api, helpers, listahan, workspace, form modal, print
        'pc-steps.php',          // step rail, "What to do", Complete Step
        'overview.php',
        'step1-delivery.php',
        'step2-permits.php',
        'step3-workers.php',
        'step4-client.php',
        'step5-timeline.php',
        'step6-billing.php',
        'step7-punch.php',
        'step8-turnover.php',
    ];
    foreach ($pcParts as $part) include __DIR__ . '/coordenator/' . $part;
    ?>
    <script>window.NHPC.start();</script>
</body>

</html>
