-- ============================================================
--  Project Coordinator (coordenator.php) — lahat ng table
-- ============================================================

CREATE TABLE IF NOT EXISTS noblepc_project (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bom_id INT NOT NULL,
  client_name VARCHAR(255) NULL,
  location VARCHAR(255) NULL,
  scope VARCHAR(255) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Ongoing',
  notes TEXT NULL,
  checklist TEXT NULL,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  UNIQUE KEY uq_pc_bom (bom_id)
);

CREATE TABLE IF NOT EXISTS noblepc_timeline (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  category VARCHAR(150) NOT NULL,
  name VARCHAR(200) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  actual_start DATE NULL,
  actual_end DATE NULL,
  progress TINYINT NOT NULL DEFAULT 0,
  remarks VARCHAR(500) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  KEY idx_pc_tl_project (project_id)
);

-- 1. Delivery Receipt
CREATE TABLE IF NOT EXISTS noblepc_delivery (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  dr_no VARCHAR(30) NOT NULL,
  dr_date DATE NOT NULL,
  client_name VARCHAR(255) NOT NULL,
  address VARCHAR(255) NULL,
  scheduled_date DATE NULL,
  vehicle VARCHAR(150) NULL,
  notes TEXT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Scheduled',
  delivered_at DATE NULL,
  received_by VARCHAR(150) NULL,
  prepared_by VARCHAR(150) NULL,
  created_by INT NULL,
  created_at DATETIME NOT NULL,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  UNIQUE KEY uq_pc_dr_no (dr_no),
  KEY idx_pc_dr_project (project_id)
);

CREATE TABLE IF NOT EXISTS noblepc_delivery_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  delivery_id INT NOT NULL,
  item_no INT NOT NULL,
  particular VARCHAR(255) NOT NULL,
  size VARCHAR(100) NULL,
  qty DECIMAL(12,2) NOT NULL DEFAULT 0,
  unit VARCHAR(30) NULL,
  amount DECIMAL(14,2) NOT NULL DEFAULT 0,
  KEY idx_pc_dri_delivery (delivery_id)
);

-- 2. Permits
CREATE TABLE IF NOT EXISTS noblepc_permit (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  permit_type VARCHAR(150) NOT NULL,
  authority VARCHAR(150) NULL,
  date_needed DATE NULL,
  submitted_at DATE NULL,
  approved_at DATE NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Needed',
  ref_no VARCHAR(100) NULL,
  remarks VARCHAR(500) NULL,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  KEY idx_pc_permit_project (project_id)
);

-- 3. Workers / Subcontractors + attendance
CREATE TABLE IF NOT EXISTS noblepc_worker (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  name VARCHAR(150) NOT NULL,
  kind VARCHAR(20) NOT NULL DEFAULT 'Worker',
  role VARCHAR(100) NULL,
  contact VARCHAR(50) NULL,
  scope VARCHAR(255) NULL,
  start_date DATE NULL,
  end_date DATE NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active',
  remarks VARCHAR(500) NULL,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  KEY idx_pc_worker_project (project_id)
);

CREATE TABLE IF NOT EXISTS noblepc_attendance (
  project_id INT NOT NULL,
  worker_id INT NOT NULL,
  work_date DATE NOT NULL,
  present TINYINT(1) NOT NULL DEFAULT 1,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  PRIMARY KEY (worker_id, work_date),
  KEY idx_pc_att_project (project_id, work_date)
);

-- 4. Client contact log
CREATE TABLE IF NOT EXISTS noblepc_clientlog (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  log_date DATE NOT NULL,
  type VARCHAR(30) NOT NULL DEFAULT 'Update',
  subject VARCHAR(200) NOT NULL,
  details TEXT NULL,
  contact_person VARCHAR(150) NULL,
  needs_approval TINYINT(1) NOT NULL DEFAULT 0,
  approved_at DATE NULL,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  KEY idx_pc_log_project (project_id)
);

-- 5. Subcontractor quotation (Labor Only)
CREATE TABLE IF NOT EXISTS noblepc_subcon_quote (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  subcontractor VARCHAR(150) NOT NULL,
  subject VARCHAR(255) NULL,
  quote_date DATE NOT NULL,
  duration_days INT NOT NULL DEFAULT 0,
  downpayment_pct DECIMAL(5,2) NOT NULL DEFAULT 30,
  terms TEXT NULL,
  created_by INT NULL,
  created_at DATETIME NOT NULL,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  KEY idx_pc_sq_project (project_id)
);

CREATE TABLE IF NOT EXISTS noblepc_subcon_quote_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  quote_id INT NOT NULL,
  section VARCHAR(150) NULL,
  item_name VARCHAR(255) NOT NULL,
  qty DECIMAL(12,2) NOT NULL DEFAULT 0,
  unit VARCHAR(30) NULL,
  unit_cost DECIMAL(14,2) NOT NULL DEFAULT 0,
  amount DECIMAL(14,2) NOT NULL DEFAULT 0,
  sort_order INT NOT NULL DEFAULT 0,
  KEY idx_pc_sqi_quote (quote_id)
);

-- 6. Progress billing (Application for Payment)
CREATE TABLE IF NOT EXISTS noblepc_billing (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  quote_id INT NOT NULL,
  app_no VARCHAR(60) NOT NULL,
  billing_date DATE NOT NULL,
  period VARCHAR(100) NULL,
  description VARCHAR(255) NOT NULL,
  amount DECIMAL(14,2) NOT NULL DEFAULT 0,
  change_orders DECIMAL(14,2) NOT NULL DEFAULT 0,
  retainage_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
  remarks VARCHAR(500) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Draft',
  submitted_at DATETIME NULL,
  paid_at DATETIME NULL,
  prepared_by VARCHAR(150) NULL,
  created_by INT NULL,
  created_at DATETIME NOT NULL,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  UNIQUE KEY uq_pc_app_no (app_no),
  KEY idx_pc_bill_project (project_id, quote_id)
);

-- 7. Punch list
CREATE TABLE IF NOT EXISTS noblepc_punch (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  area VARCHAR(150) NULL,
  description VARCHAR(500) NOT NULL,
  responsible VARCHAR(150) NULL,
  target_date DATE NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Open',
  remarks VARCHAR(500) NULL,
  fixed_at DATETIME NULL,
  verified_at DATETIME NULL,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  KEY idx_pc_punch_project (project_id)
);

-- 8. Turnover
CREATE TABLE IF NOT EXISTS noblepc_turnover (
  project_id INT NOT NULL PRIMARY KEY,
  turnover_date DATE NOT NULL,
  project_name VARCHAR(255) NULL,
  location VARCHAR(255) NULL,
  contractor VARCHAR(255) NULL,
  owner_name VARCHAR(150) NULL,
  owner_title VARCHAR(100) NULL,
  signatory_name VARCHAR(150) NULL,
  signatory_title VARCHAR(100) NULL,
  documents TEXT NULL,
  items TEXT NULL,
  turned_over_at DATE NULL,
  completed_by INT NULL,
  updated_by INT NULL,
  updated_at DATETIME NULL
);

-- 9. Estado ng bawat hakbang ng Operations (1 Delivery … 8 Turnover)
CREATE TABLE IF NOT EXISTS noblepc_step (
  project_id INT NOT NULL,
  step_key VARCHAR(20) NOT NULL,
  status VARCHAR(10) NULL,            -- NULL = bukas pa, 'done' = tapos, 'na' = not required
  duties TEXT NULL,                   -- JSON ng mga na-tick na tungkulin
  completed_at DATETIME NULL,
  completed_by INT NULL,
  updated_by INT NULL,
  updated_at DATETIME NULL,
  PRIMARY KEY (project_id, step_key)
);
