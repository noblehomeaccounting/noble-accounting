<?php
// coordenator/step2-permits.php — STEP 2: Permit Processing (if required)
// Kasama sa coordenator.php (huwag buksan nang direkta).
defined('ROOT_PATH') || exit;
?>
<script>
    (function (PC) {
        'use strict';
        const { esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL, money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn, openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals, openProject, loadList, renderWorkspace, go } = PC;

        // ── Kahulugan ng hakbang (galing sa F. Operations) ──
        PC.defineStep({ key: 'permits', n: 2, label: 'Permit Processing', icon: 'fa-id-card', optional: true,
            role: 'Secure the permits required by the client or building administration (if required).',
            link: 'Permit approval affects site access, delivery, and installation schedules.',
            duties: [
                ['Identify permits required by the client or building administration', () => PC.current.permits.length > 0],
                ['Prepare and submit necessary documents', () => PC.current.permits.length > 0 && PC.current.permits.every(x => x.status !== 'Needed')],
                ['Coordinate work permits, delivery permits, access passes, and other approvals'],
                ['Confirm approvals before activities that require permits', () => PC.current.permits.length > 0 && PC.current.permits.every(x => x.status === 'Approved')],
            ],
            render: renderPermits,
            badge: () => PC.current.permits.filter(x => x.status !== 'Approved').length,
        });

        // ═════════════════════════════════════════════════════════
        //  STEP 2 · PERMIT PROCESSING
        // ═════════════════════════════════════════════════════════
        const PERMIT_COLOR = { Needed: PILL.gray, Submitted: PILL.amber, Approved: PILL.green, Rejected: PILL.red };
        const PERMIT_FIELDS = [
            { name: 'permit_type', label: 'Permit', req: 1, list: 'pcPermitList', ph: 'e.g. Work permit' },
            { name: 'authority', label: 'Issued by', ph: 'e.g. Building admin' },
            { name: 'status', label: 'Status', type: 'select', options: ['Needed', 'Submitted', 'Approved', 'Rejected'] },
            { name: 'date_needed', label: 'Needed by', type: 'date' },
            { name: 'submitted_at', label: 'Date submitted', type: 'date' },
            { name: 'approved_at', label: 'Date approved', type: 'date' },
            { name: 'ref_no', label: 'Reference / Permit No.' },
            { name: 'remarks', label: 'Remarks', full: 1, max: 500 },
        ];
        function renderPermits() {
            const list = PC.current.permits;
            const body = document.getElementById('pcTabBody');
            const count = s => list.filter(x => x.status === s).length;
            body.innerHTML = sectionHead('Permits', 'Work permits, delivery permits, gate/access passes — confirm approval before the activity.', addBtn('pcAddPermit', 'Add Permit'))
                + `<div class="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">${['Needed', 'Submitted', 'Approved', 'Rejected'].map(s => `<div class="rounded-lg border border-gray-200 px-3 py-2"><p class="text-[10px] font-semibold uppercase tracking-wider text-gray-400">${s}</p><p class="text-lg font-bold text-gray-900">${count(s)}</p></div>`).join('')}</div>`
                + (list.length ? `<div class="rounded-lg border border-gray-200 overflow-hidden"><table class="w-full text-xs table-fixed"><thead class="bg-gray-50 text-[10px] uppercase tracking-wider text-gray-500"><tr>
                    <th class="px-3 py-2 text-left w-[40%] md:w-[26%]">Permit</th><th class="px-3 py-2 text-left">Needed by</th><th class="hidden md:table-cell px-3 py-2 text-left">Submitted</th><th class="hidden md:table-cell px-3 py-2 text-left">Approved</th><th class="px-3 py-2 text-left w-[28%] md:w-[14%]">Status</th><th class="w-10"></th></tr></thead>
                    <tbody class="divide-y divide-gray-100">${list.map(r => {
                        const late = r.status !== 'Approved' && r.date_needed && r.date_needed < todayISO();
                        return `<tr class="${late ? 'bg-red-50/50' : ''}"><td class="px-3 py-2.5"><p class="font-semibold text-gray-800 truncate">${esc(r.permit_type)}</p><p class="text-[10.5px] text-gray-400 truncate">${esc(r.authority || '')}${r.ref_no ? ' · ' + esc(r.ref_no) : ''}</p></td>
                            <td class="px-3 py-2.5 ${late ? 'text-red-600 font-semibold' : 'text-gray-600'}">${r.date_needed ? fmtY(r.date_needed) : '—'}${late ? ' <i class="fa-solid fa-triangle-exclamation"></i>' : ''}</td>
                            <td class="hidden md:table-cell px-3 py-2.5 text-gray-600">${r.submitted_at ? fmtY(r.submitted_at) : '—'}</td><td class="hidden md:table-cell px-3 py-2.5 text-gray-600">${r.approved_at ? fmtY(r.approved_at) : '—'}</td>
                            <td class="px-3 py-2.5">${pill(r.status.toUpperCase(), PERMIT_COLOR[r.status])}</td><td class="px-2 text-right">${iconBtn(`data-permit="${r.id}"`, 'fa-pen', 'Edit')}</td></tr>`;
                    }).join('')}</tbody></table></div>` : emptyBox('fa-id-card', 'No permits recorded', 'Add the permits required by the client or building administration.'))
                + `<datalist id="pcPermitList"><option>Work permit<option>Delivery permit<option>Gate pass / Access pass<option>Hot works permit<option>Renovation permit<option>Parking / Loading bay permit</datalist>`;
            F('pcAddPermit').addEventListener('click', () => entityForm('permit', 'Permit', PERMIT_FIELDS, null, { validate: permitCheck }));
            body.querySelectorAll('[data-permit]').forEach(b => b.addEventListener('click', () => entityForm('permit', 'Permit', PERMIT_FIELDS, list.find(x => x.id == b.dataset.permit), { validate: permitCheck })));
        }
        function permitCheck(d) {
            if (d.status === 'Approved' && !d.approved_at) d.approved_at = todayISO();
            if (['Submitted', 'Approved'].includes(d.status) && !d.submitted_at) d.submitted_at = d.approved_at || todayISO();
            if (d.approved_at && d.submitted_at && d.approved_at < d.submitted_at) return 'Date approved cannot be earlier than date submitted.';
            return '';
        }

    })(window.NHPC);
</script>
