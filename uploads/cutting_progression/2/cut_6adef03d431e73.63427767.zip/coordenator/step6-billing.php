<?php
// coordenator/step6-billing.php — STEP 6: Progress Billing (Application for Payment + print)
// Kasama sa coordenator.php (huwag buksan nang direkta).
defined('ROOT_PATH') || exit;
?>
<script>
    (function (PC) {
        'use strict';
        const { esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL, money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn, openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals, openProject, loadList, renderWorkspace, go } = PC;

        // ── Kahulugan ng hakbang (galing sa F. Operations) ──
        PC.defineStep({ key: 'billing', n: 6, label: 'Progress Billing', icon: 'fa-file-invoice-dollar',
            role: 'Document the accomplishment and submit progress billing.',
            link: 'Operations documents project accomplishment. Accounting or Finance reviews and processes billing according to company procedures and contract terms.',
            duties: [
                ['Monitor completed work against the contract and agreed billing milestones', () => PC.current.quotes.length > 0 && PC.current.billings.length > 0],
                ['Collect progress reports, accomplishment records, delivery receipts, or other supporting documents'],
                ['Verify the percentage of work completed with the responsible team'],
                ['Prepare and submit progress billing documents to the authorized department or client', () => PC.current.billings.some(b => b.status !== 'Draft')],
                ['Follow up on billing clarifications, approvals, and payment status', () => PC.current.billings.length > 0 && PC.current.billings.every(b => b.status === 'Paid')],
            ],
            render: renderBilling,
            badge: () => PC.current.billings.filter(b => b.status === 'Submitted').length,
        });

        // ═════════════════════════════════════════════════════════
        //  STEP 6 · PROGRESS BILLING
        // ═════════════════════════════════════════════════════════
        const SIGN = { notedBy: 'MARY GRACE RIVERA', notedTitle: 'NOTED BY: ACCOUNTING HEAD', approvedBy: 'MR. KEN YANG', approvedTitle: 'APPROVED BY' };
        let billQuote = null;
        // kompyutasyon ng AFP para sa isang billing (lahat ng naunang billing ng parehong quotation)
        function afp(q, bill) {
            const bills = PC.current.billings.filter(b => b.quote_id == q.id);
            const upto = bills.filter(b => +b.id <= +bill.id);
            const prev = upto.filter(b => +b.id < +bill.id);
            const sum = (arr, f) => arr.reduce((a, b) => a + num(b[f]), 0);
            const contract = q.total, co = sum(upto, 'change_orders'), contractSum = contract + co;
            const completed = sum(upto, 'amount');
            const retPct = num(bill.retainage_pct);
            const retAmt = Math.round(completed * retPct) / 100;
            const earned = completed - retAmt;
            const prevCert = prev.reduce((a, b) => a + num(b.amount) - num(b.amount) * num(b.retainage_pct) / 100, 0);
            return { bills, upto, contract, co, contractSum, completed, retPct, retAmt, earned, prevCert, due: earned - prevCert, balance: contractSum - completed };
        }
        function renderBilling() {
            const quotes = PC.current.quotes;
            const body = document.getElementById('pcTabBody');
            if (!quotes.length) {
                body.innerHTML = sectionHead('Progress Billing', 'Application for Payment per subcontractor.') + emptyBox('fa-file-invoice-dollar', 'No subcontractor quotation yet', 'Add the labor quotation in Workers / Subcon first — its total becomes the contract amount.');
                return;
            }
            if (!billQuote || !quotes.some(q => q.id == billQuote)) billQuote = quotes[0].id;
            const q = quotes.find(x => x.id == billQuote);
            const bills = PC.current.billings.filter(b => b.quote_id == q.id);
            const last = bills[bills.length - 1];
            const s = last ? afp(q, last) : { contract: q.total, co: 0, contractSum: q.total, completed: 0, retAmt: 0, earned: 0, prevCert: 0, due: 0, balance: q.total };
            const pctDone = s.contractSum ? Math.min(100, s.completed / s.contractSum * 100) : 0;
            const ST = { Draft: PILL.gray, Submitted: PILL.amber, Paid: PILL.green };
            const stat = (l, v, cls = 'text-gray-900') => `<div class="rounded-lg border border-gray-200 px-3 py-2.5"><p class="text-[10px] font-semibold uppercase tracking-wider text-gray-400">${l}</p><p class="text-base font-bold tabular-nums ${cls}">${v}</p></div>`;

            body.innerHTML = sectionHead('Progress Billing', 'Application for Payment — schedule of values, previous vs current billing.', addBtn('pcAddBill', 'New Billing'))
                + (quotes.length > 1 ? `<div class="flex flex-wrap gap-1 mb-4">${quotes.map(x => `<button type="button" data-bq="${x.id}" class="px-3 py-1.5 rounded-lg text-xs font-semibold ${x.id == q.id ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}">${esc(x.subcontractor)}</button>`).join('')}</div>` : '')
                + `<div class="grid grid-cols-2 lg:grid-cols-5 gap-2 mb-2">
                    ${stat('Contract Sum', '₱ ' + money(s.contractSum))}${stat('Total Billed', '₱ ' + money(s.completed))}${stat('Retainage', '₱ ' + money(s.retAmt))}
                    ${stat('Balance to Finish', '₱ ' + money(s.balance), 'text-amber-700')}${stat('% Complete', pctDone.toFixed(1) + '%', 'text-green-600')}
                </div>
                <div class="h-2 rounded-full bg-gray-100 overflow-hidden mb-5"><div class="h-full bg-green-500" style="width:${pctDone}%"></div></div>
                ${bills.length ? `<div class="rounded-lg border border-gray-200 overflow-hidden"><table class="w-full text-xs table-fixed"><thead class="bg-gray-50 text-[10px] uppercase tracking-wider text-gray-500"><tr>
                    <th class="px-3 py-2 text-left w-[34%]">Application</th><th class="hidden md:table-cell px-3 py-2 text-right">Previous</th><th class="px-3 py-2 text-right">This Period</th><th class="hidden md:table-cell px-3 py-2 text-right">To Date</th><th class="hidden sm:table-cell px-3 py-2 text-left w-[12%]">Status</th><th class="w-[96px] md:w-[132px]"></th></tr></thead>
                    <tbody class="divide-y divide-gray-100">${bills.map(b => {
                        const a = afp(q, b);
                        const next = b.status === 'Draft' ? ['Submitted', 'Submit', 'fa-paper-plane', 'bg-amber-700 hover:bg-amber-800'] : b.status === 'Submitted' ? ['Paid', 'Paid', 'fa-check', 'bg-green-600 hover:bg-green-700'] : null;
                        return `<tr><td class="px-3 py-2.5"><p class="font-semibold text-gray-800 truncate" title="${esc(b.description)}">${esc(b.description)}</p><p class="font-mono text-[10px] text-gray-500 truncate" title="${esc(b.app_no)}">${esc(b.app_no)}</p><p class="text-[10.5px] text-gray-400">${fmtY(b.billing_date)}${b.period ? ' · ' + esc(b.period) : ''}</p></td>
                            <td class="hidden md:table-cell px-3 py-2.5 text-right tabular-nums text-gray-500">${money(a.completed - num(b.amount))}</td>
                            <td class="px-3 py-2.5 text-right tabular-nums font-semibold text-gray-900">${money(b.amount)}</td>
                            <td class="hidden md:table-cell px-3 py-2.5 text-right tabular-nums text-gray-700">${money(a.completed)}</td>
                            <td class="hidden sm:table-cell px-3 py-2.5">${pill(b.status.toUpperCase(), ST[b.status])}</td>
                            <td class="px-2 py-2 text-right"><div class="flex flex-wrap justify-end items-center gap-0.5">${iconBtn(`data-bill-print="${b.id}"`, 'fa-print', 'View / Print AFP')}${b.status === 'Draft' ? iconBtn(`data-bill-edit="${b.id}"`, 'fa-pen', 'Edit') : ''}
                                ${next ? `<button type="button" data-bill-next="${b.id}" data-to="${next[0]}" class="ml-1 inline-flex items-center gap-1 px-2 py-1 text-[10.5px] font-semibold text-white rounded-md ${next[3]}"><i class="fa-solid ${next[2]} text-[9px]"></i>${next[1]}</button>` : ''}</div></td></tr>`;
                    }).join('')}</tbody></table></div>` : emptyBox('fa-file-invoice-dollar', 'No billing yet', 'Start with the down payment, then add each Application for Payment.')}`;

            body.querySelectorAll('[data-bq]').forEach(b => b.addEventListener('click', () => { billQuote = +b.dataset.bq; renderBilling(); }));
            F('pcAddBill').addEventListener('click', () => billForm(q, null));
            body.querySelectorAll('[data-bill-edit]').forEach(b => b.addEventListener('click', () => billForm(q, bills.find(x => x.id == b.dataset.billEdit))));
            body.querySelectorAll('[data-bill-print]').forEach(b => b.addEventListener('click', () => { const bill = bills.find(x => x.id == b.dataset.billPrint); previewDoc(`Application for Payment — ${bill.app_no}`, afpDoc(q, bill)); }));
            body.querySelectorAll('[data-bill-next]').forEach(b => b.addEventListener('click', () => {
                const bill = bills.find(x => x.id == b.dataset.billNext), to = b.dataset.to;
                openForm({
                    title: to === 'Paid' ? `Mark ${bill.app_no} as paid?` : `Submit ${bill.app_no}?`, saveLabel: to === 'Paid' ? 'Yes, paid' : 'Submit',
                    body: `<p class="text-xs text-gray-600">${to === 'Paid' ? 'Confirm that Accounting has released the payment for this application.' : 'Once submitted to Accounting / Finance, this billing can no longer be edited.'}</p>
                        <p class="mt-3 rounded-lg bg-gray-50 border border-gray-200 px-3 py-2 text-xs">Amount this period: <b>₱ ${money(bill.amount)}</b></p>`,
                    onSave: async () => { await must(await post('billing_status', { billing_id: bill.id, status: to })); toast(to === 'Paid' ? 'Marked as paid.' : 'Billing submitted.'); await reload(); },
                });
            }));
        }
        function billForm(q, b) {
            const bills = PC.current.billings.filter(x => x.quote_id == q.id);
            const billed = bills.filter(x => !b || x.id != b.id).reduce((a, x) => a + num(x.amount), 0);
            const firstDesc = bills.length ? `APPLICATION FOR PAYMENT ${bills.length}` : 'DOWN PAYMENT';
            const suggested = bills.length ? '' : (q.total * num(q.downpayment_pct) / 100).toFixed(2);
            openForm({
                title: b ? `Edit ${b.app_no}` : `New Billing — ${q.subcontractor}`, saveLabel: 'Save Billing',
                body: `<div class="rounded-lg bg-gray-50 border border-gray-200 px-3 py-2 mb-3 text-[11px] text-gray-600">Contract: <b>₱ ${money(q.total)}</b> · Already billed: <b>₱ ${money(billed)}</b> · Remaining: <b>₱ ${money(q.total - billed)}</b></div>`
                    + fieldsHtml([
                        { name: 'billing_date', label: 'Billing date', type: 'date', req: 1 },
                        { name: 'period', label: 'Billing period', ph: 'e.g. Oct 1–15, 2026' },
                        { name: 'description', label: 'Description of work', req: 1, full: 1 },
                        { name: 'amount', label: 'Amount this period (₱)', type: 'number', req: 1 },
                        { name: 'retainage_pct', label: 'Retainage %', type: 'number' },
                        { name: 'change_orders', label: 'Change orders (₱, + / −)', type: 'number' },
                        { name: 'remarks', label: 'Remarks', max: 500 },
                    ], b || { billing_date: todayISO(), description: firstDesc, amount: suggested, retainage_pct: 0, change_orders: 0 }),
                onSave: async err => {
                    const d = { billing_id: b ? b.id : 0, quote_id: q.id };
                    ['billing_date', 'period', 'description', 'amount', 'retainage_pct', 'change_orders', 'remarks'].forEach(k => d[k] = fv(k));
                    if (!d.description) return err('Description of work is required.'), false;
                    if (num(d.amount) <= 0) return err('Amount this period must be more than zero.'), false;
                    await must(await post('save_billing', d));
                    toast('Billing saved.');
                    await reload();
                },
                onDelete: b ? async () => { await must(await post('delete_billing', { billing_id: b.id })); toast('Billing deleted.'); await reload(); } : null,
            });
        }
        function afpDoc(q, bill) {
            const p = P(), a = afp(q, bill);
            const sov = a.upto.map((b, k) => {
                const before = a.upto.slice(0, k).reduce((x, y) => x + num(y.amount), 0);
                const toDate = before + num(b.amount);
                const cur = b.id == bill.id;
                return `<tr class="${cur ? 'cur' : ''}"><td class="c">${k + 1}</td><td>${esc(b.description)}</td><td class="r">${k === 0 ? money(a.contractSum) : ''}</td><td class="r">${money(before)}</td><td class="r">${money(b.amount)}</td><td class="c">${fmtSlash(b.billing_date)}</td><td class="r b">${money(toDate)}</td><td class="c">${a.contractSum ? (toDate / a.contractSum * 100).toFixed(1) : '0.0'}%</td><td class="r">${money(a.contractSum - toDate)}</td><td class="r">${money(toDate * num(b.retainage_pct) / 100)}</td></tr>`;
            }).join('');
            const line = (n, t, v, cls = '') => `<tr class="${cls}"><td>${n}. ${t}</td><td class="r">${money(v)}</td></tr>`;
            return `<div class="pcdoc pcafp">
                <table class="nb hd"><tr><td style="width:90px"><img src="${LOGO}" alt="" style="width:80px"></td><td>
                    <div class="co">NOBLEHOME CONSTRUCTION CORPORATION</div>
                    <div class="addr">1181 MC Premiere, Brgy. Balingasa, EDSA Balintawak Quezon City | Tel: (02) 8822-1295 | Email: noblehomeconst.ph@gmail.com</div>
                    <div class="ttl">PROGRESS BILLING / APPLICATION FOR PAYMENT</div></td></tr></table>
                <div class="bar">PROJECT INFORMATION</div>
                <table class="kv"><tr><td class="k">Project Name:</td><td>${esc(p.scope || p.client_name)}</td><td class="k">Application No.:</td><td>${esc(bill.app_no)}</td></tr>
                    <tr><td class="k">Project Location:</td><td>${esc(p.location || '')}</td><td class="k">Billing Period:</td><td>${esc(bill.period || '')}</td></tr>
                    <tr><td class="k">Owner/Client:</td><td>${esc(p.client_name)}</td><td class="k">Contract Date:</td><td>${esc(fmtLong(q.quote_date))}</td></tr>
                    <tr><td class="k">Subcontractor:</td><td>${esc(q.subcontractor)}</td><td class="k">Billing Date:</td><td>${esc(fmtLong(bill.billing_date))}</td></tr></table>
                <div class="bar">CONTRACT SUMMARY</div>
                <table class="sum">
                    ${line(1, 'Original Contract Amount', a.contract)}${line(2, 'Net Change by Approved Change Orders', a.co)}${line(3, 'Contract Sum to Date (Line 1 + Line 2)', a.contractSum, 'b')}
                    ${line(4, 'Total Completed &amp; Stored to Date', a.completed)}<tr><td>5a. Retainage Rate (%)</td><td class="r">${a.retPct.toFixed(2)}</td></tr>${line('5b', 'Retainage Amount (Line 4 × Line 5a)', a.retAmt)}
                    ${line(6, 'Total Earned Less Retainage (Line 4 − Line 5b)', a.earned)}${line(7, 'Less Previous Certificates for Payment', a.prevCert)}
                    ${line(8, 'CURRENT PAYMENT DUE (Line 6 − Line 7)', a.due, 'due')}${line(9, 'Balance to Finish, Including Retainage (Line 3 − Line 6)', a.contractSum - a.earned)}
                </table>
                <div class="bar">SCHEDULE OF VALUES — PREVIOUS BILLING vs. CURRENT BILLING</div>
                <table class="sov"><colgroup><col style="width:4%"><col style="width:22%"><col span="8" style="width:9.25%"></colgroup><tr class="th"><td>No.</td><td>Description of Work</td><td>Schedule of Values (A)</td><td>Previous Billed (B)</td><td>This Period (C)</td><td>Date</td><td>Total to Date (B+C=D)</td><td>% Complete (D/A)</td><td>Balance to Finish (A−D)</td><td>Retainage</td></tr>${sov}</table>
                <div class="bar">CONTRACTOR'S CERTIFICATION</div>
                <p class="cert">The undersigned Contractor certifies that, to the best of its knowledge, the work covered by this Application for Payment has been completed in accordance with the Contract Documents, that all amounts have been paid for work for which previous Certificates for Payment were issued, and that the current payment shown herein is now due.</p>
                <table class="sg"><tr><td><div class="nm">${esc((bill.prepared_by || '').toUpperCase())}</div><div class="t">PREPARED BY: PROJECT COORDINATOR</div></td>
                    <td><div class="nm">${SIGN.notedBy}</div><div class="t">${SIGN.notedTitle}</div></td>
                    <td><div class="nm">${SIGN.approvedBy}</div><div class="t">${SIGN.approvedTitle}</div></td></tr></table>
            </div>`;
        }

    })(window.NHPC);
</script>
