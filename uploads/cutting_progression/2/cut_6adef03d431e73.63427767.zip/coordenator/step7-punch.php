<?php
// coordenator/step7-punch.php — STEP 7: Punch List / Quality Check
// Kasama sa coordenator.php (huwag buksan nang direkta).
defined('ROOT_PATH') || exit;
?>
<script>
    (function (PC) {
        'use strict';
        const { esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL, money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn, openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals, openProject, loadList, renderWorkspace, go } = PC;

        // ── Kahulugan ng hakbang (galing sa F. Operations) ──
        PC.defineStep({ key: 'punch', n: 7, label: 'Punch List / Quality Check', icon: 'fa-list-check',
            role: 'Inspect the completed work and correct deficiencies before acceptance.',
            link: 'Quality checking confirms that work meets required standards and identifies items to correct before final acceptance.',
            duties: [
                ['Inspect completed work against approved drawings and specifications'],
                ['Identify incomplete work, defects, or installation issues'],
                ['Prepare a punch list showing deficiencies, responsible persons, and target correction dates', () => PC.current.punch.length > 0 && PC.current.punch.every(x => x.responsible && x.target_date)],
                ['Coordinate corrective work with subcontractors, workers, or the responsible department'],
                ['Reinspect corrected items and record completion', () => PC.current.punch.length > 0 && PC.current.punch.every(x => x.status === 'Verified')],
                ['Arrange client inspection or acceptance, as applicable'],
            ],
            render: renderPunch,
            badge: () => PC.current.punch.filter(x => x.status !== 'Verified').length,
        });

        // ═════════════════════════════════════════════════════════
        //  STEP 7 · PUNCH LIST / QUALITY CHECK
        // ═════════════════════════════════════════════════════════
        const PUNCH_FIELDS = [
            { name: 'area', label: 'Area / Location', ph: 'e.g. Bedroom closet' },
            { name: 'responsible', label: 'Responsible', list: 'pcRespList', ph: 'Worker / subcon / dept.' },
            { name: 'description', label: 'Deficiency / item to correct', req: 1, full: 1, max: 500 },
            { name: 'target_date', label: 'Target correction date', type: 'date' },
            { name: 'status', label: 'Status', type: 'select', options: ['Open', 'Fixed', 'Verified'] },
            { name: 'remarks', label: 'Remarks', full: 1, max: 500 },
        ];
        const PUNCH_COLOR = { Open: PILL.red, Fixed: PILL.amber, Verified: PILL.green };
        function renderPunch() {
            const list = PC.current.punch;
            const body = document.getElementById('pcTabBody');
            const c = s => list.filter(x => x.status === s).length;
            body.innerHTML = sectionHead('Punch List / Quality Check', 'Inspect against approved drawings, list deficiencies, correct, then re-inspect.', addBtn('pcAddPunch', 'Add Item'))
                + `<div class="grid grid-cols-3 gap-2 mb-4">${['Open', 'Fixed', 'Verified'].map(s => `<div class="rounded-lg border border-gray-200 px-3 py-2"><p class="text-[10px] font-semibold uppercase tracking-wider text-gray-400">${s === 'Fixed' ? 'Fixed · for re-inspection' : s}</p><p class="text-lg font-bold ${s === 'Open' && c(s) ? 'text-red-600' : 'text-gray-900'}">${c(s)}</p></div>`).join('')}</div>`
                + (list.length ? `<div class="space-y-2">${list.map(r => {
                    const late = r.status === 'Open' && r.target_date && r.target_date < todayISO();
                    const next = r.status === 'Open' ? ['Fixed', 'Mark Fixed', 'bg-amber-600 hover:bg-amber-700'] : r.status === 'Fixed' ? ['Verified', 'Verify', 'bg-green-600 hover:bg-green-700'] : null;
                    return `<div class="flex flex-wrap items-center gap-3 rounded-lg border ${late ? 'border-red-200 bg-red-50/40' : 'border-gray-200'} px-3 py-2.5">
                        ${pill(r.status.toUpperCase(), PUNCH_COLOR[r.status])}
                        <div class="min-w-0 flex-1"><p class="text-xs font-semibold text-gray-900 ${r.status === 'Verified' ? 'line-through text-gray-400' : ''}">${esc(r.description)}</p>
                            <p class="text-[10.5px] text-gray-400">${esc(r.area || '—')}${r.responsible ? ' · ' + esc(r.responsible) : ''}${r.target_date ? ` · <span class="${late ? 'text-red-600 font-semibold' : ''}">target ${fmt(r.target_date)}</span>` : ''}${r.verified_at ? ' · verified ' + fmt(r.verified_at) : r.fixed_at ? ' · fixed ' + fmt(r.fixed_at) : ''}</p></div>
                        ${next ? `<button type="button" data-punch-next="${r.id}" data-to="${next[0]}" class="px-2.5 py-1 text-[10.5px] font-semibold text-white rounded-md ${next[2]}">${next[1]}</button>` : ''}
                        ${iconBtn(`data-punch="${r.id}"`, 'fa-pen', 'Edit')}
                    </div>`;
                }).join('')}</div>` : emptyBox('fa-list-check', 'No punch list items', 'After inspection, list incomplete work or defects here.'))
                + `<datalist id="pcRespList">${PC.current.workers.map(w => `<option value="${esc(w.name)}">`).join('')}</datalist>`;
            F('pcAddPunch').addEventListener('click', () => entityForm('punch', 'Punch Item', PUNCH_FIELDS, null));
            body.querySelectorAll('[data-punch]').forEach(b => b.addEventListener('click', () => entityForm('punch', 'Punch Item', PUNCH_FIELDS, list.find(x => x.id == b.dataset.punch))));
            body.querySelectorAll('[data-punch-next]').forEach(b => b.addEventListener('click', async () => {
                const r = list.find(x => x.id == b.dataset.punchNext);
                const data = { entity: 'punch', row_id: r.id };
                PUNCH_FIELDS.forEach(f => data[f.name] = r[f.name] ?? '');
                data.status = b.dataset.to;
                try { await must(await post('save_entity', data)); toast(data.status === 'Verified' ? 'Verified.' : 'Marked as fixed — for re-inspection.'); await reload(); }
                catch (e) { toast(e.message, 'error'); }
            }));
        }

    })(window.NHPC);
</script>
