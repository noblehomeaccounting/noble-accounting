<?php
// coordenator/step5-timeline.php — STEP 5: Project Timeline (Gantt + task modal)
// Kasama sa coordenator.php (huwag buksan nang direkta).
defined('ROOT_PATH') || exit;
?>
<script>
    (function (PC) {
        'use strict';
        const { esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL, money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn, openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals, openProject, loadList, renderWorkspace, go } = PC;

        // ── Kahulugan ng hakbang (galing sa F. Operations) ──
        PC.defineStep({ key: 'timeline', n: 5, label: 'Project Timeline', icon: 'fa-chart-gantt', optional: true,
            role: 'Schedule procurement, fabrication, delivery, and installation (if required).',
            link: 'The timeline helps ensure materials, permits, manpower, and approvals are ready when needed.',
            duties: [
                ['Prepare the schedule for procurement, fabrication, delivery, and installation', () => PC.current.timeline.length > 0],
                ['Identify target dates and project milestones'],
                ['Coordinate dates with Purchasing, production, subcontractors, and the client'],
                ['Monitor actual progress against planned dates', () => PC.current.timeline.some(t => t.actual_start)],
                ['Identify delays and coordinate corrective actions', () => PC.current.timeline.length > 0 && !PC.current.timeline.some(isDelayed)],
            ],
            render: renderTimeline,
        });

        let editingTask = null;

        // ═════════════════════════════════════════════════════════
        //  STEP 5 · PROJECT TIMELINE — Gantt (walang horizontal scroll: naka-percent ang bars)
        // ═════════════════════════════════════════════════════════
        function renderTimeline() {
            const tl = PC.current.timeline;
            const body = document.getElementById('pcTabBody');
            const toolbar = `
                <div class="flex flex-wrap items-center justify-between gap-2 mb-4">
                    <div class="flex flex-wrap items-center gap-3 text-[11px] text-gray-500">
                        <span class="inline-flex items-center gap-1.5"><span class="w-4 h-2.5 rounded-sm bg-amber-200"></span>Planned</span>
                        <span class="inline-flex items-center gap-1.5"><span class="w-4 h-2.5 rounded-sm bg-amber-600"></span>Progress</span>
                        <span class="inline-flex items-center gap-1.5"><span class="w-4 h-1 rounded-sm bg-gray-700 opacity-60"></span>Actual</span>
                        <span class="inline-flex items-center gap-1.5"><span class="w-4 h-2.5 rounded-sm bg-red-200"></span>Delayed</span>
                        <span class="inline-flex items-center gap-1.5"><span class="w-0.5 h-3 bg-red-500"></span>Today</span>
                    </div>
                    <button type="button" id="pcAddTask" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-amber-700 rounded-lg hover:bg-amber-800 shadow-sm"><i class="fa-solid fa-plus"></i> Add task</button>
                </div>`;

            if (!tl.length) {
                body.innerHTML = toolbar + `
                <div class="rounded-xl border-2 border-dashed border-gray-200 px-6 py-10 text-center">
                    <i class="fa-solid fa-chart-gantt text-3xl text-gray-300 mb-3"></i>
                    <p class="text-sm font-semibold text-gray-700">No timeline yet</p>
                    <p class="text-xs text-gray-400 mt-1 mb-4">Add tasks one by one, or start from the standard template and adjust the dates.</p>
                    <div class="inline-flex flex-wrap items-center justify-center gap-2">
                        <span class="text-[11px] text-gray-500">Start date</span>
                        <input type="date" id="pcTplStart" value="${todayISO()}" class="border border-gray-200 rounded-lg px-3 py-1.5 text-xs outline-none focus:border-amber-600">
                        <button type="button" id="pcTplApply" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 rounded-lg hover:bg-amber-100"><i class="fa-solid fa-wand-magic-sparkles"></i> Use template</button>
                    </div>
                    <p class="text-[10px] text-gray-400 mt-3">Plan → Dismantling → Delivery → Installation → Hand Over</p>
                </div>`;
                document.getElementById('pcAddTask').addEventListener('click', () => openTask(null));
                document.getElementById('pcTplApply').addEventListener('click', async function () {
                    this.disabled = true;
                    try {
                        const d = await api('apply_template', { project_id: PC.current.project.id, start_date: document.getElementById('pcTplStart').value }, true);
                        if (!d.success) throw new Error(d.message);
                        toast('Template added. Adjust the dates as needed.');
                        await openProject(PC.current.project.id, true); loadList();
                    } catch (e) { toast(e.message, 'error'); this.disabled = false; }
                });
                return;
            }

            // saklaw ng chart (may 1 araw na palugit sa magkabilang dulo)
            let min = tl[0].start_date, max = tl[0].end_date;
            tl.forEach(t => {
                [t.start_date, t.actual_start].forEach(d => { if (d && d < min) min = d; });
                [t.end_date, t.actual_end].forEach(d => { if (d && d > max) max = d; });
            });
            const startD = new Date(toD(min).getTime() - DAY), endD = new Date(toD(max).getTime() + DAY);
            const total = Math.round((endD - startD) / DAY) + 1;
            const pct = d => ((toD(d) - startD) / DAY) / total * 100;
            const span = (a, b) => days(a, b) / total * 100;

            // header ticks (araw/linggo depende sa haba)
            const step = total <= 21 ? 1 : total <= 45 ? 2 : total <= 90 ? 7 : 14;
            let ticks = '', months = '', weekends = '';
            for (let i = 0; i < total; i++) {
                const d = new Date(startD.getTime() + i * DAY);
                const left = i / total * 100;
                if (d.getDay() === 0 || d.getDay() === 6) weekends += `<div class="pc-weekend" style="left:${left}%;width:${100 / total}%"></div>`;
                if (i % step === 0) ticks += `<span class="absolute text-[9px] text-gray-400 -translate-x-1/2" style="left:${left + 50 / total}%">${d.getDate()}</span>`;
                if (i === 0 || d.getDate() === 1) months += `<span class="absolute text-[10px] font-semibold text-gray-600 whitespace-nowrap" style="left:${left}%">${d.toLocaleDateString('en-PH', { month: 'short', year: 'numeric' })}</span>`;
            }
            const today = todayISO();
            const todayLine = (today >= ymd(startD) && today <= ymd(endD)) ? `<div class="pc-today" style="left:${pct(today) + 50 / total}%"></div>` : '';

            // nakagrupo bawat kategorya (ayon sa pagkakasunod)
            const groups = [];
            tl.forEach(t => {
                let g = groups.find(x => x.cat === t.category);
                if (!g) groups.push(g = { cat: t.category, items: [] });
                g.items.push(t);
            });

            const row = (left, right, cls = '') => `<div class="grid grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)] md:grid-cols-[340px_minmax(0,1fr)] border-b border-gray-100 ${cls}">${left}<div class="relative pc-gantt-grid" style="--day:${100 / total}%">${weekends}${todayLine}${right}</div></div>`;

            let html = row(
                `<div class="grid grid-cols-[minmax(0,1fr)_40px_52px_52px] gap-1 px-3 py-2 text-[10px] font-semibold uppercase tracking-wider text-gray-400 items-end"><span>Task</span><span class="text-center">Days</span><span>Start</span><span>End</span></div>`,
                `<div class="relative h-9">${months.replace(/class="absolute/g, 'class="absolute top-1')}<div class="absolute inset-x-0 bottom-1 h-3">${ticks}</div></div>`,
                'bg-gray-50 sticky top-0 z-10');

            groups.forEach(g => {
                const gMin = g.items.reduce((a, t) => a < t.start_date ? a : t.start_date, g.items[0].start_date);
                const gMax = g.items.reduce((a, t) => a > t.end_date ? a : t.end_date, g.items[0].end_date);
                const gProg = Math.round(g.items.reduce((a, t) => a + t.progress, 0) / g.items.length);
                html += row(
                    `<div class="px-3 py-1.5 text-[11px] font-bold text-gray-800 uppercase tracking-wide truncate bg-slate-50">${esc(g.cat)} <span class="font-semibold text-gray-400 normal-case">· ${gProg}%</span></div>`,
                    `<div class="h-7"><div class="absolute top-1/2 -translate-y-1/2 h-1.5 rounded-full bg-gray-300" style="left:${pct(gMin)}%;width:${span(gMin, gMax)}%"></div></div>`,
                    'bg-slate-50');
                g.items.forEach(t => {
                    const late = isDelayed(t);
                    const planCls = late ? 'bg-red-200' : (t.progress >= 100 ? 'bg-green-200' : 'bg-amber-200');
                    const fillCls = late ? 'bg-red-500' : (t.progress >= 100 ? 'bg-green-500' : 'bg-amber-600');
                    const actual = t.actual_start ? `<div class="pc-actual" style="left:${pct(t.actual_start)}%;width:${span(t.actual_start, t.actual_end || (today > t.actual_start ? today : t.actual_start))}%"></div>` : '';
                    html += row(
                        `<button type="button" data-task="${t.id}" class="grid grid-cols-[minmax(0,1fr)_40px_52px_52px] gap-1 px-3 py-2 text-left items-center hover:bg-amber-50/50 w-full">
                            <span class="min-w-0">
                                <span class="block text-xs text-gray-800 truncate">${esc(t.name)}${late ? ' <i class="fa-solid fa-triangle-exclamation text-red-500 text-[10px]"></i>' : ''}${t.progress >= 100 ? ' <i class="fa-solid fa-circle-check text-green-500 text-[10px]"></i>' : ''}</span>
                                <span class="block text-[10px] text-gray-400">${t.progress}%${t.remarks ? ' · ' + esc(t.remarks) : ''}</span>
                            </span>
                            <span class="text-center text-xs tabular-nums text-gray-600">${days(t.start_date, t.end_date)}</span>
                            <span class="text-[11px] text-gray-500">${fmt(t.start_date)}</span>
                            <span class="text-[11px] text-gray-500">${fmt(t.end_date)}</span>
                        </button>`,
                        `<div class="h-11 cursor-pointer" data-task="${t.id}" title="${esc(t.name)} · ${fmtY(t.start_date)} – ${fmtY(t.end_date)} · ${t.progress}%">
                            <div class="pc-bar ${planCls}" style="left:${pct(t.start_date)}%;width:${span(t.start_date, t.end_date)}%"><i class="${fillCls}" style="width:${t.progress}%"></i></div>
                            ${actual}
                        </div>`);
                });
            });

            body.innerHTML = toolbar + `<div class="rounded-lg border border-gray-200 overflow-hidden">${html}</div>
                <p class="mt-2 text-[11px] text-gray-400">Click a task to edit its dates or progress.</p>`;
            document.getElementById('pcAddTask').addEventListener('click', () => openTask(null));
            body.querySelectorAll('[data-task]').forEach(el => el.addEventListener('click', () => openTask(+el.dataset.task)));
        }


        // ═════════════ TASK MODAL ═════════════
        const modal = document.getElementById('pcTaskModal');
        const openModal = () => { modal.classList.remove('hidden'); modal.classList.add('flex'); };
        const closeModal = () => { modal.classList.add('hidden'); modal.classList.remove('flex'); };
        document.querySelectorAll('[data-close="pcTaskModal"]').forEach(b => b.addEventListener('click', closeModal));
        modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
        document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

        const taskErr = msg => { F('pcTError').textContent = msg || ''; F('pcTError').classList.toggle('hidden', !msg); };
        function updateDur() {
            const s = F('pcTStart').value, e = F('pcTEnd').value;
            F('pcTDur').textContent = s && e && e >= s ? `${days(s, e)} day${days(s, e) === 1 ? '' : 's'}` : '';
        }
        ['pcTStart', 'pcTEnd'].forEach(id => F(id).addEventListener('change', () => {
            if (id === 'pcTStart' && F('pcTEnd').value && F('pcTEnd').value < F('pcTStart').value) F('pcTEnd').value = F('pcTStart').value;
            updateDur();
        }));
        F('pcTProg').addEventListener('input', () => F('pcTProgVal').textContent = F('pcTProg').value + '%');

        function openTask(id) {
            const t = id ? PC.current.timeline.find(x => x.id === id) : null;
            editingTask = t;
            F('pcTaskTitle').textContent = t ? 'Edit task' : 'Add task';
            F('pcCatList').innerHTML = [...new Set(PC.current.timeline.map(x => x.category))].map(c => `<option value="${esc(c)}">`).join('');
            const last = PC.current.timeline[PC.current.timeline.length - 1];
            F('pcTCat').value = t ? t.category : (last ? last.category : '');
            F('pcTName').value = t ? t.name : '';
            F('pcTStart').value = t ? t.start_date : (last ? ymd(new Date(toD(last.end_date).getTime() + DAY)) : todayISO());
            F('pcTEnd').value = t ? t.end_date : F('pcTStart').value;
            F('pcTAStart').value = t?.actual_start || '';
            F('pcTAEnd').value = t?.actual_end || '';
            F('pcTProg').value = t ? t.progress : 0;
            F('pcTProgVal').textContent = F('pcTProg').value + '%';
            F('pcTRemarks').value = t?.remarks || '';
            taskErr('');
            updateDur();
            F('pcTDelWrap').innerHTML = t ? '<button type="button" id="pcTDel" class="px-3 py-2 text-[11px] font-semibold text-red-600 hover:bg-red-50 rounded-lg"><i class="fa-solid fa-trash mr-1"></i>Delete</button>' : '';
            if (t) F('pcTDel').addEventListener('click', askDelete);
            openModal();
            setTimeout(() => F(t ? 'pcTName' : (F('pcTCat').value ? 'pcTName' : 'pcTCat')).focus(), 50);
        }

        function askDelete() {
            F('pcTDelWrap').innerHTML = `<span class="text-[11px] text-red-700 mr-1">Delete this task?</span>
                <button type="button" id="pcTDelYes" class="px-2.5 py-1.5 text-[11px] font-semibold text-white bg-red-600 rounded-md hover:bg-red-700">Delete</button>
                <button type="button" id="pcTDelNo" class="px-2 py-1.5 text-[11px] font-semibold text-gray-500 hover:bg-gray-100 rounded-md">No</button>`;
            F('pcTDelNo').addEventListener('click', () => openTask(editingTask.id));
            F('pcTDelYes').addEventListener('click', async () => {
                try {
                    const d = await api('delete_task', { project_id: PC.current.project.id, task_id: editingTask.id }, true);
                    if (!d.success) throw new Error(d.message);
                    closeModal(); toast('Task deleted.');
                    await openProject(PC.current.project.id, true); loadList();
                } catch (e) { taskErr(e.message); }
            });
        }

        F('pcTSave').addEventListener('click', async function () {
            const v = {
                project_id: PC.current.project.id, task_id: editingTask ? editingTask.id : 0,
                category: F('pcTCat').value.trim().toUpperCase(), name: F('pcTName').value.trim(),
                start_date: F('pcTStart').value, end_date: F('pcTEnd').value,
                actual_start: F('pcTAStart').value, actual_end: F('pcTAEnd').value,
                progress: F('pcTProg').value, remarks: F('pcTRemarks').value.trim(),
            };
            if (!v.category || !v.name) return taskErr('Category and task are required.');
            if (!v.start_date || !v.end_date) return taskErr('Planned start and end dates are required.');
            if (v.end_date < v.start_date) return taskErr('End date cannot be earlier than the start date.');
            if (v.actual_start && v.actual_end && v.actual_end < v.actual_start) return taskErr('Actual end cannot be earlier than actual start.');
            taskErr('');
            this.disabled = true;
            try {
                const d = await api('save_task', v, true);
                if (!d.success) throw new Error(d.message);
                closeModal(); toast(editingTask ? 'Task updated.' : 'Task added.');
                await openProject(PC.current.project.id, true); loadList();
            } catch (e) { taskErr(e.message); }
            finally { this.disabled = false; }
        });

    })(window.NHPC);
</script>
