<?php
// coordenator/step3-workers.php — STEP 3: Subcontractors / Workers (attendance + labor-only quotation)
// Kasama sa coordenator.php (huwag buksan nang direkta).
defined('ROOT_PATH') || exit;
?>
<script>
    (function (PC) {
        'use strict';
        const { esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL, money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn, openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals, openProject, loadList, renderWorkspace, go } = PC;

        // ── Kahulugan ng hakbang (galing sa F. Operations) ──
        PC.defineStep({ key: 'workers', n: 3, label: 'Subcontractors / Workers', icon: 'fa-helmet-safety',
            role: 'Line up the manpower and subcontractors for the work.',
            link: 'Operations aligns workers with approved drawings, available materials, and the project timeline.',
            duties: [
                ['Identify the manpower needed for the project', () => PC.current.workers.length > 0],
                ['Coordinate subcontractor availability, scope of work, and schedule', () => PC.current.quotes.length > 0],
                ['Confirm work assignments and safety requirements'],
                ['Monitor attendance, workmanship, and progress', () => PC.current.attendance.length > 0],
                ['Address manpower shortages and site issues'],
            ],
            render: renderWorkers,
        });

        // ═════════════════════════════════════════════════════════
        //  STEP 3 · SUBCONTRACTORS / WORKERS
        // ═════════════════════════════════════════════════════════
        let attDate = todayISO();
        const WORKER_FIELDS = [
            { name: 'name', label: 'Name', req: 1 },
            { name: 'kind', label: 'Type', type: 'select', options: ['Worker', 'Subcontractor'] },
            { name: 'role', label: 'Role / Trade', list: 'pcRoleList', ph: 'e.g. Carpenter, Foreman' },
            { name: 'contact', label: 'Contact No.', max: 50 },
            { name: 'scope', label: 'Scope of work / Assignment', full: 1 },
            { name: 'start_date', label: 'Start', type: 'date' },
            { name: 'end_date', label: 'End', type: 'date' },
            { name: 'status', label: 'Status', type: 'select', options: ['Active', 'Standby', 'Done'] },
            { name: 'remarks', label: 'Safety / remarks', max: 500 },
        ];
        function renderWorkers() {
            const ws = PC.current.workers, quotes = PC.current.quotes;
            const body = document.getElementById('pcTabBody');
            const active = ws.filter(w => w.status === 'Active');
            const att = (wid) => PC.current.attendance.find(a => a.worker_id == wid && a.work_date === attDate);
            body.innerHTML = sectionHead('Workers & Subcontractors', 'Manpower, assignments and daily attendance.', addBtn('pcAddWorker', 'Add Worker / Subcon'))
                + `<div class="grid grid-cols-1 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)] gap-4">
                    <div>${ws.length ? `<div class="rounded-lg border border-gray-200 divide-y divide-gray-100">${ws.map(w => `
                        <div class="flex items-center gap-3 px-3 py-2.5">
                            <span class="w-9 h-9 rounded-full ${w.kind === 'Subcontractor' ? 'bg-violet-100 text-violet-700' : 'bg-amber-100 text-amber-800'} flex items-center justify-center text-xs font-bold shrink-0">${esc((w.name || '?').trim().split(/\s+/).map(x => x[0]).slice(0, 2).join('').toUpperCase())}</span>
                            <div class="min-w-0 flex-1">
                                <p class="text-xs font-semibold text-gray-900 truncate">${esc(w.name)} ${w.kind === 'Subcontractor' ? pill('SUBCON', PILL.violet) : ''}</p>
                                <p class="text-[10.5px] text-gray-400 truncate">${esc(w.role || '—')}${w.scope ? ' · ' + esc(w.scope) : ''}${w.contact ? ' · ' + esc(w.contact) : ''}</p>
                            </div>
                            <span class="text-[10.5px] text-gray-500 whitespace-nowrap">${w.days_present} day${w.days_present == 1 ? '' : 's'}</span>
                            ${pill(w.status.toUpperCase(), w.status === 'Active' ? PILL.green : w.status === 'Done' ? PILL.gray : PILL.amber)}
                            ${iconBtn(`data-worker="${w.id}"`, 'fa-pen', 'Edit')}
                        </div>`).join('')}</div>` : emptyBox('fa-helmet-safety', 'No workers yet', 'Add the subcontractors and workers assigned to this project.')}</div>

                    <div class="rounded-lg border border-gray-200">
                        <div class="flex items-center justify-between gap-2 px-3 py-2.5 border-b border-gray-100 bg-gray-50">
                            <p class="text-xs font-semibold text-gray-800"><i class="fa-solid fa-user-check text-amber-700 mr-1"></i> Attendance</p>
                            <input type="date" id="pcAttDate" value="${attDate}" max="${todayISO()}" class="border border-gray-200 rounded-md px-2 py-1 text-[11px] outline-none focus:border-amber-600">
                        </div>
                        ${active.length ? `<ul class="divide-y divide-gray-100">${active.map(w => {
                            const a = att(w.id); const st = a ? (+a.present ? 'p' : 'a') : '';
                            return `<li class="flex items-center justify-between gap-2 px-3 py-2"><span class="text-xs text-gray-700 truncate">${esc(w.name)}</span>
                                <span class="inline-flex rounded-md border border-gray-200 overflow-hidden text-[10.5px] font-semibold">
                                    <button type="button" data-att="${w.id}" data-val="1" class="px-2.5 py-1 ${st === 'p' ? 'bg-green-600 text-white' : 'text-gray-500 hover:bg-gray-50'}">Present</button>
                                    <button type="button" data-att="${w.id}" data-val="0" class="px-2.5 py-1 border-l border-gray-200 ${st === 'a' ? 'bg-red-500 text-white' : 'text-gray-500 hover:bg-gray-50'}">Absent</button>
                                </span></li>`;
                        }).join('')}</ul>
                        <p class="px-3 py-2 text-[10.5px] text-gray-400 border-t border-gray-100">${active.filter(w => +(att(w.id)?.present)).length} of ${active.length} present on ${fmtY(attDate)}</p>`
                        : '<p class="px-3 py-6 text-center text-[11px] text-gray-400">No active workers.</p>'}
                    </div>
                </div>

                <div class="mt-8">${sectionHead('Subcontractor Quotations (Labor Only)', 'The labor quotation of each subcontractor — this becomes the contract amount in Progress Billing.', addBtn('pcAddQuote', 'New Labor Quotation'))}
                ${quotes.length ? `<div class="grid grid-cols-1 md:grid-cols-2 gap-3">${quotes.map(q => `
                    <div class="rounded-xl border border-gray-200 p-4">
                        <div class="flex items-start justify-between gap-2">
                            <div class="min-w-0"><p class="text-sm font-semibold text-gray-900 truncate">${esc(q.subcontractor)}</p><p class="text-[11px] text-gray-400">${esc(q.subject || '')} · ${fmtY(q.quote_date)}</p></div>
                            <div class="flex items-center gap-1">${iconBtn(`data-quote-print="${q.id}"`, 'fa-print', 'View / Print')}${iconBtn(`data-quote="${q.id}"`, 'fa-pen', 'Edit')}</div>
                        </div>
                        <div class="mt-3 flex items-end justify-between"><p class="text-[11px] text-gray-500">${q.items.length} item${q.items.length === 1 ? '' : 's'}${q.duration_days ? ' · ' + q.duration_days + ' days' : ''}</p><p class="text-lg font-bold text-gray-900 tabular-nums">₱ ${money(q.total)}</p></div>
                    </div>`).join('')}</div>` : emptyBox('fa-file-signature', 'No labor quotation yet', 'Encode the subcontractor\'s Quotation for Works (Labor Only).')}</div>
                <datalist id="pcRoleList"><option>Foreman<option>Carpenter<option>Installer<option>Painter<option>Electrician<option>Helper<option>Glass installer</datalist>`;

            F('pcAddWorker').addEventListener('click', () => entityForm('worker', 'Worker', WORKER_FIELDS, null));
            body.querySelectorAll('[data-worker]').forEach(b => b.addEventListener('click', () => entityForm('worker', 'Worker', WORKER_FIELDS, ws.find(x => x.id == b.dataset.worker))));
            F('pcAttDate').addEventListener('change', e => { attDate = e.target.value || todayISO(); renderWorkers(); });
            body.querySelectorAll('[data-att]').forEach(b => b.addEventListener('click', async () => {
                try {
                    await must(await post('set_attendance', { worker_id: b.dataset.att, work_date: attDate, present: b.dataset.val }));
                    const ex = PC.current.attendance.find(a => a.worker_id == b.dataset.att && a.work_date === attDate);
                    if (ex) ex.present = b.dataset.val; else PC.current.attendance.push({ worker_id: b.dataset.att, work_date: attDate, present: b.dataset.val });
                    renderWorkers();
                } catch (e) { toast(e.message, 'error'); }
            }));
            F('pcAddQuote').addEventListener('click', () => quoteForm(null));
            body.querySelectorAll('[data-quote]').forEach(b => b.addEventListener('click', () => quoteForm(quotes.find(q => q.id == b.dataset.quote))));
            body.querySelectorAll('[data-quote-print]').forEach(b => b.addEventListener('click', () => { const q = quotes.find(x => x.id == b.dataset.quotePrint); previewDoc(`Labor Quotation — ${q.subcontractor}`, quoteDoc(q)); }));
        }

        const QUOTE_COLS = [
            { name: 'section', label: 'Section', ph: 'e.g. CLOSET', w: '20%' },
            { name: 'item_name', label: 'Item', ph: 'e.g. Wardrobe', w: '30%' },
            { name: 'qty', label: 'Qty', type: 'number', right: true, w: '11%' },
            { name: 'unit', label: 'Unit', list: 'pcQUnitList', ph: 'SQM', w: '10%' },
            { name: 'unit_cost', label: 'Unit Cost', type: 'number', right: true, w: '14%' },
        ];
        const DEFAULT_TERMS = '1. Client shall provide necessary permit for workers passage to the project site.\n2. Terms of Payment: The Client shall pay the CONTRACTOR {dp}% Down Payment, and {rest}% Progress Billing\n3. Duration of Work: {days} calendar days';
        function quoteForm(q) {
            const subs = PC.current.workers.filter(w => w.kind === 'Subcontractor').map(w => w.name);
            const rows = q ? q.items.map(i => ({ section: i.section, item_name: i.item_name, qty: qtyFmt(i.qty), unit: i.unit, unit_cost: num(i.unit_cost) })) : [];
            openForm({
                title: q ? 'Edit Labor Quotation' : 'New Labor Quotation', wide: true, saveLabel: 'Save Quotation',
                body: `<div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                        <label class="col-span-2">${lbl('Subcontractor', 1)}<input name="subcontractor" value="${esc(q?.subcontractor || '')}" list="pcSubList" maxlength="150" class="${inputCls}"></label>
                        <label class="col-span-2">${lbl('Subject')}<input name="subject" value="${esc(q?.subject || 'Quotation for Works (Labor Only)')}" maxlength="255" class="${inputCls}"></label>
                        <label>${lbl('Date')}<input type="date" name="quote_date" value="${q?.quote_date || todayISO()}" class="${inputCls}"></label>
                        <label>${lbl('Duration (days)')}<input type="number" min="0" name="duration_days" value="${q?.duration_days || 60}" class="${inputCls}"></label>
                        <label>${lbl('Down payment %')}<input type="number" min="0" max="100" name="downpayment_pct" value="${q ? +q.downpayment_pct : 30}" class="${inputCls}"></label>
                        <div class="flex items-end"><p class="text-[11px] text-gray-500">Total: <b id="pcQTotal" class="text-gray-900 text-sm">₱ 0.00</b></p></div>
                    </div>
                    ${itemTable('pcQItems', QUOTE_COLS, rows, 'Add item')}
                    <label class="block mt-4">${lbl('Terms and Conditions')}<textarea name="terms" rows="4" maxlength="2000" class="${inputCls} resize-none">${esc(q?.terms || '')}</textarea></label>
                    <p class="text-[10.5px] text-gray-400 mt-1">Leave blank to use the standard terms (permit, down payment / progress billing, duration).</p>
                    <datalist id="pcSubList">${subs.map(s => `<option value="${esc(s)}">`).join('')}</datalist>
                    <datalist id="pcQUnitList"><option>SQM<option>LM<option>PCS<option>SET<option>LOT</datalist>`,
                onOpen: () => {
                    const calc = () => {
                        const qty = tableVals('pcQItems', 'qty'), cost = tableVals('pcQItems', 'unit_cost');
                        F('pcQTotal').textContent = '₱ ' + money(qty.reduce((a, v, i) => a + num(v) * num(cost[i]), 0));
                    };
                    wireItemTable('pcQItems', QUOTE_COLS, calc); calc();
                },
                onSave: async err => {
                    const items = {}; QUOTE_COLS.forEach(c => items[c.name] = tableVals('pcQItems', c.name));
                    if (!fv('subcontractor')) return err('Subcontractor name is required.'), false;
                    if (!items.item_name.some(Boolean)) return err('Add at least one item.'), false;
                    let terms = fv('terms');
                    if (!terms) { const dp = num(fv('downpayment_pct')); terms = DEFAULT_TERMS.replace('{dp}', dp).replace('{rest}', 100 - dp).replace('{days}', num(fv('duration_days')) || '—'); }
                    await must(await post('save_quote', Object.assign({ quote_id: q ? q.id : 0, subcontractor: fv('subcontractor'), subject: fv('subject'), quote_date: fv('quote_date'), duration_days: fv('duration_days'), downpayment_pct: fv('downpayment_pct'), terms }, items)));
                    toast('Labor quotation saved.');
                    await reload();
                },
                onDelete: q ? async () => { await must(await post('delete_quote', { quote_id: q.id })); toast('Quotation deleted.'); await reload(); } : null,
            });
        }
        function quoteGroups(q) {
            const groups = [];
            q.items.forEach(i => { let g = groups.find(x => x.sec === (i.section || '')); if (!g) groups.push(g = { sec: i.section || '', items: [] }); g.items.push(i); });
            return groups;
        }
        function quoteDoc(q) {
            const p = P();
            const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            let rows = '';
            quoteGroups(q).forEach((g, gi) => {
                const L = letters[gi] || String(gi + 1);
                rows += `<tr class="sec"><td class="c">${L}</td><td>${esc(g.sec || '—')}</td><td></td><td></td><td></td><td class="r">-</td></tr>`;
                g.items.forEach((i, k) => rows += `<tr><td class="r">${L}.${k + 1}</td><td>${esc(i.item_name)}</td><td class="r">${qtyFmt(i.qty)}</td><td>${esc(i.unit)}</td><td class="r">${money(i.unit_cost)}</td><td class="r">${money(i.amount)}</td></tr>`);
            });
            return `<div class="pcdoc pcq">
                <table class="nb info">
                    <tr><td style="width:16%">Project Name</td><td style="width:3%">:</td><td><b>${esc(p.client_name)}</b></td></tr>
                    <tr><td>Location</td><td>:</td><td><b>${esc(p.location || '')}</b></td></tr>
                    <tr><td>Subject</td><td>:</td><td><b>${esc(q.subject || 'Quotation for Works')}</b></td></tr>
                    <tr><td>Date</td><td>:</td><td><b>${esc(fmtLong(q.quote_date))}</b></td></tr>
                </table>
                <div class="qt">QUOTATION for ${esc((p.scope || 'WORKS').toUpperCase())} (LABOR ONLY)</div>
                <table class="tbl"><colgroup><col style="width:8%"><col style="width:44%"><col style="width:10%"><col style="width:10%"><col style="width:13%"><col style="width:15%"></colgroup>
                    <tr class="th"><td rowspan="2">Item No.</td><td rowspan="2">Items</td><td rowspan="2">Qty</td><td rowspan="2">Unit</td><td colspan="2">Labor Cost</td></tr>
                    <tr class="th"><td>Unit Cost</td><td>Amount</td></tr>
                    ${rows}
                    <tr class="tot"><td colspan="5" class="c">TOTAL</td><td class="r b">${money(q.total)}</td></tr>
                </table>
                <p class="b" style="margin-top:14px">Terms and Conditions:</p>
                ${(q.terms || '').split('\n').filter(Boolean).map(t => `<p>${esc(t)}</p>`).join('')}
                <table class="nb sign" style="margin-top:28px"><tr><td>Submitted by:</td><td>Conforme:</td></tr>
                    <tr><td><div class="ln2"></div><div class="nm">${esc(q.subcontractor)}</div><div>Contractor</div></td><td><div class="ln2"></div><div class="nm" style="font-weight:400">Mr. Ken Yang</div></td></tr></table>
            </div>`;
        }

        PC.quoteGroups = quoteGroups;   // gamit din ng Turnover letter
    })(window.NHPC);
</script>
