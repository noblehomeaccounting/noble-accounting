<?php
// coordenator/step1-delivery.php — STEP 1: Delivery Form (Delivery Receipt + print)
// Kasama sa coordenator.php (huwag buksan nang direkta).
defined('ROOT_PATH') || exit;
?>
<script>
    (function (PC) {
        'use strict';
        const { esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL, money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn, openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals, openProject, loadList, renderWorkspace, go } = PC;

        // ── Kahulugan ng hakbang (galing sa F. Operations) ──
        PC.defineStep({ key: 'delivery', n: 1, label: 'Delivery Form', icon: 'fa-truck',
            role: 'Prepare delivery documentation for materials, equipment, or fabricated items.',
            link: 'Purchasing confirms material availability; Operations arranges and documents delivery.',
            duties: [
                ['Prepare delivery documentation for materials, equipment, or fabricated items', () => PC.current.deliveries.length > 0],
                ['Verify descriptions, quantities, project details, and destination'],
                ['Coordinate delivery dates, transportation, and site access', () => PC.current.deliveries.length > 0 && PC.current.deliveries.every(d => d.scheduled_date || d.delivered_at)],
                ['Obtain acknowledgment or proof of receipt', () => PC.current.deliveries.length > 0 && PC.current.deliveries.every(d => d.status === 'Delivered')],
            ],
            render: renderDelivery,
            badge: () => PC.current.deliveries.filter(d => d.status !== 'Delivered').length,
        });

        // ═════════════════════════════════════════════════════════
        //  STEP 1 · DELIVERY FORM
        // ═════════════════════════════════════════════════════════
        function renderDelivery() {
            const list = PC.current.deliveries;
            const body = document.getElementById('pcTabBody');
            body.innerHTML = sectionHead('Delivery Receipts', 'Prepare the DR, schedule the delivery, and record who received it.', addBtn('pcAddDr', 'New Delivery Receipt'))
                + (list.length ? `<div class="space-y-3">${list.map(d => {
                    const done = d.status === 'Delivered';
                    const total = d.items.reduce((a, i) => a + num(i.amount) * (num(i.qty) || 1), 0);
                    return `<div class="rounded-xl border ${done ? 'border-green-200 bg-green-50/30' : 'border-gray-200'} p-4">
                        <div class="flex flex-wrap items-start justify-between gap-3">
                            <div class="min-w-0">
                                <div class="flex items-center gap-2"><p class="font-mono text-sm font-bold text-gray-900">DR# ${esc(d.dr_no)}</p>${done ? pill('DELIVERED', PILL.green) : pill('SCHEDULED', PILL.amber)}</div>
                                <p class="text-[11px] text-gray-500 mt-0.5">${fmtY(d.dr_date)} · ${d.items.length} item${d.items.length === 1 ? '' : 's'}${total ? ' · ₱ ' + money(total) : ''}</p>
                                <p class="text-[11px] text-gray-400 mt-0.5">${done ? `<i class="fa-solid fa-truck text-green-600 mr-1"></i>Delivered ${fmtY(d.delivered_at)} · received by <b class="text-gray-600">${esc(d.received_by)}</b>`
                                    : `<i class="fa-regular fa-calendar mr-1"></i>Scheduled ${d.scheduled_date ? fmtY(d.scheduled_date) : '—'}${d.vehicle ? ' · ' + esc(d.vehicle) : ''}`}</p>
                            </div>
                            <div class="flex items-center gap-1">
                                ${iconBtn(`data-dr-print="${d.id}"`, 'fa-print', 'View / Print')}
                                ${done ? '' : iconBtn(`data-dr-edit="${d.id}"`, 'fa-pen', 'Edit')}
                                ${done ? '' : `<button type="button" data-dr-deliver="${d.id}" class="ml-1 inline-flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold text-white bg-green-600 rounded-md hover:bg-green-700"><i class="fa-solid fa-truck text-[10px]"></i> Delivered</button>`}
                            </div>
                        </div>
                        <div class="mt-3 flex flex-wrap gap-1.5">${d.items.slice(0, 6).map(i => `<span class="px-2 py-0.5 rounded-md bg-white border border-gray-200 text-[10.5px] text-gray-600">${esc(i.particular)} <b>×${qtyFmt(i.qty)}</b></span>`).join('')}${d.items.length > 6 ? `<span class="text-[10.5px] text-gray-400">+${d.items.length - 6} more</span>` : ''}</div>
                    </div>`;
                }).join('')}</div>` : emptyBox('fa-truck', 'No delivery receipts yet', 'Create one for the materials, equipment or fabricated items going to the site.'));
            F('pcAddDr').addEventListener('click', () => drForm(null));
            body.querySelectorAll('[data-dr-edit]').forEach(b => b.addEventListener('click', () => drForm(list.find(d => d.id == b.dataset.drEdit))));
            body.querySelectorAll('[data-dr-print]').forEach(b => b.addEventListener('click', () => { const d = list.find(x => x.id == b.dataset.drPrint); previewDoc(`DR# ${d.dr_no}`, drDoc(d)); }));
            body.querySelectorAll('[data-dr-deliver]').forEach(b => b.addEventListener('click', () => drDeliver(list.find(d => d.id == b.dataset.drDeliver))));
        }

        const DR_COLS = [
            { name: 'particular', label: 'Particular', ph: 'e.g. Working area upper cab', w: '38%' },
            { name: 'size', label: 'Size', ph: '296*1415*550', w: '20%' },
            { name: 'qty', label: 'Qty', type: 'number', right: true, w: '10%' },
            { name: 'unit', label: 'Unit', ph: 'SET', list: 'pcUnitList', w: '10%' },
            { name: 'amount', label: 'Amount', type: 'number', right: true, w: '14%' },
        ];
        function drForm(d) {
            const p = P();
            openForm({
                title: d ? `Edit DR# ${d.dr_no}` : 'New Delivery Receipt', wide: true, saveLabel: 'Save Delivery Receipt',
                body: `<div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                        <label>${lbl('DR Date', 1)}<input type="date" name="dr_date" value="${d ? d.dr_date : todayISO()}" class="${inputCls}"></label>
                        <label class="md:col-span-1">${lbl('Delivery Schedule')}<input type="date" name="scheduled_date" value="${d?.scheduled_date || ''}" class="${inputCls}"></label>
                        <label class="col-span-2">${lbl('Client Name', 1)}<input name="client_name" value="${esc(d ? d.client_name : p.client_name)}" maxlength="255" class="${inputCls}"></label>
                        <label class="col-span-2">${lbl('Address / Destination')}<input name="address" value="${esc(d ? d.address : (p.location || ''))}" maxlength="255" class="${inputCls}"></label>
                        <label class="col-span-2">${lbl('Transport / Vehicle')}<input name="vehicle" value="${esc(d?.vehicle || '')}" maxlength="150" list="pcVehicleList" placeholder="e.g. Company truck, Lalamove" class="${inputCls}"></label>
                        <label class="col-span-2 md:col-span-4">${lbl('Notes (site access, delivery permit, contact on site)')}<input name="notes" value="${esc(d?.notes || '')}" maxlength="1000" class="${inputCls}"></label>
                    </div>
                    ${itemTable('pcDrItems', DR_COLS, d ? d.items : [], 'Add item')}
                    <datalist id="pcUnitList"><option>SET<option>PCS<option>PC<option>LOT<option>SQM<option>LM<option>PAIRS<option>BOX</datalist>
                    <datalist id="pcVehicleList"><option>Company truck<option>Lalamove<option>Pick up by client</datalist>`,
                onOpen: () => wireItemTable('pcDrItems', DR_COLS),
                onSave: async err => {
                    const items = { particular: tableVals('pcDrItems', 'particular'), size: tableVals('pcDrItems', 'size'), qty: tableVals('pcDrItems', 'qty'), unit: tableVals('pcDrItems', 'unit'), amount: tableVals('pcDrItems', 'amount') };
                    if (!fv('client_name')) return err('Client name is required.'), false;
                    if (!items.particular.some(Boolean)) return err('Add at least one item.'), false;
                    await must(await post('save_delivery', Object.assign({ delivery_id: d ? d.id : 0, dr_date: fv('dr_date'), scheduled_date: fv('scheduled_date'), client_name: fv('client_name'), address: fv('address'), vehicle: fv('vehicle'), notes: fv('notes') }, items)));
                    toast(d ? 'Delivery receipt updated.' : 'Delivery receipt created.');
                    await reload();
                },
                onDelete: d ? async () => { await must(await post('delete_delivery', { delivery_id: d.id })); toast('Delivery receipt deleted.'); await reload(); } : null,
            });
        }
        function drDeliver(d) {
            openForm({
                title: `Mark DR# ${d.dr_no} as delivered`, saveLabel: 'Yes, delivered',
                body: `<div class="grid grid-cols-2 gap-3">
                    <label>${lbl('Date Delivered', 1)}<input type="date" name="delivered_at" value="${todayISO()}" max="${todayISO()}" class="${inputCls}"></label>
                    <label>${lbl('Received By', 1)}<input name="received_by" maxlength="150" placeholder="Name of receiver on site" class="${inputCls}"></label>
                    <label class="col-span-2 flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 text-[11px] text-amber-900 cursor-pointer"><input type="checkbox" name="confirm" class="mt-0.5 w-4 h-4 accent-green-600"> I have the signed delivery receipt / proof of receipt. This can't be undone.</label>
                </div>`,
                onSave: async err => {
                    if (fv('confirm') !== '1') return err('Please confirm you have the signed proof of receipt.'), false;
                    if (!fv('received_by')) return err('Enter who received the delivery.'), false;
                    await must(await post('deliver_receipt', { delivery_id: d.id, delivered_at: fv('delivered_at'), received_by: fv('received_by') }));
                    toast(`DR# ${d.dr_no} marked as delivered.`);
                    await reload();
                },
            });
        }
        function drDoc(d) {
            const rows = d.items.map((i, k) => `<tr><td class="c">${k + 1}</td><td class="b">${esc(i.particular)}</td><td class="c">${esc(i.size)}</td><td class="c">${qtyFmt(i.qty)}</td><td>${esc(i.unit)}</td><td class="r">${num(i.amount) ? money(i.amount) : ''}</td><td class="r">${num(i.amount) ? money(num(i.amount) * (num(i.qty) || 1)) : '-'}</td></tr>`).join('');
            const total = d.items.reduce((a, i) => a + num(i.amount) * (num(i.qty) || 1), 0);
            return `<div class="pcdoc pcdr">
                <div class="dr-head"><div class="dr-title">DELIVERY RECEIPT</div>
                    <table class="nb"><tr>
                        <td style="width:22%"><div class="dr-logo"><img src="${LOGO}" alt=""></div></td>
                        <td style="width:40%" class="dr-co"><b>Noblehome Construction Corporation</b><br>MC Premier 2F, Quezon City, Metro Manila, Philippines<br>(02) 8822-1295 / (+63)993-548-7799</td>
                        <td class="dr-meta"><table class="nb">
                            <tr><td>Client Name:</td><td><b>${esc(d.client_name)}</b></td></tr>
                            <tr><td>Address:</td><td><b>${esc(d.address || '')}</b></td></tr>
                            <tr><td>Date:</td><td><b>${esc(fmtSlash(d.dr_date))}</b></td></tr>
                            <tr><td>DR #:</td><td><b>${esc(d.dr_no)}</b></td></tr></table></td>
                    </tr></table></div>
                <table class="tbl"><colgroup><col style="width:4%"><col style="width:34%"><col style="width:18%"><col style="width:10%"><col style="width:8%"><col style="width:12%"><col style="width:14%"></colgroup>
                    <tr class="th"><td></td><td>Particular</td><td>Size</td><td>Quantity</td><td>Unit</td><td>Amount</td><td>Total</td></tr>
                    ${rows}
                    <tr><td colspan="7" class="c i">-------------------NOTHING FOLLOWS-------------------</td></tr>
                    <tr><td colspan="6" class="r b">TOTAL:</td><td class="r b">${money(total)}</td></tr>
                </table>
                ${d.notes ? `<p class="note"><b>Notes:</b> ${esc(d.notes)}</p>` : ''}
                <table class="nb terms"><tr><td style="width:55%">
                    <p class="blue">TERMS AND CONDITIONS</p>
                    <p>1. Payment Terms — 50% Downpayment, 40% upon Delivery, 10% after completion</p>
                    <p>2. Inspection and Acceptance — All materials delivered and installed must be inspected the day after the completion.</p>
                    <p>3. Validity — This Delivery Receipt is not an Invoice. This serves as proof of delivery only.</p>
                </td><td><p>Account Name: <b>Noblehome Construction Corp.</b></p><p>Account Number: <b>013-238-001-657</b></p><p>Bank: <b>BDO UNIBANK</b></p></td></tr></table>
                <table class="nb sign"><tr>
                    <td><div class="nm">${esc(d.prepared_by || '')}</div><div class="ln">Prepared By:</div></td>
                    <td><div class="nm">Mr. Ken Yang</div><div class="ln">Noted By:</div></td>
                    <td><div class="nm">${esc(d.received_by || '')}</div><div class="ln">Received By:</div></td>
                </tr></table>
            </div>`;
        }

    })(window.NHPC);
</script>
