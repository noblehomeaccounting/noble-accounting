<?php
// coordenator/overview.php — Overview: buod ng 8 hakbang, control points, transmittals, detalye ng proyekto
// Kasama sa coordenator.php (huwag buksan nang direkta).
defined('ROOT_PATH') || exit;
?>
<script>
    (function (PC) {
        'use strict';
        const { esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL, money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn, openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals, openProject, loadList, renderWorkspace, go } = PC;

        // ── OVERVIEW ──
        function renderOverview() {
            const p = PC.current.project, tl = PC.current.timeline;
            const done = tl.filter(t => t.progress >= 100).length;
            const delayed = tl.filter(isDelayed);
            const next = tl.filter(t => t.progress < 100).sort((a, b) => a.start_date.localeCompare(b.start_date))[0];
            const checks = Object.entries(PC.current.check_labels);
            const ticked = checks.filter(([k]) => PC.current.checks[k]).length;
            const card = (lbl, val, cls = 'text-gray-900') => `<div class="rounded-lg bg-gray-50 border border-gray-200 px-3 py-2.5"><p class="text-[10px] font-semibold uppercase tracking-wider text-gray-400">${lbl}</p><p class="text-sm font-semibold ${cls} mt-0.5 truncate">${val}</p></div>`;

            document.getElementById('pcTabBody').innerHTML = PC.stepsSummaryHtml() + `
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
                ${card('Tasks done', `${done} / ${tl.length}`)}
                ${card('Delayed', delayed.length, delayed.length ? 'text-red-600' : 'text-gray-900')}
                ${card('Schedule', tl.length ? `${fmt(tl.reduce((a, t) => a < t.start_date ? a : t.start_date, tl[0].start_date))} → ${fmt(tl.reduce((a, t) => a > t.end_date ? a : t.end_date, tl[0].end_date))}` : '—')}
                ${card('Next up', next ? esc(next.name) : (tl.length ? 'All done' : 'Plan the timeline'))}
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <p class="text-xs font-semibold text-gray-800"><i class="fa-solid fa-shield-halved text-amber-700 mr-1"></i> Important control points</p>
                        <span class="text-[11px] font-semibold text-gray-400">${ticked}/${checks.length}</span>
                    </div>
                    <ul class="rounded-lg border border-gray-200 divide-y divide-gray-100">
                        ${checks.map(([k, lbl]) => {
                            const at = PC.current.checks[k];
                            return `<li><label class="flex items-center gap-3 px-3 py-2.5 cursor-pointer hover:bg-gray-50">
                                <input type="checkbox" data-check="${k}" ${at ? 'checked' : ''} class="w-4 h-4 accent-green-600">
                                <span class="flex-1 text-xs ${at ? 'text-gray-400 line-through' : 'text-gray-700'}">${esc(lbl)}</span>
                                ${at ? `<span class="text-[10px] text-gray-400">${fmt(at)}</span>` : ''}
                            </label></li>`;
                        }).join('')}
                    </ul>
                </div>

                <div class="space-y-5">
                    <div>
                        <p class="text-xs font-semibold text-gray-800 mb-2"><i class="fa-solid fa-file-export text-amber-700 mr-1"></i> Transmittals</p>
                        <ul class="rounded-lg border border-gray-200 divide-y divide-gray-100">
                            ${PC.current.transmittals.length ? PC.current.transmittals.map(t => `
                                <li class="flex items-center justify-between gap-3 px-3 py-2.5">
                                    <div class="min-w-0">
                                        <a href="${TR_URL}?view=${t.id}" class="font-mono text-xs font-semibold text-gray-900 hover:text-amber-700 hover:underline">${esc(t.ref_no)}</a>
                                        <p class="text-[11px] text-gray-400 truncate">${esc(t.particulars || '—')}${t.req_no ? ' · ' + esc(t.req_no) : ''}</p>
                                    </div>
                                    ${t.delivered_at
                                        ? `<span class="shrink-0 text-[10px] font-bold text-green-700"><i class="fa-solid fa-truck mr-1"></i>${fmt(t.delivered_at)}</span>`
                                        : '<span class="shrink-0 text-[10px] font-bold text-orange-600">FOR DELIVERY</span>'}
                                </li>`).join('') : '<li class="px-3 py-4 text-center text-xs text-gray-400">No transmittals.</li>'}
                        </ul>
                    </div>
                    <div>
                        <p class="text-xs font-semibold text-gray-800 mb-2"><i class="fa-solid fa-circle-info text-amber-700 mr-1"></i> Project details</p>
                        <div class="space-y-2">
                            <input id="pcInfoLoc" value="${esc(p.location || '')}" placeholder="Location" maxlength="255" class="w-full border border-gray-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-600">
                            <input id="pcInfoScope" value="${esc(p.scope || '')}" placeholder="Scope" maxlength="255" class="w-full border border-gray-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-600">
                            <textarea id="pcInfoNotes" rows="3" placeholder="Notes (site conditions, working hours, access…)" maxlength="2000" class="w-full border border-gray-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-600 resize-none">${esc(p.notes || '')}</textarea>
                            <p id="pcInfoSaved" class="text-[10px] text-gray-400 h-3"></p>
                        </div>
                    </div>
                </div>
            </div>`;

            document.querySelectorAll('#pcTabBody [data-tab]').forEach(b => b.addEventListener('click', () => go(b.dataset.tab)));
            document.querySelectorAll('[data-check]').forEach(cb => cb.addEventListener('change', async () => {
                try {
                    const d = await api('toggle_check', { id: p.id, key: cb.dataset.check, value: cb.checked ? '1' : '0' }, true);
                    if (!d.success) throw new Error(d.message);
                    PC.current.checks = d.checks;
                    renderOverview();
                } catch (e) { cb.checked = !cb.checked; toast(e.message, 'error'); }
            }));
            let infoTimer = null;
            const saveInfo = () => {
                clearTimeout(infoTimer);
                infoTimer = setTimeout(async () => {
                    const loc = document.getElementById('pcInfoLoc').value.trim();
                    const scope = document.getElementById('pcInfoScope').value.trim();
                    const notes = document.getElementById('pcInfoNotes').value.trim();
                    try {
                        const d = await api('update_project', { id: p.id, location: loc, scope, notes }, true);
                        if (!d.success) throw new Error(d.message);
                        Object.assign(p, { location: loc, scope, notes });
                        document.getElementById('pcInfoSaved').textContent = 'Saved ' + new Date().toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' });
                    } catch (e) { toast(e.message, 'error'); }
                }, 700);
            };
            ['pcInfoLoc', 'pcInfoScope', 'pcInfoNotes'].forEach(id => document.getElementById(id).addEventListener('input', saveInfo));
        }


        PC.renders.overview = renderOverview;
    })(window.NHPC);
</script>
