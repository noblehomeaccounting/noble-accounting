<?php
// coordenator/pc-steps.php — Step by step: rail ng 8 hakbang, header ng bawat hakbang (What to do / Complete Step), at buod sa Overview
// Kasama sa coordenator.php (huwag buksan nang direkta).
defined('ROOT_PATH') || exit;
?>
<script>
    (function (PC) {
        'use strict';
        const { esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL, money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn, openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals, openProject, loadList, renderWorkspace, go } = PC;

        // ═════════════════════════════════════════════════════════
        //  STEP BY STEP: rail, header ng hakbang, at pag-close ng hakbang
        // ═════════════════════════════════════════════════════════
        const stepState = k => PC.current.steps?.[k] || { status: '', duties: [] };
        const stepClosed = k => ['done', 'na'].includes(stepState(k).status);
        const dutyAuto = (st, i) => { const f = st.duties[i][1]; try { return !!(f && f()); } catch (e) { return false; } };
        const dutyDone = (st, i) => dutyAuto(st, i) || stepState(st.key).duties.includes(i);
        const dutyCount = st => st.duties.filter((_, i) => dutyDone(st, i)).length;
        const currentStep = () => PC.stepList.find(st => !stepClosed(st.key));   // ang hakbang na dapat ginagawa ngayon
        const prevOpen = st => PC.stepList.filter(x => x.n < st.n && !stepClosed(x.key));

        function stepRail() {
            const cur = currentStep();
            const doneN = PC.stepList.filter(st => stepClosed(st.key)).length;
            const item = (t) => {
                const active = PC.tab === t.key;
                if (t.key === 'overview') return `<button type="button" data-tab="overview" class="flex items-center gap-2 rounded-lg px-2.5 py-2 text-left border ${active ? 'border-amber-600 bg-amber-50' : 'border-gray-200 hover:border-gray-300 bg-white'}">
                    <span class="w-7 h-7 rounded-full bg-gray-900 text-white flex items-center justify-center text-[10px] font-bold shrink-0">${doneN}/8</span>
                    <span class="min-w-0"><span class="block text-[9.5px] uppercase tracking-wider text-gray-400 font-semibold">Summary</span><span class="block text-[11.5px] font-semibold text-gray-800 truncate">Overview</span></span></button>`;
                const ss = stepState(t.key).status;
                const isCur = cur && cur.key === t.key;
                const circle = ss === 'done' ? 'bg-green-600 text-white' : ss === 'na' ? 'bg-gray-200 text-gray-500' : isCur ? 'bg-amber-600 text-white ring-4 ring-amber-100' : 'bg-white text-gray-400 border border-gray-300';
                const mark = ss === 'done' ? '✓' : ss === 'na' ? '–' : t.n;
                const sub = ss === 'done' ? 'Done' : ss === 'na' ? 'Not required' : isCur ? 'Current step' : `${dutyCount(t)}/${t.duties.length}`;
                return `<button type="button" data-tab="${t.key}" class="flex items-center gap-2 rounded-lg px-2.5 py-2 text-left border ${active ? 'border-amber-600 bg-amber-50' : 'border-gray-200 hover:border-gray-300 bg-white'}">
                    <span class="w-7 h-7 rounded-full ${circle} flex items-center justify-center text-[11px] font-bold shrink-0">${mark}</span>
                    <span class="min-w-0"><span class="block text-[9.5px] uppercase tracking-wider font-semibold ${ss === 'done' ? 'text-green-600' : isCur ? 'text-amber-700' : 'text-gray-400'}">Step ${t.n} · ${sub}</span>
                    <span class="block text-[11.5px] font-semibold text-gray-800 truncate">${t.label}${tabBadge(t)}</span></span></button>`;
            };
            return `<div class="px-4 py-3 border-b border-gray-100 bg-slate-50/60">
                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 2xl:grid-cols-9 gap-1.5">${[{ key: 'overview' }, ...PC.stepList].map(item).join('')}</div></div>`;
        }

        function renderStepHead() {
            const head = document.getElementById('pcStepHead');
            const st = PC.step(PC.tab);
            if (!st) { head.innerHTML = ''; return; }
            const state = stepState(st.key), closed = stepClosed(st.key);
            const n = dutyCount(st), all = n === st.duties.length;
            const blockers = prevOpen(st);
            const prev = PC.stepList[st.n - 2], next = PC.stepList[st.n];
            let action;
            if (closed) {
                action = `<div class="flex flex-wrap items-center gap-2">
                    <span class="inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold ${state.status === 'done' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-gray-100 text-gray-600 border border-gray-200'}">
                        <i class="fa-solid ${state.status === 'done' ? 'fa-circle-check' : 'fa-ban'}"></i>${state.status === 'done' ? 'Step completed' : 'Marked not required'}${state.completed_at ? ' · ' + fmtY(state.completed_at) : ''}${state.completed_by_name ? ' · ' + esc(state.completed_by_name) : ''}</span>
                    <button type="button" id="pcStepReopen" class="px-2.5 py-2 text-[11px] font-semibold text-gray-500 hover:text-amber-700 hover:bg-amber-50 rounded-lg">Reopen</button></div>`;
            } else if (blockers.length) {
                action = `<div class="rounded-lg bg-amber-50 border border-amber-200 px-3 py-2 text-[11px] text-amber-900"><i class="fa-solid fa-lock mr-1"></i> Close <b>Step ${blockers[0].n} · ${blockers[0].label}</b> first. You can already prepare the records here.</div>`;
            } else {
                action = `<div class="flex flex-wrap items-center gap-2">
                    ${st.optional ? `<button type="button" id="pcStepNA" class="px-3 py-2 text-xs font-semibold text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50">Not required</button>` : ''}
                    ${st.key === 'turnover' && !(PC.current.turnover && PC.current.turnover.turned_over_at) ? '<span class="text-[11px] text-gray-500">Complete the turnover below, then close this step.</span>' : ''}
                    <button type="button" id="pcStepDone" ${all ? '' : 'disabled'} class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-green-600 rounded-lg hover:bg-green-700 disabled:opacity-40 disabled:cursor-not-allowed"><i class="fa-solid fa-check"></i> Complete Step ${st.n}</button>
                    ${all ? '' : `<span class="text-[11px] text-gray-400">${st.duties.length - n} item${st.duties.length - n === 1 ? '' : 's'} left</span>`}</div>`;
            }
            head.innerHTML = `<div class="px-5 pt-5">
                <div class="rounded-xl border border-gray-200 overflow-hidden">
                    <div class="flex flex-wrap items-start justify-between gap-3 px-4 py-3 bg-gradient-to-r from-amber-50 to-white border-b border-gray-100">
                        <div class="min-w-0">
                            <p class="text-[10px] font-bold uppercase tracking-[0.15em] text-amber-700">Step ${st.n} of 8${st.optional ? ' · if required' : ''}</p>
                            <p class="text-base font-semibold text-gray-900">${st.label}</p>
                            <p class="text-[11.5px] text-gray-500">${st.role}</p>
                        </div>
                        <div class="flex items-center gap-1">
                            ${prev ? `<button type="button" data-tab="${prev.key}" class="px-2.5 py-1.5 text-[11px] font-semibold text-gray-500 bg-white border border-gray-200 rounded-lg hover:bg-gray-50" title="${prev.label}">← Step ${prev.n}</button>` : ''}
                            ${next ? `<button type="button" data-tab="${next.key}" class="px-2.5 py-1.5 text-[11px] font-semibold text-gray-500 bg-white border border-gray-200 rounded-lg hover:bg-gray-50" title="${next.label}">Step ${next.n} →</button>` : ''}
                        </div>
                    </div>
                    <div class="px-4 py-3">
                        <div class="flex items-center justify-between mb-2"><p class="text-[10px] font-semibold uppercase tracking-wider text-gray-400">What to do</p><p class="text-[11px] font-semibold ${all ? 'text-green-600' : 'text-gray-400'}">${n}/${st.duties.length}</p></div>
                        <ul class="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1">${st.duties.map((d, i) => {
                            const auto = dutyAuto(st, i), on = dutyDone(st, i);
                            return `<li><label class="flex items-start gap-2 rounded-md px-1.5 py-1 ${closed || auto ? '' : 'cursor-pointer hover:bg-gray-50'}">
                                <input type="checkbox" data-duty="${i}" ${on ? 'checked' : ''} ${closed || auto ? 'disabled' : ''} class="mt-0.5 w-3.5 h-3.5 accent-green-600 shrink-0">
                                <span class="text-[11.5px] leading-snug ${on ? 'text-gray-400 line-through' : 'text-gray-700'}">${d[0]}${auto ? ' <span class="no-underline inline-block ml-1 px-1.5 rounded bg-sky-50 text-sky-700 text-[9px] font-bold align-middle" style="text-decoration:none">AUTO</span>' : ''}</span></label></li>`;
                        }).join('')}</ul>
                        <p class="mt-3 rounded-lg bg-slate-50 border border-slate-200 px-3 py-2 text-[11px] text-slate-600"><i class="fa-solid fa-link text-slate-400 mr-1"></i><b>Process connection:</b> ${st.link}</p>
                        <div class="mt-3">${action}</div>
                    </div>
                </div></div>`;

            head.querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => go(b.dataset.tab)));
            head.querySelectorAll('[data-duty]').forEach(cb => cb.addEventListener('change', async () => {
                try {
                    const d = await must(await post('step_duty', { step: st.key, index: cb.dataset.duty, value: cb.checked ? '1' : '0' }));
                    PC.current.steps[st.key].duties = d.duties;
                    renderWorkspace();
                } catch (e) { cb.checked = !cb.checked; toast(e.message, 'error'); }
            }));
            const setStatus = async (status, msg) => {
                try {
                    const d = await must(await post('step_status', { step: st.key, status }));
                    PC.current.steps = d.steps;
                    toast(msg);
                    const nx = (status === 'done' || status === 'na') ? currentStep() : null;
                    nx ? go(nx.key) : renderWorkspace(); loadList();
                } catch (e) { toast(e.message, 'error'); }
            };
            if (F('pcStepDone')) F('pcStepDone').addEventListener('click', () => setStatus('done', `Step ${st.n} completed.`));
            if (F('pcStepNA')) F('pcStepNA').addEventListener('click', () => openForm({
                title: `Mark Step ${st.n} as not required?`, saveLabel: 'Not required',
                body: `<p class="text-xs text-gray-600">Use this only if <b>${st.label}</b> is not needed for this project (e.g. the building does not require permits).</p>`,
                onSave: async () => { await setStatus('na', `Step ${st.n} marked not required.`); },
            }));
            if (F('pcStepReopen')) F('pcStepReopen').addEventListener('click', () => setStatus('', `Step ${st.n} reopened.`));
        }

        // Overview: buod ng 8 hakbang
        function stepsSummaryHtml() {
            const cur = currentStep();
            return `<div class="mb-5 rounded-xl border border-gray-200 overflow-hidden">
                <div class="flex items-center justify-between px-4 py-2.5 bg-gray-50 border-b border-gray-100">
                    <p class="text-xs font-semibold text-gray-800"><i class="fa-solid fa-route text-amber-700 mr-1"></i> Operations — step by step</p>
                    <p class="text-[11px] text-gray-500">${cur ? `Now: <b class="text-amber-700">Step ${cur.n} · ${cur.label}</b>` : '<b class="text-green-600">All steps completed</b>'}</p>
                </div>
                <ol class="divide-y divide-gray-100">${PC.stepList.map(st => {
                    const ss = stepState(st.key).status, n = dutyCount(st), isCur = cur && cur.key === st.key;
                    return `<li><button type="button" data-tab="${st.key}" class="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-amber-50/40 ${isCur ? 'bg-amber-50/60' : ''}">
                        <span class="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${ss === 'done' ? 'bg-green-600 text-white' : ss === 'na' ? 'bg-gray-200 text-gray-500' : isCur ? 'bg-amber-600 text-white' : 'border border-gray-300 text-gray-400'}">${ss === 'done' ? '✓' : ss === 'na' ? '–' : st.n}</span>
                        <span class="flex-1 min-w-0"><span class="block text-xs font-semibold text-gray-800 truncate">${st.label}${st.optional ? ' <span class="font-normal text-gray-400">(if required)</span>' : ''}</span>
                            <span class="block h-1 mt-1 rounded-full bg-gray-100 overflow-hidden"><span class="block h-full ${ss === 'done' ? 'bg-green-500' : ss === 'na' ? 'bg-gray-300' : 'bg-amber-500'}" style="width:${ss ? 100 : Math.round(n / st.duties.length * 100)}%"></span></span></span>
                        <span class="text-[10.5px] font-semibold w-24 text-right ${ss === 'done' ? 'text-green-600' : ss === 'na' ? 'text-gray-400' : isCur ? 'text-amber-700' : 'text-gray-400'}">${ss === 'done' ? 'Done' : ss === 'na' ? 'Not required' : `${n}/${st.duties.length}`}</span>
                    </button></li>`;
                }).join('')}</ol></div>`;
        }

        // maliit na bilang sa step kapag may kailangang asikasuhin (ibinibigay ng bawat step file)
        function tabBadge(st) {
            const n = PC.current && st.badge ? st.badge() : 0;
            return n ? `<span class="ml-0.5 min-w-[16px] h-4 px-1 inline-flex items-center justify-center rounded-full bg-amber-100 text-amber-800 text-[9px] font-bold">${n}</span>` : '';
        }

        Object.assign(PC, { stepState, stepClosed, prevOpen, currentStep, dutyCount, stepRail, renderStepHead, stepsSummaryHtml });
    })(window.NHPC);
</script>
