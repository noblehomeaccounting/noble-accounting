<?php
// coordenator/step8-turnover.php — STEP 8: Turnover (readiness, turnover letter, complete turnover) + Project Completion
// Kasama sa coordenator.php (huwag buksan nang direkta).
defined('ROOT_PATH') || exit;
?>
<script>
    (function (PC) {
        'use strict';
        const { esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL, money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn, openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals, openProject, loadList, renderWorkspace, go } = PC;
        const { stepState, stepClosed, prevOpen, currentStep, dutyCount } = PC;

        // ── Kahulugan ng hakbang (galing sa F. Operations) ──
        PC.defineStep({ key: 'turnover', n: 8, label: 'Turnover', icon: 'fa-handshake',
            role: 'Formally hand over the completed project and close it out.',
            link: 'Turnover formally hands over the completed project to the client and provides documentation for project closeout.',
            duties: [
                ['Confirm completion of the agreed scope of work', () => PC.current.timeline.length > 0 && PC.current.timeline.every(t => t.progress >= 100)],
                ['Verify that punch list items are completed or formally documented as agreed', () => PC.current.punch.every(x => x.status === 'Verified') && PC.current.steps.punch.status === 'done'],
                ['Prepare turnover documents, warranties, manuals, and inspection records', () => !!(PC.current.turnover && PC.current.turnover.documents)],
                ['Coordinate final inspection and acceptance with the client'],
                ['Obtain required turnover signatures', () => !!(PC.current.turnover && PC.current.turnover.turned_over_at)],
                ['Endorse closeout documents to the concerned departments (Accounting, management)'],
                ['Archive project records and endorse outstanding financial or administrative matters'],
            ],
            render: renderTurnover,
        });

        // ═════════════════════════════════════════════════════════
        //  STEP 8 · TURNOVER
        // ═════════════════════════════════════════════════════════
        function turnoverReadiness() {
            const openPunch = PC.current.punch.filter(x => x.status !== 'Verified').length;
            const undelivered = PC.current.deliveries.filter(d => d.status !== 'Delivered').length;
            const tasksLeft = PC.current.timeline.filter(t => t.progress < 100).length;
            const unpaid = PC.current.billings.filter(b => b.status !== 'Paid').length;
            const open = prevOpen(PC.step('turnover'));
            return [
                { ok: !open.length, txt: open.length ? `Close Step ${open.map(x => x.n).join(', ')} first` : 'Steps 1–7 closed', block: true },
                { ok: !openPunch, txt: openPunch ? `${openPunch} punch list item(s) not yet verified` : 'Punch list cleared', block: true },
                { ok: !undelivered, txt: undelivered ? `${undelivered} delivery receipt(s) not yet delivered` : 'All deliveries received' },
                { ok: PC.current.timeline.length > 0 && !tasksLeft, txt: !PC.current.timeline.length ? 'No timeline tasks yet' : tasksLeft ? `${tasksLeft} timeline task(s) not at 100%` : 'Timeline complete' },
                { ok: !unpaid, txt: unpaid ? `${unpaid} progress billing(s) not yet paid` : 'Progress billings settled' },
            ];
        }
        function turnoverDefaults() {
            const p = P(), q = PC.current.quotes[0];
            const items = q ? PC.quoteGroups(q).map(g => ({ scope: `${g.sec || 'WORKS'} (${g.items.map(i => i.item_name).join(', ')})`.toUpperCase(), area: '', status: 'Accomplished' }))
                : [...new Set(PC.current.timeline.map(t => t.category))].filter(c => !/PLAN|HAND OVER/i.test(c)).map(c => ({ scope: c, area: '', status: 'Accomplished' }));
            return { turnover_date: todayISO(), project_name: (p.scope || '').toUpperCase(), location: p.location || '', contractor: 'Noblehome Construction Company',
                owner_name: p.client_name, owner_title: 'Owner', signatory_name: 'Mr. Ken Yang', signatory_title: 'General Manager', documents: '', items: items.length ? items : [{ scope: '', area: '', status: 'Accomplished' }] };
        }
        function renderTurnover() {
            const tv = PC.current.turnover, ready = turnoverReadiness(), blocked = ready.some(r => r.block && !r.ok);
            const stepsOpen = prevOpen(PC.step('turnover'));
            const body = document.getElementById('pcTabBody');
            const done = tv && tv.turned_over_at;
            body.innerHTML = sectionHead('Turnover', 'Final inspection, acceptance and turnover documents.',
                    tv ? `<div class="flex gap-2"><button type="button" id="pcTvView" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-gray-700 bg-white border border-gray-200 rounded-lg hover:bg-gray-50"><i class="fa-solid fa-print"></i> View / Print Letter</button>${done ? '' : `<button type="button" id="pcTvEdit" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 rounded-lg hover:bg-amber-100"><i class="fa-solid fa-pen"></i> Edit Letter</button>`}</div>` : addBtn('pcTvNew', 'Prepare Turnover Letter'))
                + (done ? `<div class="mb-4 rounded-xl border border-green-200 bg-green-50 px-4 py-3 flex items-center gap-3"><i class="fa-solid fa-circle-check text-green-600 text-xl"></i><div><p class="text-sm font-semibold text-green-800">Turned over on ${fmtY(tv.turned_over_at)}</p><p class="text-[11px] text-green-700">Endorse the closeout documents to Accounting and management, archive the records, then complete Step 8 above.</p></div></div>` : '')
                + `<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div class="rounded-lg border border-gray-200"><p class="px-3 py-2.5 border-b border-gray-100 text-xs font-semibold text-gray-800"><i class="fa-solid fa-clipboard-check text-amber-700 mr-1"></i> Readiness</p>
                        <ul class="divide-y divide-gray-100">${ready.map(r => `<li class="flex items-center gap-2.5 px-3 py-2 text-xs ${r.ok ? 'text-gray-600' : r.block ? 'text-red-600 font-semibold' : 'text-amber-700'}"><i class="fa-solid ${r.ok ? 'fa-circle-check text-green-500' : r.block ? 'fa-circle-xmark' : 'fa-circle-exclamation'}"></i>${r.txt}${r.block && !r.ok ? ' <span class="text-[10px] font-normal">(required)</span>' : ''}</li>`).join('')}</ul></div>
                    <div class="rounded-lg border border-gray-200 p-4">
                        ${tv ? `<p class="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Letter</p><p class="text-sm font-semibold text-gray-900">${esc(tv.project_name || '')}</p><p class="text-[11px] text-gray-500">${fmtY(tv.turnover_date)} · ${tv.items.length} scope item${tv.items.length === 1 ? '' : 's'} · conforme: ${esc(tv.owner_name || '')}</p>`
                            : '<p class="text-xs text-gray-500">Prepare the turnover letter, print it, and have the client sign the conforme.</p>'}
                        ${!done && tv ? `<button type="button" id="pcTvComplete" ${blocked ? 'disabled' : ''} class="mt-4 w-full inline-flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-semibold text-white bg-green-600 rounded-lg hover:bg-green-700 disabled:opacity-40 disabled:cursor-not-allowed"><i class="fa-solid fa-handshake"></i> Complete Turnover</button>
                            ${blocked ? `<p class="mt-2 text-[10.5px] text-red-600 text-center">${stepsOpen.length ? `Close Step ${stepsOpen[0].n} · ${stepsOpen[0].label} first.` : 'Clear the punch list first.'}</p>` : ''}` : ''}
                    </div>
                </div>`;
            if (F('pcTvNew')) F('pcTvNew').addEventListener('click', () => turnoverForm(turnoverDefaults()));
            if (F('pcTvEdit')) F('pcTvEdit').addEventListener('click', () => turnoverForm(tv));
            if (F('pcTvView')) F('pcTvView').addEventListener('click', () => previewDoc('Turnover Letter', turnoverDoc(tv)));
            if (F('pcTvComplete')) F('pcTvComplete').addEventListener('click', () => openForm({
                title: 'Complete turnover?', saveLabel: 'Complete Turnover',
                body: `<div class="grid grid-cols-1 gap-3"><label>${lbl('Date accepted by client', 1)}<input type="date" name="accepted_at" value="${todayISO()}" max="${todayISO()}" class="${inputCls}"></label>
                    <label class="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 text-[11px] text-amber-900 cursor-pointer"><input type="checkbox" name="confirm" class="mt-0.5 w-4 h-4 accent-green-600"> The client has inspected the works and signed the turnover letter (conforme). This closes the project and can't be undone.</label></div>`,
                onSave: async err => {
                    if (fv('confirm') !== '1') return err('Please confirm the client has signed.'), false;
                    await must(await post('complete_turnover', { accepted_at: fv('accepted_at'), confirm: '1' }));
                    toast('Project turned over and closed.');
                    await reload();
                },
            }));
        }
        const TV_COLS = [
            { name: 'scope', label: 'Completed works scope', ph: 'e.g. CLOSET (WARDROBE, INNER CABINET)', w: '58%' },
            { name: 'area', label: 'Area', ph: 'e.g. BEDROOM', w: '20%' },
            { name: 'item_status', label: 'Status', ph: 'Accomplished', w: '18%' },
        ];
        function turnoverForm(tv) {
            const rows = (tv.items || []).map(i => ({ scope: i.scope, area: i.area, item_status: i.status }));
            const f = (n, l, req, extra = '') => `<label>${lbl(l, req)}<input name="${n}" value="${esc(tv[n] || '')}" maxlength="255" class="${inputCls}" ${extra}></label>`;
            openForm({
                title: 'Turnover Letter', wide: true, saveLabel: 'Save Letter',
                body: `<div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                        <label>${lbl('Date', 1)}<input type="date" name="turnover_date" value="${tv.turnover_date || todayISO()}" class="${inputCls}"></label>
                        ${f('project_name', 'Project', 1)}<div class="col-span-2">${f('location', 'Project location')}</div>
                        <div class="col-span-2">${f('contractor', 'Contractor / Subcontractor')}</div>${f('owner_name', 'Conforme (client)', 1)}${f('owner_title', 'Client title')}
                        ${f('signatory_name', 'Signed by')}${f('signatory_title', 'Title')}
                    </div>
                    ${itemTable('pcTvItems', TV_COLS, rows, 'Add scope')}
                    <label class="block mt-4">${lbl('Turnover documents included (warranties, manuals, inspection records)')}<textarea name="documents" rows="2" maxlength="1000" class="${inputCls} resize-none">${esc(tv.documents || '')}</textarea></label>`,
                onOpen: () => wireItemTable('pcTvItems', TV_COLS),
                onSave: async err => {
                    const scope = tableVals('pcTvItems', 'scope');
                    if (!scope.some(Boolean)) return err('Add at least one completed work scope.'), false;
                    const d = { scope, area: tableVals('pcTvItems', 'area'), item_status: tableVals('pcTvItems', 'item_status') };
                    ['turnover_date', 'project_name', 'location', 'contractor', 'owner_name', 'owner_title', 'signatory_name', 'signatory_title', 'documents'].forEach(k => d[k] = fv(k));
                    if (!d.project_name || !d.owner_name) return err('Project and conforme name are required.'), false;
                    await must(await post('save_turnover', d));
                    toast('Turnover letter saved.');
                    await reload();
                },
            });
        }
        function turnoverDoc(tv) {
            return `<div class="pcdoc pctv">
                <table class="nb"><tr><td style="width:120px"><img src="${LOGO}" alt="" style="width:105px"></td><td class="hd">NOBLEHOME CONSTRUCTION COMPANY<br>1181 MC PREMIERE BRGY. BALINGASA QUEZON CITY</td></tr></table>
                <p class="ttl">CONSTRUCTION PROJECT TURNOVER LETTER</p>
                <p>Date : ${esc(fmtLong(tv.turnover_date))}</p>
                <p style="margin-top:12px">Project : ${esc(tv.project_name || '')}<br>Project Location: ${esc(tv.location || '')}<br>Contractor/Subcontractor: ${esc(tv.contractor || '')}</p>
                <p style="margin-top:12px">SUBJECT: <b>TURNOVER OF COMPLETED CONSTRUCTION WORKS</b></p>
                <p style="margin-top:12px">Dear Sir/Madam,</p>
                <p>This letter serves as the formal turnover of the completed construction works.</p>
                <table class="tbl"><colgroup><col style="width:56%"><col style="width:24%"><col style="width:20%"></colgroup>
                    <tr><td>COMPLETED WORKS SCOPE</td><td>AREA</td><td>STATUS</td></tr>
                    ${(tv.items || []).map(i => `<tr><td>• ${esc(i.scope)}</td><td>${esc(i.area)}</td><td>${esc(i.status)}</td></tr>`).join('')}
                </table>
                <p>We hereby confirm that the following works have been completed in accordance with the approved plans, specifications, and the agreed scope of work. The completed areas have been inspected, cleaned, and cleared of construction debris and excess materials.</p>
                <p>We respectfully request your final inspection, acceptance, and turnover of the completed works. Any remaining punch-list items identified during the inspection will be rectified accordingly.</p>
                ${tv.documents ? `<p>Turnover documents included: ${esc(tv.documents)}</p>` : ''}
                <p>Thank you for your cooperation and support throughout the completion of the project.</p>
                <p style="margin-top:14px">Respectfully,</p>
                <p style="margin-top:26px">${esc(tv.signatory_name || '')}<br>${esc(tv.signatory_title || '')}<br>Noblehome Construction Corporation</p>
                <p style="margin-top:18px">CONFORME / ACCEPTED BY:</p>
                <p style="margin-top:26px">${esc(tv.owner_name || '')}<br>${esc(tv.owner_title || 'Owner')}</p>
            </div>`;
        }

    })(window.NHPC);
</script>
