<?php
// coordenator/pc-core.php — state, api, helpers, project list, workspace, generic form modal at print
defined('ROOT_PATH') || exit;
?>
<script>
    (function () {
        'use strict';
        const AJAX = <?= json_encode($pcAjaxUrl) ?>;
        const LOGO = <?= json_encode(BASE_URL . '/icon/logo.webp') ?>;
        const TR_URL = <?= json_encode(BASE_URL . '/transmittal') ?>;

        let projects = [], statuses = [], filter = 'Ongoing';
        let current = null;          // buong data ng bukas na proyekto (galing sa ?action=view)
        let tab = 'overview';

        // ── shared na lalagyan: dito kumukuha ang bawat step file ──
        const PC = window.NHPC = {
            renders: {},           // tab key → render function
            stepList: [],            // mga hakbang (step1…step8), naka-ayos ayon sa n
            defineStep(def) { this.stepList.push(def); this.stepList.sort((a, b) => a.n - b.n); this.renders[def.key] = def.render; },
            step(key) { return this.stepList.find(s => s.key === key); },
            get current() { return current; },
            get tab() { return tab; },
        };
        const F = id => document.getElementById(id);
        // lumipat sa ibang tab / step
        function go(key) { tab = key; memo.set('tab', tab); renderWorkspace(); }

        // ── helpers ──
        const esc = s => { const d = document.createElement('div'); d.textContent = s ?? ''; return d.innerHTML; };
        const DAY = 86400000;
        const toD = s => { const [y, m, d] = String(s).slice(0, 10).split('-').map(Number); return new Date(y, m - 1, d); };
        const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        const todayISO = () => ymd(new Date());
        const days = (a, b) => Math.round((toD(b) - toD(a)) / DAY) + 1;
        const fmt = s => s ? toD(s).toLocaleDateString('en-PH', { month: 'short', day: 'numeric' }) : '—';
        const fmtY = s => s ? toD(s).toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';
        const isDelayed = t => t.progress < 100 && t.end_date < todayISO();

        function toast(message, type = 'success', duration = 3500) {
            const box = document.getElementById('crmToastContainer');
            const p = type === 'success'
                ? { wrap: 'bg-green-50 border-green-200 text-green-700', icon: 'bg-green-200 text-green-700', sym: '✓' }
                : { wrap: 'bg-red-50 border-red-200 text-red-700', icon: 'bg-red-200 text-red-700', sym: '!' };
            const t = document.createElement('div');
            t.className = `pointer-events-auto flex items-start gap-2.5 border rounded-lg shadow-lg px-4 py-3 text-sm ${p.wrap} transition-all duration-300`;
            t.innerHTML = `<span class="shrink-0 inline-flex items-center justify-center w-5 h-5 rounded-full text-xs font-bold ${p.icon}">${p.sym}</span><span class="flex-1 leading-relaxed"></span>`;
            t.querySelector('.flex-1').textContent = message;
            box.appendChild(t);
            setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, duration);
        }

        async function api(action, params = {}, post = false) {
            const ctrl = new AbortController();
            const timer = setTimeout(() => ctrl.abort(), 15000);
            try {
                // sinusuportahan ang arrays → key[]=a&key[]=b (para sa item rows)
                const qs = new URLSearchParams();
                Object.entries(params).forEach(([k, v]) => Array.isArray(v) ? v.forEach(x => qs.append(k + '[]', x ?? '')) : qs.append(k, v ?? ''));
                const url = post ? `${AJAX}?action=${action}` : `${AJAX}?action=${action}&${qs}`;
                const res = await fetch(url, post
                    ? { method: 'POST', body: qs, signal: ctrl.signal, cache: 'no-store' }
                    : { signal: ctrl.signal, cache: 'no-store' });
                const text = await res.text();
                try { return JSON.parse(text); }
                catch (e) { throw new Error(/login|<form/i.test(text) ? 'Your session may have expired. Please reload the page.' : 'The server sent an unexpected response.'); }
            } catch (e) {
                throw new Error(e.name === 'AbortError' ? 'The server took too long to respond.' : e.message);
            } finally { clearTimeout(timer); }
        }

        const memo = {
            get: k => { try { return localStorage.getItem('nh-pc-' + k); } catch (e) { return null; } },
            set: (k, v) => { try { localStorage.setItem('nh-pc-' + k, v); } catch (e) { } },
        };

        const STATUS_STYLE = {
            'Ongoing':      'bg-amber-50 text-amber-700 ring-amber-600/20',
            'For Turnover': 'bg-sky-50 text-sky-700 ring-sky-600/20',
            'Closed':       'bg-green-50 text-green-700 ring-green-600/20',
        };

        // ═════════════ PROJECT LIST ═════════════
        function renderFilter() {
            const opts = ['Ongoing', 'For Turnover', 'Closed', 'All'];
            document.getElementById('pcStatusFilter').innerHTML = opts.map(o => {
                const n = o === 'All' ? projects.length : projects.filter(p => p.status === o).length;
                const on = filter === o;
                return `<button type="button" data-filter="${o}" class="flex-1 px-1.5 py-1.5 rounded-md text-[10.5px] font-semibold whitespace-nowrap ${on ? 'bg-white shadow-sm text-amber-700' : 'text-gray-500 hover:text-gray-700'}">${o === 'For Turnover' ? 'Turnover' : o} <span class="text-gray-400">${n}</span></button>`;
            }).join('');
        }
        document.getElementById('pcStatusFilter').addEventListener('click', e => {
            const b = e.target.closest('[data-filter]');
            if (!b) return;
            filter = b.dataset.filter; memo.set('filter', filter);
            renderList();
        });
        document.getElementById('pcSearch').addEventListener('input', renderList);

        function renderList() {
            renderFilter();
            const q = document.getElementById('pcSearch').value.trim().toLowerCase();
            const list = projects.filter(p => (filter === 'All' || p.status === filter)
                && (!q || `${p.client_name} ${p.bom_number ?? ''} ${p.location ?? ''} ${p.scope ?? ''}`.toLowerCase().includes(q)));
            const box = document.getElementById('pcList');
            if (!list.length) {
                box.innerHTML = `<li class="px-4 py-10 text-center text-xs text-gray-400"><i class="fa-regular fa-folder-open text-2xl text-gray-300 block mb-2"></i>${projects.length ? 'No projects here.' : 'No projects yet. They appear once a transmittal is delivered.'}</li>`;
                return;
            }
            box.innerHTML = list.map(p => {
                const on = current && current.project.id === p.id;
                return `
                <li><button type="button" data-open="${p.id}" class="w-full text-left px-4 py-3 transition-colors ${on ? 'bg-amber-50 shadow-[inset_3px_0_0_#b45309]' : 'hover:bg-gray-50'}">
                    <div class="flex items-start justify-between gap-2">
                        <p class="text-sm font-semibold text-gray-900 truncate">${esc(p.client_name)}</p>
                        ${p.delayed_count ? `<span class="shrink-0 inline-flex items-center gap-1 text-[10px] font-bold text-red-600"><i class="fa-solid fa-triangle-exclamation"></i>${p.delayed_count}</span>` : ''}
                    </div>
                    <p class="text-[11px] text-gray-400 truncate"><span class="font-mono">${esc(p.bom_number || '—')}</span>${p.location ? ' · ' + esc(p.location) : ''}</p>
                    <div class="mt-2 flex items-center gap-2">
                        <div class="flex-1 h-1.5 rounded-full bg-gray-100 overflow-hidden"><div class="h-full rounded-full ${p.progress >= 100 ? 'bg-green-500' : 'bg-amber-600'}" style="width:${p.progress}%"></div></div>
                        <span class="text-[10px] font-semibold text-gray-500 tabular-nums w-8 text-right">${p.progress}%</span>
                    </div>
                    <p class="mt-1 text-[10px] text-gray-400">${p.task_count ? `${fmt(p.start_date)} → ${fmt(p.end_date)}` : 'No timeline yet'}</p>
                </button></li>`;
            }).join('');
        }
        document.getElementById('pcList').addEventListener('click', e => {
            const b = e.target.closest('[data-open]');
            if (b) openProject(+b.dataset.open);
        });

        async function loadList() {
            try {
                const d = await api('list');
                if (!d.success) throw new Error(d.message || 'Failed to load projects.');
                projects = d.rows; statuses = d.statuses;
                document.getElementById('pcStatOngoing').textContent = projects.filter(p => p.status === 'Ongoing').length;
                document.getElementById('pcStatDelayed').textContent = projects.filter(p => p.delayed_count > 0 && p.status !== 'Closed').length;
                document.getElementById('pcStatTurnover').textContent = projects.filter(p => p.status === 'For Turnover').length;
                renderList();
            } catch (e) {
                document.getElementById('pcList').innerHTML = `<li class="px-4 py-10 text-center text-xs text-red-600">${esc(e.message)}<br><button type="button" id="pcRetry" class="mt-2 font-semibold text-amber-700 hover:underline">Retry</button></li>`;
                document.getElementById('pcRetry').addEventListener('click', loadList);
            }
        }

        // ═════════════ WORKSPACE ═════════════
        async function openProject(id, keepTab = false) {
            if (!keepTab) document.getElementById('pcWorkspace').innerHTML = '<div class="bg-white border border-gray-200 rounded-xl px-6 py-16 text-center text-xs text-gray-400"><i class="fa-solid fa-spinner fa-spin mr-1"></i> Loading…</div>';
            try {
                const d = await api('view', { id });
                if (!d.success) throw new Error(d.message);
                current = d;
                memo.set('project', id);
                renderWorkspace();
                renderList();
            } catch (e) { toast(e.message, 'error'); }
        }

        function projectProgress() {
            const tl = current.timeline;
            return tl.length ? Math.round(tl.reduce((a, t) => a + t.progress, 0) / tl.length) : 0;
        }

        function renderWorkspace() {
            const p = current.project;
            const prog = projectProgress();
            const ring = `conic-gradient(${prog >= 100 ? '#22c55e' : '#b45309'} ${prog * 3.6}deg, #f1f5f9 0)`;
            document.getElementById('pcWorkspace').innerHTML = `
            <div class="bg-white border border-gray-200 rounded-xl overflow-hidden">
                <div class="px-5 py-4 border-b border-gray-100 flex flex-wrap items-center gap-4">
                    <div class="w-14 h-14 rounded-full p-1 shrink-0" style="background:${ring}">
                        <div class="w-full h-full rounded-full bg-white flex items-center justify-center text-xs font-bold text-gray-800 tabular-nums">${prog}%</div>
                    </div>
                    <div class="min-w-0 flex-1">
                        <p class="text-[10px] font-semibold uppercase tracking-wider text-gray-400"><span class="font-mono">${esc(p.bom_number || '')}</span>${p.control_no ? ' · ' + esc(p.control_no) : ''}</p>
                        <h2 class="text-lg font-semibold text-gray-900 truncate">${esc(p.client_name)}</h2>
                        <p class="text-xs text-gray-500 truncate"><i class="fa-solid fa-location-dot text-amber-700 mr-1"></i>${esc(p.location || 'No location')}</p>
                    </div>
                    <label class="shrink-0">
                        <span class="block text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-1">Status</span>
                        <select id="pcStatus" class="rounded-lg px-3 py-1.5 text-xs font-semibold ring-1 ${STATUS_STYLE[p.status] || ''} outline-none">
                            ${statuses.map(s => `<option ${s === p.status ? 'selected' : ''}>${s}</option>`).join('')}
                        </select>
                    </label>
                </div>
                ${PC.stepRail()}
                <div id="pcStepHead"></div>
                <div id="pcTabBody" class="p-5"></div>
            </div>`;

            document.getElementById('pcStatus').addEventListener('change', async e => {
                try {
                    const d = await api('update_project', { id: p.id, status: e.target.value }, true);
                    if (!d.success) throw new Error(d.message);
                    p.status = e.target.value;
                    toast(`Status set to ${p.status}.`);
                    loadList(); renderWorkspace();
                } catch (err) { toast(err.message, 'error'); }
            });
            document.querySelectorAll('#pcWorkspace [data-tab]').forEach(b => b.addEventListener('click', () => go(b.dataset.tab)));
            if (!PC.renders[tab]) tab = 'overview';
            PC.renderStepHead();
            PC.renders[tab]();
        }


        // ═════════════════════════════════════════════════════════
        //  SHARED: generic modal, confirm, print, money
        // ═════════════════════════════════════════════════════════
        const money = n => (Number(n) || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        const num = v => Number(String(v ?? '').replace(/,/g, '')) || 0;
        const qtyFmt = q => { const n = parseFloat(q); return isNaN(n) ? '' : String(+n.toFixed(2)); };
        const P = () => current.project;
        const post = (action, params) => api(action, Object.assign({ project_id: P().id }, params), true);
        async function reload() { await openProject(P().id, true); loadList(); }
        const inputCls = 'w-full border border-gray-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-600';
        const lbl = (t, req) => `<span class="block text-[10px] font-semibold uppercase tracking-wider text-gray-500 mb-1">${t}${req ? ' <span class="text-red-500">*</span>' : ''}</span>`;
        const pill = (txt, color) => `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ring-1 ${color}">${esc(txt)}</span>`;
        const PILL = {
            green: 'bg-green-50 text-green-700 ring-green-600/20', amber: 'bg-amber-50 text-amber-700 ring-amber-600/20',
            sky: 'bg-sky-50 text-sky-700 ring-sky-600/20', red: 'bg-red-50 text-red-600 ring-red-600/20', gray: 'bg-gray-50 text-gray-500 ring-gray-400/30',
            violet: 'bg-violet-50 text-violet-700 ring-violet-600/20',
        };
        const emptyBox = (icon, title, sub) => `<div class="rounded-xl border-2 border-dashed border-gray-200 px-6 py-10 text-center"><i class="fa-solid ${icon} text-3xl text-gray-300 mb-3"></i><p class="text-sm font-semibold text-gray-700">${title}</p><p class="text-xs text-gray-400 mt-1">${sub}</p></div>`;
        const sectionHead = (title, sub, btn = '') => `<div class="flex flex-wrap items-end justify-between gap-2 mb-4"><div><p class="text-sm font-semibold text-gray-900">${title}</p><p class="text-[11px] text-gray-400">${sub}</p></div>${btn}</div>`;
        const addBtn = (id, label) => `<button type="button" id="${id}" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-amber-700 rounded-lg hover:bg-amber-800 shadow-sm"><i class="fa-solid fa-plus"></i> ${label}</button>`;
        const iconBtn = (attr, icon, title, cls = 'text-gray-500 hover:text-amber-700 hover:bg-amber-50') => `<button type="button" ${attr} title="${title}" class="w-7 h-7 inline-flex items-center justify-center rounded-md ${cls}"><i class="fa-solid ${icon} text-[11px]"></i></button>`;

        // generic form modal
        const FM = document.getElementById('pcFormModal');
        let fmSave = null, fmDelete = null;
        function openForm({ title, body, wide = false, saveLabel = 'Save', onSave, onDelete, onOpen }) {
            F('pcFormTitle').textContent = title;
            F('pcFormBody').innerHTML = body;
            F('pcFormBox').className = `bg-white rounded-xl shadow-xl w-full ${wide ? 'max-w-4xl' : 'max-w-lg'} my-auto overflow-hidden`;
            F('pcFormSave').innerHTML = `<i class="fa-solid fa-check mr-1"></i> ${saveLabel}`;
            F('pcFormSave').classList.toggle('hidden', !onSave);
            fmSave = onSave; fmDelete = onDelete;
            formErr('');
            F('pcFormDel').innerHTML = onDelete ? '<button type="button" id="pcFormDelBtn" class="px-3 py-2 text-[11px] font-semibold text-red-600 hover:bg-red-50 rounded-lg"><i class="fa-solid fa-trash mr-1"></i>Delete</button>' : '';
            if (onDelete) F('pcFormDelBtn').addEventListener('click', askFormDelete);
            FM.classList.remove('hidden'); FM.classList.add('flex');
            if (onOpen) onOpen(F('pcFormBody'));
            const first = F('pcFormBody').querySelector('input:not([type=hidden]):not([readonly]), select, textarea');
            if (first) setTimeout(() => first.focus(), 50);
        }
        const closeForm = () => { FM.classList.add('hidden'); FM.classList.remove('flex'); };
        const formErr = msg => { F('pcFormError').textContent = msg || ''; F('pcFormError').classList.toggle('hidden', !msg); };
        function askFormDelete() {
            F('pcFormDel').innerHTML = `<span class="text-[11px] text-red-700 mr-1">Delete this?</span>
                <button type="button" id="pcFormDelYes" class="px-2.5 py-1.5 text-[11px] font-semibold text-white bg-red-600 rounded-md hover:bg-red-700">Delete</button>
                <button type="button" id="pcFormDelNo" class="px-2 py-1.5 text-[11px] font-semibold text-gray-500 hover:bg-gray-100 rounded-md">No</button>`;
            F('pcFormDelNo').addEventListener('click', () => { F('pcFormDel').innerHTML = '<button type="button" id="pcFormDelBtn" class="px-3 py-2 text-[11px] font-semibold text-red-600 hover:bg-red-50 rounded-lg"><i class="fa-solid fa-trash mr-1"></i>Delete</button>'; F('pcFormDelBtn').addEventListener('click', askFormDelete); });
            F('pcFormDelYes').addEventListener('click', async () => {
                try { await fmDelete(); closeForm(); } catch (e) { formErr(e.message); }
            });
        }
        document.querySelectorAll('[data-close="pcFormModal"]').forEach(b => b.addEventListener('click', closeForm));
        FM.addEventListener('click', e => { if (e.target === FM) closeForm(); });
        document.addEventListener('keydown', e => { if (e.key === 'Escape') closeForm(); });
        F('pcFormSave').addEventListener('click', async function () {
            if (!fmSave) return;
            formErr('');
            this.disabled = true;
            try { const ok = await fmSave(formErr); if (ok !== false) closeForm(); }
            catch (e) { formErr(e.message); }
            finally { this.disabled = false; }
        });
        const fv = name => { const el = F('pcFormBody').querySelector(`[name="${name}"]`); return el ? (el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value.trim()) : ''; };
        async function must(d) { if (!d.success) throw new Error(d.message || 'Something went wrong.'); return d; }

        // field builder para sa simpleng form
        function fieldsHtml(fields, row = {}) {
            return `<div class="grid grid-cols-2 gap-3">${fields.map(f => {
                const v = row[f.name] ?? f.value ?? '';
                const span = f.full ? 'col-span-2' : 'col-span-2 sm:col-span-1';
                let ctl;
                if (f.type === 'select') ctl = `<select name="${f.name}" class="${inputCls} bg-white">${f.options.map(o => `<option ${String(o) === String(v) ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
                else if (f.type === 'textarea') ctl = `<textarea name="${f.name}" rows="3" maxlength="${f.max || 2000}" class="${inputCls} resize-none">${esc(v)}</textarea>`;
                else if (f.type === 'checkbox') return `<label class="${span} flex items-center gap-2 text-xs text-gray-700 cursor-pointer"><input type="checkbox" name="${f.name}" ${+v ? 'checked' : ''} class="w-4 h-4 accent-amber-700"> ${f.label}</label>`;
                else ctl = `<input type="${f.type || 'text'}" name="${f.name}" value="${esc(String(v ?? '').slice(0, f.type === 'date' ? 10 : 9999))}" ${f.list ? `list="${f.list}"` : ''} maxlength="${f.max || 255}" placeholder="${esc(f.ph || '')}" class="${inputCls}">`;
                return `<label class="${span}">${lbl(f.label, f.req)}${ctl}</label>`;
            }).join('')}</div>`;
        }
        function entityForm(entity, title, fields, row, extra = {}) {
            openForm({
                title: (row ? 'Edit ' : 'Add ') + title, body: fieldsHtml(fields, row || {}) + (extra.after || ''),
                onOpen: extra.onOpen,
                onSave: async err => {
                    const data = { entity, row_id: row ? row.id : 0 };
                    for (const f of fields) {
                        data[f.name] = fv(f.name);
                        if (f.req && !data[f.name]) { err(`${f.label} is required.`); return false; }
                    }
                    if (extra.validate) { const m = extra.validate(data); if (m) { err(m); return false; } }
                    await must(await post('save_entity', data));
                    toast(row ? 'Saved.' : `${title} added.`);
                    await reload();
                },
                onDelete: row ? async () => { await must(await post('delete_entity', { entity, row_id: row.id })); toast('Deleted.'); await reload(); } : null,
            });
        }

        // print: kopya lang ng dokumento ang lalabas sa papel
        function printDoc(html) {
            let area = document.getElementById('nhPrintArea');
            if (!area) { area = document.createElement('div'); area.id = 'nhPrintArea'; document.body.appendChild(area); }
            area.innerHTML = html;
            const imgs = [...area.querySelectorAll('img')].filter(i => !i.complete);
            Promise.all(imgs.map(i => new Promise(r => { i.onload = i.onerror = r; }))).then(() => {
                window.print();
                setTimeout(() => { area.innerHTML = ''; }, 500);
            });
        }
        function previewDoc(title, html) {
            openForm({ title, wide: true, body: `<div class="overflow-x-auto"><div class="min-w-[720px] border border-gray-200 rounded-lg p-6 bg-white">${html}</div></div>
                <div class="mt-3 flex justify-end"><button type="button" id="pcDocPrint" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-gray-800"><i class="fa-solid fa-print"></i> Print / Save PDF</button></div>`,
                onOpen: () => F('pcDocPrint').addEventListener('click', () => printDoc(html)) });
        }


        // ── item rows (DR, Quotation, Turnover letter) ──
        const itemRow = (cols, vals = {}) => `<tr>${cols.map(c => `<td class="p-1"><input name="${c.name}[]" value="${esc(vals[c.name] ?? '')}" ${c.type ? `type="${c.type}" step="any" min="0"` : ''} placeholder="${c.ph || ''}" class="${inputCls} ${c.right ? 'text-right' : ''}" ${c.list ? `list="${c.list}"` : ''}></td>`).join('')}<td class="p-1 text-center"><button type="button" class="pc-row-del w-7 h-7 rounded-md text-gray-400 hover:text-red-600 hover:bg-red-50" title="Remove"><i class="fa-solid fa-xmark"></i></button></td></tr>`;
        function itemTable(id, cols, rows, addLabel) {
            return `<div class="rounded-lg border border-gray-200 overflow-hidden"><table class="w-full text-xs" id="${id}"><thead class="bg-gray-50 text-[10px] uppercase tracking-wider text-gray-500"><tr>${cols.map(c => `<th class="px-2 py-2 text-left font-semibold" style="width:${c.w || 'auto'}">${c.label}</th>`).join('')}<th class="w-9"></th></tr></thead>
                <tbody>${(rows.length ? rows : [{}, {}, {}]).map(r => itemRow(cols, r)).join('')}</tbody></table></div>
                <button type="button" data-add-row="${id}" class="mt-2 inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 hover:underline"><i class="fa-solid fa-plus text-[10px]"></i> ${addLabel}</button>`;
        }
        function wireItemTable(id, cols, onChange) {
            const tb = F(id).querySelector('tbody');
            F('pcFormBody').querySelector(`[data-add-row="${id}"]`).addEventListener('click', () => { tb.insertAdjacentHTML('beforeend', itemRow(cols)); onChange && onChange(); });
            tb.addEventListener('click', e => { const b = e.target.closest('.pc-row-del'); if (b) { if (tb.rows.length > 1) b.closest('tr').remove(); else b.closest('tr').querySelectorAll('input').forEach(i => i.value = ''); onChange && onChange(); } });
            if (onChange) tb.addEventListener('input', onChange);
        }
        const tableVals = (id, name) => [...F(id).querySelectorAll(`[name="${name}[]"]`)].map(i => i.value.trim());
        const fmtSlash = s => { if (!s) return ''; const [y, m, d] = String(s).slice(0, 10).split('-'); return `${m}/${d}/${y}`; };
        const fmtLong = s => s ? toD(s).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) : '';

        Object.assign(PC, {
            esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL,
            money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn,
            openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals,
            openProject, loadList, renderWorkspace, go,
        });

        // simulan kapag naka-load na lahat ng step file (tinatawag sa dulo ng coordenator.php)
        PC.start = function () {
            filter = memo.get('filter') || 'Ongoing';
            tab = memo.get('tab') || 'overview';
            loadList().then(() => {
                const last = +(memo.get('project') || 0);
                if (last && projects.some(p => p.id === last)) openProject(last);
            });
        };
    })();
</script>
