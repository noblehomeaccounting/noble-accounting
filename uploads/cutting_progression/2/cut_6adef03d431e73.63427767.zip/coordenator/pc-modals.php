<?php
// coordenator/pc-modals.php — Task modal (Timeline) at ang generic form modal na gamit ng lahat ng step
defined('ROOT_PATH') || exit;
?>
    <!-- ===================== TASK MODAL ===================== -->
    <div id="pcTaskModal" class="hidden fixed inset-0 z-[9999] items-center justify-center bg-black/50 p-4">
        <div class="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden">
            <div class="flex items-center justify-between px-5 py-3.5 border-b border-gray-100">
                <p id="pcTaskTitle" class="text-sm font-semibold text-gray-800">Add task</p>
                <button type="button" data-close="pcTaskModal" class="text-gray-400 hover:text-gray-600 text-xl leading-none">&times;</button>
            </div>
            <div class="p-5 grid grid-cols-2 gap-3">
                <label class="col-span-2 sm:col-span-1">
                    <span class="block text-[10px] font-semibold uppercase tracking-wider text-gray-500 mb-1">Category <span class="text-red-500">*</span></span>
                    <input type="text" id="pcTCat" list="pcCatList" maxlength="150" placeholder="e.g. INSTALLATION"
                        class="w-full border border-gray-200 rounded-lg px-3 py-2 text-xs uppercase outline-none focus:border-amber-600">
                    <datalist id="pcCatList"></datalist>
                </label>
                <label class="col-span-2 sm:col-span-1">
                    <span class="block text-[10px] font-semibold uppercase tracking-wider text-gray-500 mb-1">Task <span class="text-red-500">*</span></span>
                    <input type="text" id="pcTName" maxlength="200" placeholder="e.g. Dry wall installation"
                        class="w-full border border-gray-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-600">
                </label>
                <div class="col-span-2 rounded-lg border border-gray-200 p-3">
                    <div class="flex items-center justify-between mb-2">
                        <p class="text-[10px] font-semibold uppercase tracking-wider text-gray-500">Planned <span class="text-red-500">*</span></p>
                        <span id="pcTDur" class="text-[11px] font-semibold text-amber-700"></span>
                    </div>
                    <div class="grid grid-cols-2 gap-2">
                        <input type="date" id="pcTStart" class="border border-gray-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-600" title="Start">
                        <input type="date" id="pcTEnd" class="border border-gray-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-600" title="End">
                    </div>
                </div>
                <div class="col-span-2 rounded-lg border border-gray-200 p-3">
                    <p class="text-[10px] font-semibold uppercase tracking-wider text-gray-500 mb-2">Actual <span class="normal-case font-normal text-gray-400">(optional)</span></p>
                    <div class="grid grid-cols-2 gap-2">
                        <input type="date" id="pcTAStart" class="border border-gray-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-600" title="Actual start">
                        <input type="date" id="pcTAEnd" class="border border-gray-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-600" title="Actual end">
                    </div>
                </div>
                <label class="col-span-2">
                    <span class="flex items-center justify-between text-[10px] font-semibold uppercase tracking-wider text-gray-500 mb-1">Progress <b id="pcTProgVal" class="text-amber-700 text-xs">0%</b></span>
                    <input type="range" id="pcTProg" min="0" max="100" step="5" value="0" class="pc-range w-full accent-amber-700">
                </label>
                <label class="col-span-2">
                    <span class="block text-[10px] font-semibold uppercase tracking-wider text-gray-500 mb-1">Remarks</span>
                    <input type="text" id="pcTRemarks" maxlength="500" placeholder="Optional"
                        class="w-full border border-gray-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-600">
                </label>
                <p id="pcTError" class="col-span-2 hidden text-[11px] text-red-600"></p>
            </div>
            <div class="flex items-center justify-between gap-2 px-5 py-3 bg-gray-50 border-t border-gray-100">
                <div id="pcTDelWrap"></div>
                <div class="flex gap-2">
                    <button type="button" data-close="pcTaskModal" class="px-3.5 py-2 text-[11px] font-semibold text-gray-500 bg-white border border-gray-200 rounded-lg hover:bg-gray-100">Cancel</button>
                    <button type="button" id="pcTSave" class="px-3.5 py-2 text-[11px] font-semibold text-white bg-amber-700 rounded-lg hover:bg-amber-800 disabled:opacity-60"><i class="fa-solid fa-check mr-1"></i> Save task</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ===================== GENERIC FORM MODAL (lahat ng module) ===================== -->
    <div id="pcFormModal" class="hidden fixed inset-0 z-[9999] items-start justify-center bg-black/50 p-4 overflow-y-auto">
        <div id="pcFormBox" class="bg-white rounded-xl shadow-xl w-full max-w-lg my-auto overflow-hidden">
            <div class="flex items-center justify-between px-5 py-3.5 border-b border-gray-100">
                <p id="pcFormTitle" class="text-sm font-semibold text-gray-800"></p>
                <button type="button" data-close="pcFormModal" class="text-gray-400 hover:text-gray-600 text-xl leading-none">&times;</button>
            </div>
            <div class="p-5">
                <div id="pcFormBody"></div>
                <p id="pcFormError" class="hidden mt-3 rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-[11px] text-red-700"></p>
            </div>
            <div class="flex items-center justify-between gap-2 px-5 py-3 bg-gray-50 border-t border-gray-100">
                <div id="pcFormDel" class="flex items-center gap-1"></div>
                <div class="flex gap-2">
                    <button type="button" data-close="pcFormModal" class="px-3.5 py-2 text-[11px] font-semibold text-gray-500 bg-white border border-gray-200 rounded-lg hover:bg-gray-100">Close</button>
                    <button type="button" id="pcFormSave" class="px-3.5 py-2 text-[11px] font-semibold text-white bg-amber-700 rounded-lg hover:bg-amber-800 disabled:opacity-60"></button>
                </div>
            </div>
        </div>
    </div>
