<?php
// coordenator/pc-style.php — CSS ng Gantt at ng mga printable na dokumento (DR, Quotation, AFP, Turnover Letter)
defined('ROOT_PATH') || exit;
?>
    <style>
        .pc-tabs { scrollbar-width: none; }
        .pc-tabs::-webkit-scrollbar { display: none; }
        /* Gantt */
        .pc-gantt-grid { background-image: repeating-linear-gradient(90deg, transparent 0, transparent calc(var(--day) - 1px), rgba(15, 23, 42, .05) calc(var(--day) - 1px), rgba(15, 23, 42, .05) var(--day)); }
        .pc-weekend { position: absolute; top: 0; bottom: 0; background: rgba(15, 23, 42, .035); }
        .pc-bar { position: absolute; top: 50%; transform: translateY(-50%); height: 14px; border-radius: 4px; overflow: hidden; }
        .pc-bar > i { position: absolute; left: 0; top: 0; bottom: 0; }
        .pc-actual { position: absolute; bottom: 3px; height: 3px; border-radius: 2px; background: #111827; opacity: .55; }
        .pc-today { position: absolute; top: 0; bottom: 0; width: 2px; background: #ef4444; z-index: 3; }
        .pc-range::-webkit-slider-thumb { cursor: pointer; }

        /* ── Mga printable na dokumento (DR, Labor Quotation, AFP, Turnover Letter) ── */
        .pcdoc { font-family: Arial, Helvetica, sans-serif; color: #111; font-size: 11px; line-height: 1.35; }
        .pcdoc table { border-collapse: collapse; width: 100%; table-layout: fixed; }
        .pcdoc td { vertical-align: top; padding: 3px 5px; word-wrap: break-word; }
        .pcdoc .nb td { border: 0; }
        .pcdoc .tbl td { border: 1px solid #333; }
        .pcdoc .c { text-align: center; } .pcdoc .r { text-align: right; } .pcdoc .b { font-weight: 700; } .pcdoc .i { font-style: italic; }
        .pcdoc p { margin: 0 0 6px; }
        /* DR — asul */
        .pcdr .dr-head { border: 2px solid #1d4ed8; margin-bottom: 8px; }
        .pcdr .dr-title { background: #1d4ed8; color: #fff; font-weight: 700; text-align: center; font-size: 15px; letter-spacing: .08em; padding: 5px; }
        .pcdr .dr-logo img { width: 92px; } .pcdr .dr-co { font-size: 10px; color: #333; }
        .pcdr .dr-meta td { padding: 2px 4px; font-size: 10.5px; }
        .pcdr .tbl .th td { background: #1d4ed8; color: #fff; font-weight: 700; text-align: center; }
        .pcdr .blue { color: #1d4ed8; font-weight: 700; }
        .pcdr .note { margin-top: 6px; }
        .pcdr .terms { margin-top: 12px; font-size: 10px; }
        .pcdr .sign { margin-top: 34px; } .pcdr .sign td { text-align: center; padding: 0 14px; }
        .pcdr .sign .nm { min-height: 15px; font-weight: 700; } .pcdr .sign .ln { border-top: 1px solid #111; padding-top: 2px; font-size: 10px; }
        /* Labor quotation */
        .pcq .info td { padding: 1px 4px; }
        .pcq .qt { margin: 12px 0 6px; font-weight: 700; text-align: center; font-size: 12.5px; }
        .pcq .tbl .th td { background: #e5e7eb; font-weight: 700; text-align: center; }
        .pcq .tbl .sec td { font-weight: 700; background: #f8fafc; }
        .pcq .tbl .tot td { font-weight: 700; background: #e5e7eb; }
        .pcq .sign td { width: 50%; padding-right: 40px; } .pcq .ln2 { border-top: 1px solid #111; margin-top: 30px; }
        .pcq .sign .nm { font-weight: 700; }
        /* AFP — orange */
        .pcafp .hd .co { font-weight: 800; font-size: 15px; color: #c2410c; }
        .pcafp .hd .addr { font-size: 9.5px; color: #444; } .pcafp .hd .ttl { font-weight: 700; font-size: 12.5px; margin-top: 4px; }
        .pcafp .bar { background: #ea580c; color: #fff; font-weight: 700; padding: 3px 6px; margin: 10px 0 0; font-size: 10.5px; letter-spacing: .03em; }
        .pcafp .kv td, .pcafp .sum td, .pcafp .sov td, .pcafp .sg td { border: 1px solid #9ca3af; }
        .pcafp .kv .k { background: #fff7ed; font-weight: 700; width: 17%; }
        .pcafp .sum td:last-child { width: 26%; } .pcafp .sum .b td { font-weight: 700; }
        .pcafp .sum .due td { font-weight: 800; background: #ffedd5; }
        .pcafp .sov td { font-size: 9.5px; } .pcafp .sov .th td { background: #fed7aa; font-weight: 700; text-align: center; }
        .pcafp .sov .cur td { background: #fff7ed; font-weight: 700; }
        .pcafp .cert { font-size: 10px; margin-top: 4px; }
        .pcafp .sg td { text-align: center; padding-top: 34px; } .pcafp .sg .nm { font-weight: 700; border-bottom: 1px solid #111; margin: 0 10px 2px; min-height: 14px; }
        .pcafp .sg .t { font-size: 9px; font-weight: 700; color: #444; }
        /* Turnover letter */
        .pctv { font-family: "Times New Roman", Times, serif; font-size: 12.5px; line-height: 1.5; }
        .pctv .hd { font-weight: 700; vertical-align: middle; font-size: 13px; }
        .pctv .ttl { text-align: center; font-weight: 700; margin: 14px 0; }
        .pctv .tbl { margin: 10px 0 14px; } .pctv .tbl tr:first-child td { font-weight: 700; }
        #nhPrintArea { display: none; }
        @media print {
            @page { size: A4; margin: 12mm; }
            body > *:not(#nhPrintArea) { display: none !important; }
            #nhPrintArea { display: block !important; }
            #nhPrintArea, #nhPrintArea * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            #nhPrintArea .tbl tr { break-inside: avoid; }
        }
    </style>
