<?php
// coordenator/step4-client.php — STEP 4: Client Contact and Coordination
// Kasama sa coordenator.php (huwag buksan nang direkta).
defined('ROOT_PATH') || exit;
?>
<script>
    (function (PC) {
        'use strict';
        const { esc, DAY, toD, ymd, todayISO, days, fmt, fmtY, fmtSlash, fmtLong, isDelayed, toast, api, memo, F, LOGO, TR_URL, money, num, qtyFmt, P, post, reload, must, inputCls, lbl, pill, PILL, emptyBox, sectionHead, addBtn, iconBtn, openForm, closeForm, formErr, fv, fieldsHtml, entityForm, printDoc, previewDoc, itemRow, itemTable, wireItemTable, tableVals, openProject, loadList, renderWorkspace, go } = PC;

        // ── Kahulugan ng hakbang (galing sa F. Operations) ──
        PC.defineStep({ key: 'client', n: 4, label: 'Client Contact', icon: 'fa-comments',
            role: 'Keep the client informed and get approvals for changes.',
            link: 'Client coordination ensures all departments follow the approved scope and site requirements.',
            duties: [
                ['Confirm site conditions, working hours, and access requirements', () => PC.current.clientlog.some(l => l.type === 'Site Condition')],
                ['Coordinate deliveries, installation schedules, and inspections', () => PC.current.clientlog.some(l => ['Schedule', 'Inspection'].includes(l.type))],
                ['Provide project progress updates', () => PC.current.clientlog.some(l => l.type === 'Update')],
                ['Communicate delays, concerns, and additional requirements'],
                ['Obtain necessary approvals for changes', () => PC.current.clientlog.some(l => +l.needs_approval) && PC.current.clientlog.every(l => !+l.needs_approval || l.approved_at)],
            ],
            render: renderClientLog,
            badge: () => PC.current.clientlog.filter(l => +l.needs_approval && !l.approved_at).length,
        });

        // ═════════════════════════════════════════════════════════
        //  STEP 4 · CLIENT CONTACT
        // ═════════════════════════════════════════════════════════
        const LOG_TYPES = ['Update', 'Site Condition', 'Schedule', 'Delay', 'Change Request', 'Inspection', 'Concern'];
        const LOG_COLOR = { Update: PILL.sky, 'Site Condition': PILL.gray, Schedule: PILL.amber, Delay: PILL.red, 'Change Request': PILL.violet, Inspection: PILL.green, Concern: PILL.red };
        const LOG_FIELDS = [
            { name: 'log_date', label: 'Date', type: 'date', req: 1, value: todayISO() },
            { name: 'type', label: 'Type', type: 'select', options: LOG_TYPES },
            { name: 'subject', label: 'Subject', req: 1, full: 1, max: 200 },
            { name: 'details', label: 'Details', type: 'textarea', full: 1 },
            { name: 'contact_person', label: 'Talked to', ph: 'Client / representative', max: 150 },
            { name: 'approved_at', label: 'Client approved on', type: 'date' },
            { name: 'needs_approval', label: 'Needs client approval (e.g. change in scope)', type: 'checkbox', full: 1 },
        ];
        function renderClientLog() {
            const list = PC.current.clientlog;
            const pending = list.filter(l => +l.needs_approval && !l.approved_at);
            const body = document.getElementById('pcTabBody');
            body.innerHTML = sectionHead('Client Contact & Coordination', 'Updates, site conditions, schedules, delays and change approvals.', addBtn('pcAddLog', 'Add Entry'))
                + (pending.length ? `<div class="mb-4 rounded-lg border border-violet-200 bg-violet-50 px-3 py-2.5 text-xs text-violet-800"><i class="fa-solid fa-hourglass-half mr-1"></i> <b>${pending.length}</b> item${pending.length === 1 ? '' : 's'} waiting for client approval.</div>` : '')
                + (list.length ? `<ol class="relative border-l-2 border-gray-100 ml-2 space-y-4">${list.map(l => `
                    <li class="relative pl-5">
                        <span class="absolute -left-[7px] top-1.5 w-3 h-3 rounded-full ring-4 ring-white ${l.type === 'Delay' || l.type === 'Concern' ? 'bg-red-500' : 'bg-amber-600'}"></span>
                        <div class="rounded-lg border border-gray-200 px-3 py-2.5 hover:border-amber-300 cursor-pointer" data-log="${l.id}">
                            <div class="flex flex-wrap items-center gap-2"><span class="text-[11px] font-semibold text-gray-500">${fmtY(l.log_date)}</span>${pill(l.type.toUpperCase(), LOG_COLOR[l.type] || PILL.gray)}
                                ${+l.needs_approval ? (l.approved_at ? pill('APPROVED ' + fmt(l.approved_at), PILL.green) : pill('PENDING APPROVAL', PILL.violet)) : ''}</div>
                            <p class="text-sm font-semibold text-gray-900 mt-1">${esc(l.subject)}</p>
                            ${l.details ? `<p class="text-xs text-gray-600 mt-0.5 whitespace-pre-line">${esc(l.details)}</p>` : ''}
                            ${l.contact_person ? `<p class="text-[10.5px] text-gray-400 mt-1"><i class="fa-regular fa-user mr-1"></i>${esc(l.contact_person)}</p>` : ''}
                        </div>
                    </li>`).join('')}</ol>` : emptyBox('fa-comments', 'No entries yet', 'Record site conditions, schedules, delays and client approvals here.'));
            F('pcAddLog').addEventListener('click', () => entityForm('clientlog', 'Entry', LOG_FIELDS, null));
            body.querySelectorAll('[data-log]').forEach(b => b.addEventListener('click', () => entityForm('clientlog', 'Entry', LOG_FIELDS, list.find(x => x.id == b.dataset.log))));
        }

    })(window.NHPC);
</script>
