<?php
// coordenatorajax.php  —  Project Coordinator (Operations): projects, overview, timeline

include ROOT_PATH . '/network/connect.php';
include ROOT_PATH . '/admin/authentication/index-roles.php';

$allowedRoles = [ROLE_PC];

include ROOT_PATH . '/admin/authentication/index-authguard.php';
include ROOT_PATH . '/admin/authentication/index-roleguard.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');

$currentUserId = intval($_SESSION['account_id'] ?? 0);
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// huwag i-lock ang session habang tumatakbo ang request (iwas "stuck" sa loading)
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

// Kailan papasok ang proyekto kay PC:
//   true  = kapag na-mark nang DELIVERED ang transmittal (tapos na ang transmittal)
//   false = kapag na-save pa lang ang transmittal
const PC_REQUIRE_DELIVERED = true;

// Mga control point (Overview checklist)
const PC_CHECKS = [
    'contract' => 'Contract approval — project scope, budget, and deliverables confirmed',
    'drawing'  => 'Drawing approval — Cutting List and production use the correct drawing revision',
    'material' => 'Material verification — BOM quantities and specifications checked before the PR',
    'ntp'      => 'Project authorization — required NTP and approvals confirmed',
    'site'     => 'Site readiness — materials, permits, manpower, and client access verified before installation',
    'billing'  => 'Progress billing — accurate accomplishment records per the billing milestones',
    'quality'  => 'Quality inspection — deficiencies documented and corrections verified',
    'turnover' => 'Turnover — client acceptance and closeout documents secured',
];
const PC_STATUSES = ['Ongoing', 'For Turnover', 'Closed'];

// Operations flow — sunud-sunod na hakbang (F. Operations 1–8). Ang may true = "If Required" (puwedeng Not required).
const PC_STEPS = [
    'delivery' => false,
    'permits'  => true,
    'workers'  => false,
    'client'   => false,
    'timeline' => true,
    'billing'  => false,
    'punch'    => false,
    'turnover' => false,
];

// Template ng timeline (galing sa sample na Gantt chart): [kategorya, gawain, araw]
const PC_TEMPLATE = [
    ['PLAN', 'Sample Approved', 2],
    ['PLAN', 'Drawing Approved', 1],
    ['PLAN', 'Cutting List', 8],
    ['GENERAL DISMANTLING & GARBAGE DISPOSAL', 'Dismantle', 3],
    ['GENERAL DISMANTLING & GARBAGE DISPOSAL', 'Garbage Disposal', 3],
    ['DELIVERY OF MATERIALS', 'Delivery of Materials', 3],
    ['INSTALLATION', 'Installation', 6],
    ['HAND OVER', 'Hand Over', 2],
];

function pcOut(array $d): void
{
    echo json_encode($d);
    exit;
}

set_exception_handler(function (Throwable $e) {
    error_log('[coordenatorajax] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
});

function pcValidDate(?string $d): ?string
{
    $d = trim((string) $d);
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) ? $d : null;
}

// maliliit na helper para sa prepared statements
function pcAll(mysqli $conn, string $sql, string $types = '', array $args = []): array
{
    $st = $conn->prepare($sql);
    if ($types !== '') $st->bind_param($types, ...$args);
    $st->execute();
    $rows = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    $st->close();
    return $rows;
}
function pcOne(mysqli $conn, string $sql, string $types = '', array $args = []): ?array
{
    $r = pcAll($conn, $sql, $types, $args);
    return $r[0] ?? null;
}
function pcRun(mysqli $conn, string $sql, string $types = '', array $args = []): int
{
    $st = $conn->prepare($sql);
    if ($types !== '') $st->bind_param($types, ...$args);
    $st->execute();
    $id = $st->insert_id ?: $st->affected_rows;
    $st->close();
    return (int) $id;
}
function pcStr(string $key, int $max = 255): string
{
    return mb_substr(trim((string) ($_POST[$key] ?? '')), 0, $max);
}
function pcNum(string $key): float
{
    return round((float) str_replace(',', '', (string) ($_POST[$key] ?? 0)), 2);
}
function pcRequirePost(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') pcOut(['success' => false, 'message' => 'Invalid request.']);
}
function pcUserName(mysqli $conn, int $uid): string
{
    $r = pcOne($conn, "SELECT name FROM noblerole WHERE id = ? LIMIT 1", 'i', [$uid]);
    return $r['name'] ?? '';
}
// Sunod-sunod na numero bawat prefix: hal. 202606-001
function pcNextNo(mysqli $conn, string $table, string $col, string $prefix, int $pad): string
{
    $start = strlen($prefix) + 1;
    $r = pcOne($conn, "SELECT COALESCE(MAX(CAST(SUBSTRING($col, ?) AS UNSIGNED)), 0) AS n FROM $table WHERE $col LIKE CONCAT(?, '%') FOR UPDATE", 'is', [$start, $prefix]);
    return $prefix . str_pad((string) ((int) ($r['n'] ?? 0) + 1), $pad, '0', STR_PAD_LEFT);
}

// Gumawa ng proyekto para sa bawat BOM na may tapos nang transmittal (isang beses lang bawat BOM)
// estado ng bawat hakbang: status (done / na / ''), mga na-tick na tungkulin, kailan at sino
function pcSteps(mysqli $conn, int $pid): array
{
    $rows = pcAll($conn, "SELECT s.step_key, s.status, s.duties, s.completed_at, r.name AS completed_by_name
                          FROM noblepc_step s LEFT JOIN noblerole r ON r.id = s.completed_by WHERE s.project_id = ?", 'i', [$pid]);
    $out = [];
    foreach (PC_STEPS as $k => $opt) $out[$k] = ['status' => '', 'duties' => [], 'completed_at' => null, 'completed_by_name' => null];
    foreach ($rows as $r) {
        if (!isset($out[$r['step_key']])) continue;
        $out[$r['step_key']] = ['status' => (string) ($r['status'] ?? ''), 'duties' => array_values(array_map('intval', json_decode((string) $r['duties'], true) ?: [])),
            'completed_at' => $r['completed_at'], 'completed_by_name' => $r['completed_by_name']];
    }
    return $out;
}
// lahat ng hakbang bago ang $step ay tapos na o "not required"?
function pcPrevStepsDone(array $steps, string $step): ?string
{
    foreach (array_keys(PC_STEPS) as $i => $k) {
        if ($k === $step) return null;
        if (!in_array($steps[$k]['status'], ['done', 'na'], true)) return 'Finish Step ' . ($i + 1) . ' first — the operations flow goes step by step.';
    }
    return null;
}
function pcSyncProjects(mysqli $conn): void
{
    $cond = PC_REQUIRE_DELIVERED ? 'AND t.delivered_at IS NOT NULL' : '';
    $conn->query("
        INSERT IGNORE INTO noblepc_project (bom_id, client_name, location, scope, status, created_at)
        SELECT b.id,
               COALESCE(NULLIF(MAX(b.client_name), ''), MIN(t.client_name)),
               COALESCE(NULLIF(MAX(i.address), ''), MIN(t.client_address)),
               COALESCE(NULLIF(MAX(i.project_scope), ''), MAX(b.general_scope)),
               'Ongoing', NOW()
        FROM nobletransmittal t
        JOIN noblecrm_bom b              ON b.id = t.bom_id
        LEFT JOIN noblecrm_2dquotation q ON q.id = b.quotation_id
        LEFT JOIN noblecrminquiry i      ON i.id = q.inquiry_id
        WHERE t.bom_id IS NOT NULL $cond
        GROUP BY b.id
    ");
}

function pcProject(mysqli $conn, int $id): ?array
{
    $st = $conn->prepare("
        SELECT p.*, b.bom_number, i.control_no, i.contact_number
        FROM noblepc_project p
        LEFT JOIN noblecrm_bom b         ON b.id = p.bom_id
        LEFT JOIN noblecrm_2dquotation q ON q.id = b.quotation_id
        LEFT JOIN noblecrminquiry i      ON i.id = q.inquiry_id
        WHERE p.id = ? LIMIT 1
    ");
    $st->bind_param('i', $id);
    $st->execute();
    $p = $st->get_result()->fetch_assoc();
    $st->close();
    return $p ?: null;
}

// ================= LIST =================
if ($action === 'list') {
    pcSyncProjects($conn);
    $rows = $conn->query("
        SELECT p.id, p.bom_id, p.client_name, p.location, p.scope, p.status, p.created_at,
               b.bom_number,
               (SELECT COUNT(*) FROM noblepc_timeline t WHERE t.project_id = p.id)                      AS task_count,
               (SELECT ROUND(AVG(t.progress)) FROM noblepc_timeline t WHERE t.project_id = p.id)         AS progress,
               (SELECT MIN(t.start_date) FROM noblepc_timeline t WHERE t.project_id = p.id)              AS start_date,
               (SELECT MAX(t.end_date) FROM noblepc_timeline t WHERE t.project_id = p.id)                AS end_date,
               (SELECT COUNT(*) FROM noblepc_timeline t WHERE t.project_id = p.id
                    AND t.progress < 100 AND t.end_date < CURDATE())                                     AS delayed_count
        FROM noblepc_project p
        LEFT JOIN noblecrm_bom b ON b.id = p.bom_id
        ORDER BY FIELD(p.status, 'Ongoing', 'For Turnover', 'Closed'), p.id DESC
    ")->fetch_all(MYSQLI_ASSOC);

    foreach ($rows as &$r) {
        $r['id'] = (int) $r['id'];
        $r['task_count'] = (int) $r['task_count'];
        $r['progress'] = (int) ($r['progress'] ?? 0);
        $r['delayed_count'] = (int) $r['delayed_count'];
    }
    unset($r);
    pcOut(['success' => true, 'rows' => $rows, 'statuses' => PC_STATUSES]);
}

// ================= VIEW =================
if ($action === 'view') {
    $id = intval($_GET['id'] ?? 0);
    $p = pcProject($conn, $id);
    if (!$p) pcOut(['success' => false, 'message' => 'Project not found.']);

    $tr = $conn->prepare("
        SELECT t.id, t.ref_no, t.transmittal_date, t.particulars, t.delivery_mode, t.delivered_at, pr.req_no
        FROM nobletransmittal t
        LEFT JOIN noblepurchaserequest pr ON pr.id = t.pr_id
        WHERE t.bom_id = ? ORDER BY t.id
    ");
    $bid = (int) $p['bom_id'];
    $tr->bind_param('i', $bid);
    $tr->execute();
    $transmittals = $tr->get_result()->fetch_all(MYSQLI_ASSOC);
    $tr->close();

    $tl = $conn->prepare("SELECT * FROM noblepc_timeline WHERE project_id = ? ORDER BY sort_order, start_date, id");
    $tl->bind_param('i', $id);
    $tl->execute();
    $timeline = $tl->get_result()->fetch_all(MYSQLI_ASSOC);
    $tl->close();
    foreach ($timeline as &$t) { $t['id'] = (int) $t['id']; $t['progress'] = (int) $t['progress']; $t['sort_order'] = (int) $t['sort_order']; }
    unset($t);

    $checks = json_decode((string) ($p['checklist'] ?? ''), true) ?: [];
    $p['id'] = (int) $p['id'];
    unset($p['checklist']);

    // ── mga module ──
    $deliveries = pcAll($conn, "SELECT * FROM noblepc_delivery WHERE project_id = ? ORDER BY id DESC", 'i', [$id]);
    $dItems = pcAll($conn, "SELECT di.* FROM noblepc_delivery_item di JOIN noblepc_delivery d ON d.id = di.delivery_id WHERE d.project_id = ? ORDER BY di.item_no", 'i', [$id]);
    foreach ($deliveries as &$d) {
        $d['items'] = array_values(array_filter($dItems, fn($x) => (int) $x['delivery_id'] === (int) $d['id']));
    }
    unset($d);

    $quotes = pcAll($conn, "SELECT * FROM noblepc_subcon_quote WHERE project_id = ? ORDER BY id", 'i', [$id]);
    $qItems = pcAll($conn, "SELECT qi.* FROM noblepc_subcon_quote_item qi JOIN noblepc_subcon_quote q ON q.id = qi.quote_id WHERE q.project_id = ? ORDER BY qi.sort_order, qi.id", 'i', [$id]);
    foreach ($quotes as &$q) {
        $q['items'] = array_values(array_filter($qItems, fn($x) => (int) $x['quote_id'] === (int) $q['id']));
        $q['total'] = round(array_sum(array_map(fn($x) => (float) $x['amount'], $q['items'])), 2);
    }
    unset($q);

    $turnover = pcOne($conn, "SELECT * FROM noblepc_turnover WHERE project_id = ?", 'i', [$id]);
    if ($turnover) $turnover['items'] = json_decode((string) $turnover['items'], true) ?: [];

    pcOut([
        'success' => true, 'project' => $p, 'transmittals' => $transmittals, 'timeline' => $timeline,
        'checks' => $checks, 'check_labels' => PC_CHECKS, 'statuses' => PC_STATUSES,
        'deliveries' => $deliveries,
        'permits'    => pcAll($conn, "SELECT * FROM noblepc_permit WHERE project_id = ? ORDER BY COALESCE(date_needed, '9999-12-31'), id", 'i', [$id]),
        'workers'    => pcAll($conn, "SELECT w.*, (SELECT COUNT(*) FROM noblepc_attendance a WHERE a.worker_id = w.id AND a.present = 1) AS days_present FROM noblepc_worker w WHERE w.project_id = ? ORDER BY w.kind DESC, w.name", 'i', [$id]),
        'attendance' => pcAll($conn, "SELECT worker_id, work_date, present FROM noblepc_attendance WHERE project_id = ? AND work_date >= CURDATE() - INTERVAL 31 DAY", 'i', [$id]),
        'clientlog'  => pcAll($conn, "SELECT * FROM noblepc_clientlog WHERE project_id = ? ORDER BY log_date DESC, id DESC", 'i', [$id]),
        'quotes'     => $quotes,
        'billings'   => pcAll($conn, "SELECT * FROM noblepc_billing WHERE project_id = ? ORDER BY quote_id, id", 'i', [$id]),
        'punch'      => pcAll($conn, "SELECT * FROM noblepc_punch WHERE project_id = ? ORDER BY FIELD(status, 'Open', 'Fixed', 'Verified'), COALESCE(target_date, '9999-12-31'), id", 'i', [$id]),
        'turnover'   => $turnover,
        'steps'      => pcSteps($conn, $id),
        'me'         => pcUserName($conn, $currentUserId),
    ]);
}

// ================= PROJECT: status / info / checklist =================
if ($action === 'update_project') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') pcOut(['success' => false, 'message' => 'Invalid request.']);
    $id = intval($_POST['id'] ?? 0);
    $p = pcProject($conn, $id);
    if (!$p) pcOut(['success' => false, 'message' => 'Project not found.']);

    $status   = in_array($_POST['status'] ?? '', PC_STATUSES, true) ? $_POST['status'] : $p['status'];
    $location = mb_substr(trim($_POST['location'] ?? $p['location'] ?? ''), 0, 255);
    $scope    = mb_substr(trim($_POST['scope'] ?? $p['scope'] ?? ''), 0, 255);
    $notes    = mb_substr(trim($_POST['notes'] ?? $p['notes'] ?? ''), 0, 2000);

    $st = $conn->prepare("UPDATE noblepc_project SET status = ?, location = ?, scope = ?, notes = ?, updated_by = ?, updated_at = NOW() WHERE id = ?");
    $st->bind_param('ssssii', $status, $location, $scope, $notes, $currentUserId, $id);
    $st->execute();
    $st->close();
    pcOut(['success' => true]);
}

if ($action === 'toggle_check') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') pcOut(['success' => false, 'message' => 'Invalid request.']);
    $id  = intval($_POST['id'] ?? 0);
    $key = $_POST['key'] ?? '';
    if (!array_key_exists($key, PC_CHECKS)) pcOut(['success' => false, 'message' => 'Invalid item.']);
    $p = pcProject($conn, $id);
    if (!$p) pcOut(['success' => false, 'message' => 'Project not found.']);

    $checks = json_decode((string) ($p['checklist'] ?? ''), true) ?: [];
    if (($_POST['value'] ?? '') === '1') $checks[$key] = date('Y-m-d H:i:s');
    else unset($checks[$key]);
    $json = json_encode($checks);

    $st = $conn->prepare("UPDATE noblepc_project SET checklist = ?, updated_by = ?, updated_at = NOW() WHERE id = ?");
    $st->bind_param('sii', $json, $currentUserId, $id);
    $st->execute();
    $st->close();
    pcOut(['success' => true, 'checks' => $checks]);
}

// ================= TIMELINE =================
if ($action === 'save_task') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') pcOut(['success' => false, 'message' => 'Invalid request.']);
    $pid      = intval($_POST['project_id'] ?? 0);
    $tid      = intval($_POST['task_id'] ?? 0);
    $category = mb_substr(trim($_POST['category'] ?? ''), 0, 150);
    $name     = mb_substr(trim($_POST['name'] ?? ''), 0, 200);
    $start    = pcValidDate($_POST['start_date'] ?? '');
    $end      = pcValidDate($_POST['end_date'] ?? '');
    $aStart   = pcValidDate($_POST['actual_start'] ?? '');
    $aEnd     = pcValidDate($_POST['actual_end'] ?? '');
    $progress = max(0, min(100, intval($_POST['progress'] ?? 0)));
    $remarks  = mb_substr(trim($_POST['remarks'] ?? ''), 0, 500);

    if (!pcProject($conn, $pid)) pcOut(['success' => false, 'message' => 'Project not found.']);
    if ($category === '' || $name === '') pcOut(['success' => false, 'message' => 'Category and task are required.']);
    if (!$start || !$end) pcOut(['success' => false, 'message' => 'Planned start and end dates are required.']);
    if ($end < $start) pcOut(['success' => false, 'message' => 'End date cannot be earlier than the start date.']);
    if ($aStart && $aEnd && $aEnd < $aStart) pcOut(['success' => false, 'message' => 'Actual end cannot be earlier than actual start.']);
    if ($progress === 100 && !$aEnd) $aEnd = date('Y-m-d');
    if ($progress > 0 && !$aStart) $aStart = min($start, date('Y-m-d'));

    if ($tid > 0) {
        $st = $conn->prepare("
            UPDATE noblepc_timeline SET category = ?, name = ?, start_date = ?, end_date = ?, actual_start = ?, actual_end = ?,
                   progress = ?, remarks = ?, updated_by = ?, updated_at = NOW()
            WHERE id = ? AND project_id = ?
        ");
        $st->bind_param('ssssssisiii', $category, $name, $start, $end, $aStart, $aEnd, $progress, $remarks, $currentUserId, $tid, $pid);
    } else {
        // ilagay sa dulo ng kategorya nito (o sa dulo ng lahat kung bago ang kategorya)
        $q = $conn->prepare("SELECT COALESCE(MAX(sort_order), 0) FROM noblepc_timeline WHERE project_id = ?");
        $q->bind_param('i', $pid);
        $q->execute();
        $sort = (int) $q->get_result()->fetch_row()[0] + 10;
        $q->close();
        $st = $conn->prepare("
            INSERT INTO noblepc_timeline (project_id, category, name, start_date, end_date, actual_start, actual_end, progress, remarks, sort_order, updated_by, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $st->bind_param('issssssisii', $pid, $category, $name, $start, $end, $aStart, $aEnd, $progress, $remarks, $sort, $currentUserId);
    }
    $st->execute();
    $st->close();
    pcOut(['success' => true]);
}

if ($action === 'delete_task') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') pcOut(['success' => false, 'message' => 'Invalid request.']);
    $pid = intval($_POST['project_id'] ?? 0);
    $tid = intval($_POST['task_id'] ?? 0);
    $st = $conn->prepare("DELETE FROM noblepc_timeline WHERE id = ? AND project_id = ?");
    $st->bind_param('ii', $tid, $pid);
    $st->execute();
    $st->close();
    pcOut(['success' => true]);
}

// Template: sunod-sunod na gawain simula sa napiling petsa (kapag wala pang laman ang timeline)
if ($action === 'apply_template') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') pcOut(['success' => false, 'message' => 'Invalid request.']);
    $pid   = intval($_POST['project_id'] ?? 0);
    $start = pcValidDate($_POST['start_date'] ?? '') ?: date('Y-m-d');
    if (!pcProject($conn, $pid)) pcOut(['success' => false, 'message' => 'Project not found.']);

    $c = $conn->prepare("SELECT COUNT(*) FROM noblepc_timeline WHERE project_id = ?");
    $c->bind_param('i', $pid);
    $c->execute();
    if ((int) $c->get_result()->fetch_row()[0] > 0) pcOut(['success' => false, 'message' => 'The timeline already has tasks.']);
    $c->close();

    $st = $conn->prepare("INSERT INTO noblepc_timeline (project_id, category, name, start_date, end_date, progress, sort_order, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?, NOW())");
    $day = new DateTime($start);
    foreach (PC_TEMPLATE as $k => [$cat, $name, $days]) {
        $s1 = $day->format('Y-m-d');
        $e1 = (clone $day)->modify('+' . ($days - 1) . ' day')->format('Y-m-d');
        $sort = ($k + 1) * 10;
        $st->bind_param('issssii', $pid, $cat, $name, $s1, $e1, $sort, $currentUserId);
        $st->execute();
        $day->modify('+' . $days . ' day');
    }
    $st->close();
    pcOut(['success' => true]);
}

// mabilisang update ng progress (slider sa listahan)
if ($action === 'task_progress') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') pcOut(['success' => false, 'message' => 'Invalid request.']);
    $pid = intval($_POST['project_id'] ?? 0);
    $tid = intval($_POST['task_id'] ?? 0);
    $progress = max(0, min(100, intval($_POST['progress'] ?? 0)));
    $today = date('Y-m-d');
    $st = $conn->prepare("
        UPDATE noblepc_timeline
        SET progress = ?,
            actual_start = CASE WHEN ? > 0 AND actual_start IS NULL THEN LEAST(start_date, ?) ELSE actual_start END,
            actual_end   = CASE WHEN ? = 100 THEN COALESCE(actual_end, ?) ELSE NULL END,
            updated_by = ?, updated_at = NOW()
        WHERE id = ? AND project_id = ?
    ");
    $st->bind_param('iisisiii', $progress, $progress, $today, $progress, $today, $currentUserId, $tid, $pid);
    $st->execute();
    $st->close();
    pcOut(['success' => true]);
}

// =====================================================================
//  SIMPLE LISTS: permits, workers, client log, punch list (iisang CRUD)
// =====================================================================
const PC_ENTITIES = [
    'permit' => ['table' => 'noblepc_permit', 'fields' => [
        'permit_type' => ['s', 150, true], 'authority' => ['s', 150], 'date_needed' => ['d'], 'submitted_at' => ['d'],
        'approved_at' => ['d'], 'status' => ['e', ['Needed', 'Submitted', 'Approved', 'Rejected']], 'ref_no' => ['s', 100], 'remarks' => ['s', 500],
    ]],
    'worker' => ['table' => 'noblepc_worker', 'fields' => [
        'name' => ['s', 150, true], 'kind' => ['e', ['Worker', 'Subcontractor']], 'role' => ['s', 100], 'contact' => ['s', 50],
        'scope' => ['s', 255], 'start_date' => ['d'], 'end_date' => ['d'], 'status' => ['e', ['Active', 'Standby', 'Done']], 'remarks' => ['s', 500],
    ]],
    'clientlog' => ['table' => 'noblepc_clientlog', 'fields' => [
        'log_date' => ['d', true], 'type' => ['e', ['Update', 'Site Condition', 'Schedule', 'Delay', 'Change Request', 'Inspection', 'Concern']],
        'subject' => ['s', 200, true], 'details' => ['s', 2000], 'contact_person' => ['s', 150],
        'needs_approval' => ['b'], 'approved_at' => ['d'],
    ]],
    'punch' => ['table' => 'noblepc_punch', 'fields' => [
        'area' => ['s', 150], 'description' => ['s', 500, true], 'responsible' => ['s', 150], 'target_date' => ['d'],
        'status' => ['e', ['Open', 'Fixed', 'Verified']], 'remarks' => ['s', 500],
    ]],
];

if ($action === 'save_entity') {
    pcRequirePost();
    $ent = PC_ENTITIES[$_POST['entity'] ?? ''] ?? null;
    if (!$ent) pcOut(['success' => false, 'message' => 'Invalid item type.']);
    $pid = intval($_POST['project_id'] ?? 0);
    $rid = intval($_POST['row_id'] ?? 0);
    if (!pcProject($conn, $pid)) pcOut(['success' => false, 'message' => 'Project not found.']);

    $cols = []; $types = ''; $vals = [];
    foreach ($ent['fields'] as $col => $def) {
        $kind = $def[0];
        $required = ($kind === 's' && !empty($def[2])) || ($kind === 'd' && !empty($def[1]));
        if ($kind === 's') {
            $v = pcStr($col, $def[1]);
            if ($required && $v === '') pcOut(['success' => false, 'message' => 'Please fill in the required fields.']);
            $v = $v === '' ? null : $v; $t = 's';
        } elseif ($kind === 'd') {
            $v = pcValidDate($_POST[$col] ?? '');
            if ($required && !$v) pcOut(['success' => false, 'message' => 'Please enter a valid date.']);
            $t = 's';
        } elseif ($kind === 'e') {
            $v = in_array($_POST[$col] ?? '', $def[1], true) ? $_POST[$col] : $def[1][0]; $t = 's';
        } else { // b
            $v = in_array($_POST[$col] ?? '', ['1', 'true', 'on'], true) ? 1 : 0; $t = 'i';
        }
        $cols[] = $col; $types .= $t; $vals[] = $v;
    }

    $table = $ent['table'];
    // punch list: itala kung kailan na-fix / na-verify
    $extraSet = '';
    if ($table === 'noblepc_punch') {
        $st = $vals[array_search('status', $cols, true)];
        $extraSet = ", fixed_at = CASE WHEN '$st' IN ('Fixed','Verified') THEN COALESCE(fixed_at, NOW()) ELSE NULL END"
                  . ", verified_at = CASE WHEN '$st' = 'Verified' THEN COALESCE(verified_at, NOW()) ELSE NULL END";
    }

    if ($rid > 0) {
        $set = implode(', ', array_map(fn($c) => "`$c` = ?", $cols));
        pcRun($conn, "UPDATE $table SET $set $extraSet, updated_by = ?, updated_at = NOW() WHERE id = ? AND project_id = ?",
            $types . 'iii', array_merge($vals, [$currentUserId, $rid, $pid]));
    } else {
        $rid = pcRun($conn, "INSERT INTO $table (project_id, `" . implode('`, `', $cols) . "`, updated_by, updated_at) VALUES (?" . str_repeat(', ?', count($cols)) . ", ?, NOW())",
            'i' . $types . 'i', array_merge([$pid], $vals, [$currentUserId]));
        if ($extraSet !== '') pcRun($conn, "UPDATE $table SET updated_at = NOW() " . $extraSet . " WHERE id = ?", 'i', [$rid]);
    }
    pcOut(['success' => true, 'id' => $rid]);
}

if ($action === 'delete_entity') {
    pcRequirePost();
    $ent = PC_ENTITIES[$_POST['entity'] ?? ''] ?? null;
    if (!$ent) pcOut(['success' => false, 'message' => 'Invalid item type.']);
    $pid = intval($_POST['project_id'] ?? 0);
    $rid = intval($_POST['row_id'] ?? 0);
    pcRun($conn, "DELETE FROM {$ent['table']} WHERE id = ? AND project_id = ?", 'ii', [$rid, $pid]);
    if ($ent['table'] === 'noblepc_worker') pcRun($conn, "DELETE FROM noblepc_attendance WHERE worker_id = ?", 'i', [$rid]);
    pcOut(['success' => true]);
}

// Attendance: isang araw, isang worker
if ($action === 'set_attendance') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $wid = intval($_POST['worker_id'] ?? 0);
    $date = pcValidDate($_POST['work_date'] ?? '');
    $present = ($_POST['present'] ?? '') === '1' ? 1 : 0;
    if (!$date) pcOut(['success' => false, 'message' => 'Invalid date.']);
    if ($date > date('Y-m-d')) pcOut(['success' => false, 'message' => 'Attendance cannot be set for a future date.']);
    if (!pcOne($conn, "SELECT id FROM noblepc_worker WHERE id = ? AND project_id = ?", 'ii', [$wid, $pid])) pcOut(['success' => false, 'message' => 'Worker not found.']);
    pcRun($conn, "INSERT INTO noblepc_attendance (project_id, worker_id, work_date, present, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, NOW())
                  ON DUPLICATE KEY UPDATE present = VALUES(present), updated_by = VALUES(updated_by), updated_at = NOW()",
        'iisii', [$pid, $wid, $date, $present, $currentUserId]);
    pcOut(['success' => true]);
}

// =====================================================================
//  DELIVERY RECEIPT
// =====================================================================
if ($action === 'save_delivery') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $did = intval($_POST['delivery_id'] ?? 0);
    $p = pcProject($conn, $pid);
    if (!$p) pcOut(['success' => false, 'message' => 'Project not found.']);

    $date = pcValidDate($_POST['dr_date'] ?? '') ?: date('Y-m-d');
    $client = pcStr('client_name'); $addr = pcStr('address'); $sched = pcValidDate($_POST['scheduled_date'] ?? '');
    $vehicle = pcStr('vehicle', 150); $notes = pcStr('notes', 1000);
    if ($client === '') pcOut(['success' => false, 'message' => 'Client name is required.']);

    $items = [];
    foreach ((array) ($_POST['particular'] ?? []) as $i => $part) {
        $part = mb_substr(trim((string) $part), 0, 255);
        if ($part === '') continue;
        $items[] = [
            $part, mb_substr(trim((string) ($_POST['size'][$i] ?? '')), 0, 100),
            max(0, (float) ($_POST['qty'][$i] ?? 0)), mb_substr(trim((string) ($_POST['unit'][$i] ?? '')), 0, 30),
            round(max(0, (float) str_replace(',', '', (string) ($_POST['amount'][$i] ?? 0))), 2),
        ];
    }
    if (!$items) pcOut(['success' => false, 'message' => 'Add at least one item.']);

    $conn->begin_transaction();
    try {
        if ($did > 0) {
            $cur = pcOne($conn, "SELECT status FROM noblepc_delivery WHERE id = ? AND project_id = ?", 'ii', [$did, $pid]);
            if (!$cur) throw new RuntimeException('Delivery receipt not found.');
            if ($cur['status'] === 'Delivered') throw new RuntimeException('Delivered receipts can no longer be edited.');
            pcRun($conn, "UPDATE noblepc_delivery SET dr_date = ?, client_name = ?, address = ?, scheduled_date = ?, vehicle = ?, notes = ?, updated_by = ?, updated_at = NOW() WHERE id = ?",
                'ssssssii', [$date, $client, $addr, $sched, $vehicle, $notes, $currentUserId, $did]);
            pcRun($conn, "DELETE FROM noblepc_delivery_item WHERE delivery_id = ?", 'i', [$did]);
        } else {
            $drNo = pcNextNo($conn, 'noblepc_delivery', 'dr_no', date('Y') . '06-', 3);
            $me = pcUserName($conn, $currentUserId);
            $did = pcRun($conn, "INSERT INTO noblepc_delivery (project_id, dr_no, dr_date, client_name, address, scheduled_date, vehicle, notes, status, prepared_by, created_by, created_at, updated_by, updated_at)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Scheduled', ?, ?, NOW(), ?, NOW())",
                'issssssssii', [$pid, $drNo, $date, $client, $addr, $sched, $vehicle, $notes, $me, $currentUserId, $currentUserId]);
        }
        foreach ($items as $k => [$part, $size, $qty, $unit, $amt]) {
            $no = $k + 1;
            pcRun($conn, "INSERT INTO noblepc_delivery_item (delivery_id, item_no, particular, size, qty, unit, amount) VALUES (?, ?, ?, ?, ?, ?, ?)",
                'iissdsd', [$did, $no, $part, $size, $qty, $unit, $amt]);
        }
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        pcOut(['success' => false, 'message' => $e instanceof RuntimeException ? $e->getMessage() : 'Could not save the delivery receipt.']);
    }
    pcOut(['success' => true, 'id' => $did]);
}

if ($action === 'deliver_receipt') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $did = intval($_POST['delivery_id'] ?? 0);
    $date = pcValidDate($_POST['delivered_at'] ?? '');
    $rcv = pcStr('received_by', 150);
    if (!$date || $date > date('Y-m-d')) pcOut(['success' => false, 'message' => 'Enter a valid delivery date (not in the future).']);
    if ($rcv === '') pcOut(['success' => false, 'message' => 'Enter who received the delivery.']);
    $n = pcRun($conn, "UPDATE noblepc_delivery SET status = 'Delivered', delivered_at = ?, received_by = ?, updated_by = ?, updated_at = NOW() WHERE id = ? AND project_id = ? AND status <> 'Delivered'",
        'ssiii', [$date, $rcv, $currentUserId, $did, $pid]);
    if ($n < 1) pcOut(['success' => false, 'message' => 'This receipt is already delivered.']);
    pcOut(['success' => true]);
}

if ($action === 'delete_delivery') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $did = intval($_POST['delivery_id'] ?? 0);
    $n = pcRun($conn, "DELETE FROM noblepc_delivery WHERE id = ? AND project_id = ? AND status <> 'Delivered'", 'ii', [$did, $pid]);
    if ($n < 1) pcOut(['success' => false, 'message' => 'Delivered receipts cannot be deleted.']);
    pcRun($conn, "DELETE FROM noblepc_delivery_item WHERE delivery_id = ?", 'i', [$did]);
    pcOut(['success' => true]);
}

// =====================================================================
//  SUBCONTRACTOR QUOTATION (Labor Only)
// =====================================================================
if ($action === 'save_quote') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $qid = intval($_POST['quote_id'] ?? 0);
    if (!pcProject($conn, $pid)) pcOut(['success' => false, 'message' => 'Project not found.']);

    $sub = pcStr('subcontractor', 150); $subj = pcStr('subject', 255) ?: 'Quotation for Works (Labor Only)';
    $date = pcValidDate($_POST['quote_date'] ?? '') ?: date('Y-m-d');
    $dur = max(0, intval($_POST['duration_days'] ?? 0));
    $dp = max(0, min(100, (float) ($_POST['downpayment_pct'] ?? 30)));
    $terms = pcStr('terms', 2000);
    if ($sub === '') pcOut(['success' => false, 'message' => 'Subcontractor name is required.']);

    $items = [];
    foreach ((array) ($_POST['item_name'] ?? []) as $i => $name) {
        $name = mb_substr(trim((string) $name), 0, 255);
        if ($name === '') continue;
        $qty = max(0, (float) ($_POST['qty'][$i] ?? 0));
        $cost = max(0, (float) str_replace(',', '', (string) ($_POST['unit_cost'][$i] ?? 0)));
        $items[] = [mb_substr(trim((string) ($_POST['section'][$i] ?? '')), 0, 150), $name, $qty,
            mb_substr(trim((string) ($_POST['unit'][$i] ?? '')), 0, 30), round($cost, 2), round($qty * $cost, 2)];
    }
    if (!$items) pcOut(['success' => false, 'message' => 'Add at least one item.']);

    $conn->begin_transaction();
    try {
        if ($qid > 0) {
            if (!pcOne($conn, "SELECT id FROM noblepc_subcon_quote WHERE id = ? AND project_id = ?", 'ii', [$qid, $pid])) throw new RuntimeException('Quotation not found.');
            pcRun($conn, "UPDATE noblepc_subcon_quote SET subcontractor = ?, subject = ?, quote_date = ?, duration_days = ?, downpayment_pct = ?, terms = ?, updated_by = ?, updated_at = NOW() WHERE id = ?",
                'sssidsii', [$sub, $subj, $date, $dur, $dp, $terms, $currentUserId, $qid]);
            pcRun($conn, "DELETE FROM noblepc_subcon_quote_item WHERE quote_id = ?", 'i', [$qid]);
        } else {
            $qid = pcRun($conn, "INSERT INTO noblepc_subcon_quote (project_id, subcontractor, subject, quote_date, duration_days, downpayment_pct, terms, created_by, created_at, updated_by, updated_at)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, NOW())",
                'isssidsii', [$pid, $sub, $subj, $date, $dur, $dp, $terms, $currentUserId, $currentUserId]);
        }
        foreach ($items as $k => [$sec, $name, $qty, $unit, $cost, $amt]) {
            $so = ($k + 1) * 10;
            pcRun($conn, "INSERT INTO noblepc_subcon_quote_item (quote_id, section, item_name, qty, unit, unit_cost, amount, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                'issdsddi', [$qid, $sec, $name, $qty, $unit, $cost, $amt, $so]);
        }
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        pcOut(['success' => false, 'message' => $e instanceof RuntimeException ? $e->getMessage() : 'Could not save the quotation.']);
    }
    pcOut(['success' => true, 'id' => $qid]);
}

if ($action === 'delete_quote') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $qid = intval($_POST['quote_id'] ?? 0);
    if (pcOne($conn, "SELECT id FROM noblepc_billing WHERE quote_id = ? LIMIT 1", 'i', [$qid])) pcOut(['success' => false, 'message' => 'This quotation already has progress billings.']);
    pcRun($conn, "DELETE FROM noblepc_subcon_quote WHERE id = ? AND project_id = ?", 'ii', [$qid, $pid]);
    pcRun($conn, "DELETE FROM noblepc_subcon_quote_item WHERE quote_id = ?", 'i', [$qid]);
    pcOut(['success' => true]);
}

// =====================================================================
//  PROGRESS BILLING (Application for Payment) — bawat subcon quotation
// =====================================================================
if ($action === 'save_billing') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $bid = intval($_POST['billing_id'] ?? 0);
    $qid = intval($_POST['quote_id'] ?? 0);
    $p = pcProject($conn, $pid);
    if (!$p) pcOut(['success' => false, 'message' => 'Project not found.']);
    $quote = pcOne($conn, "SELECT * FROM noblepc_subcon_quote WHERE id = ? AND project_id = ?", 'ii', [$qid, $pid]);
    if (!$quote) pcOut(['success' => false, 'message' => 'Choose the subcontractor quotation first.']);
    $contract = (float) (pcOne($conn, "SELECT COALESCE(SUM(amount),0) AS t FROM noblepc_subcon_quote_item WHERE quote_id = ?", 'i', [$qid])['t'] ?? 0);

    $date = pcValidDate($_POST['billing_date'] ?? '') ?: date('Y-m-d');
    $period = pcStr('period', 100); $desc = pcStr('description', 255);
    $amount = max(0, pcNum('amount'));
    $co = pcNum('change_orders');
    $ret = max(0, min(100, (float) ($_POST['retainage_pct'] ?? 0)));
    $remarks = pcStr('remarks', 500);
    if ($desc === '') pcOut(['success' => false, 'message' => 'Description of work is required.']);
    if ($amount <= 0) pcOut(['success' => false, 'message' => 'Amount this period must be more than zero.']);

    // hindi puwedeng lumampas sa contract sum
    $others = (float) (pcOne($conn, "SELECT COALESCE(SUM(amount),0) AS t FROM noblepc_billing WHERE quote_id = ? AND id <> ?", 'ii', [$qid, $bid])['t'] ?? 0);
    $cos = (float) (pcOne($conn, "SELECT COALESCE(SUM(change_orders),0) AS t FROM noblepc_billing WHERE quote_id = ? AND id <> ?", 'ii', [$qid, $bid])['t'] ?? 0);
    if ($others + $amount > $contract + $cos + $co + 0.009) {
        pcOut(['success' => false, 'message' => 'Total billed would exceed the contract sum (₱' . number_format($contract + $cos + $co, 2) . ').']);
    }

    $conn->begin_transaction();
    try {
        if ($bid > 0) {
            $cur = pcOne($conn, "SELECT status FROM noblepc_billing WHERE id = ? AND project_id = ?", 'ii', [$bid, $pid]);
            if (!$cur) throw new RuntimeException('Billing not found.');
            if ($cur['status'] !== 'Draft') throw new RuntimeException('Only draft billings can be edited.');
            pcRun($conn, "UPDATE noblepc_billing SET billing_date = ?, period = ?, description = ?, amount = ?, change_orders = ?, retainage_pct = ?, remarks = ?, updated_by = ?, updated_at = NOW() WHERE id = ?",
                'sssdddsii', [$date, $period, $desc, $amount, $co, $ret, $remarks, $currentUserId, $bid]);
        } else {
            $initials = strtoupper(preg_replace('/[^A-Za-z]/', '', (string) $quote['subcontractor'])) ?: 'SUB';
            $appNo = pcNextNo($conn, 'noblepc_billing', 'app_no', 'AFP-' . substr($initials, 0, 8) . '-' . date('Ymd', strtotime($date)) . '-', 3);
            $me = pcUserName($conn, $currentUserId);
            $bid = pcRun($conn, "INSERT INTO noblepc_billing (project_id, quote_id, app_no, billing_date, period, description, amount, change_orders, retainage_pct, remarks, status, prepared_by, created_by, created_at, updated_by, updated_at)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Draft', ?, ?, NOW(), ?, NOW())",
                'iissssdddssii', [$pid, $qid, $appNo, $date, $period, $desc, $amount, $co, $ret, $remarks, $me, $currentUserId, $currentUserId]);
        }
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        pcOut(['success' => false, 'message' => $e instanceof RuntimeException ? $e->getMessage() : 'Could not save the billing.']);
    }
    pcOut(['success' => true, 'id' => $bid]);
}

if ($action === 'billing_status') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $bid = intval($_POST['billing_id'] ?? 0);
    $to = $_POST['status'] ?? '';
    $flow = ['Draft' => 'Submitted', 'Submitted' => 'Paid'];
    $cur = pcOne($conn, "SELECT status FROM noblepc_billing WHERE id = ? AND project_id = ?", 'ii', [$bid, $pid]);
    if (!$cur) pcOut(['success' => false, 'message' => 'Billing not found.']);
    if (($flow[$cur['status']] ?? '') !== $to) pcOut(['success' => false, 'message' => 'This billing cannot move to ' . $to . '.']);
    $col = $to === 'Submitted' ? 'submitted_at' : 'paid_at';
    pcRun($conn, "UPDATE noblepc_billing SET status = ?, $col = NOW(), updated_by = ?, updated_at = NOW() WHERE id = ?", 'sii', [$to, $currentUserId, $bid]);
    pcOut(['success' => true]);
}

if ($action === 'delete_billing') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $bid = intval($_POST['billing_id'] ?? 0);
    $n = pcRun($conn, "DELETE FROM noblepc_billing WHERE id = ? AND project_id = ? AND status = 'Draft'", 'ii', [$bid, $pid]);
    if ($n < 1) pcOut(['success' => false, 'message' => 'Only draft billings can be deleted.']);
    pcOut(['success' => true]);
}

// =====================================================================
//  TURNOVER
// =====================================================================
if ($action === 'save_turnover') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    if (!pcProject($conn, $pid)) pcOut(['success' => false, 'message' => 'Project not found.']);
    $cur = pcOne($conn, "SELECT turned_over_at FROM noblepc_turnover WHERE project_id = ?", 'i', [$pid]);
    if ($cur && $cur['turned_over_at']) pcOut(['success' => false, 'message' => 'This project is already turned over.']);

    $date = pcValidDate($_POST['turnover_date'] ?? '') ?: date('Y-m-d');
    $items = [];
    foreach ((array) ($_POST['scope'] ?? []) as $i => $sc) {
        $sc = mb_substr(trim((string) $sc), 0, 255);
        if ($sc === '') continue;
        $items[] = ['scope' => $sc, 'area' => mb_substr(trim((string) ($_POST['area'][$i] ?? '')), 0, 100),
            'status' => mb_substr(trim((string) ($_POST['item_status'][$i] ?? 'Accomplished')), 0, 50) ?: 'Accomplished'];
    }
    if (!$items) pcOut(['success' => false, 'message' => 'Add at least one completed work scope.']);
    $json = json_encode($items, JSON_UNESCAPED_UNICODE);
    $f = [pcStr('project_name'), pcStr('location'), pcStr('contractor'), pcStr('owner_name', 150), pcStr('owner_title', 100) ?: 'Owner',
        pcStr('signatory_name', 150), pcStr('signatory_title', 100), pcStr('documents', 1000)];

    pcRun($conn, "INSERT INTO noblepc_turnover (project_id, turnover_date, project_name, location, contractor, owner_name, owner_title, signatory_name, signatory_title, documents, items, updated_by, updated_at)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                  ON DUPLICATE KEY UPDATE turnover_date = VALUES(turnover_date), project_name = VALUES(project_name), location = VALUES(location),
                      contractor = VALUES(contractor), owner_name = VALUES(owner_name), owner_title = VALUES(owner_title),
                      signatory_name = VALUES(signatory_name), signatory_title = VALUES(signatory_title), documents = VALUES(documents),
                      items = VALUES(items), updated_by = VALUES(updated_by), updated_at = NOW()",
        'issssssssssi', array_merge([$pid, $date], $f, [$json, $currentUserId]));
    pcOut(['success' => true]);
}


// ═════════════ MGA HAKBANG (step by step) ═════════════
if ($action === 'step_duty') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $step = $_POST['step'] ?? '';
    $idx = intval($_POST['index'] ?? -1);
    if (!array_key_exists($step, PC_STEPS) || $idx < 0 || $idx > 20) pcOut(['success' => false, 'message' => 'Invalid item.']);
    if (!pcProject($conn, $pid)) pcOut(['success' => false, 'message' => 'Project not found.']);
    $steps = pcSteps($conn, $pid);
    if ($steps[$step]['status'] !== '') pcOut(['success' => false, 'message' => 'This step is already closed. Reopen it first.']);
    $duties = $steps[$step]['duties'];
    if (($_POST['value'] ?? '') === '1') $duties[] = $idx; else $duties = array_diff($duties, [$idx]);
    $duties = array_values(array_unique($duties)); sort($duties);
    $json = json_encode($duties);
    pcRun($conn, "INSERT INTO noblepc_step (project_id, step_key, duties, updated_by, updated_at) VALUES (?, ?, ?, ?, NOW())
                  ON DUPLICATE KEY UPDATE duties = VALUES(duties), updated_by = VALUES(updated_by), updated_at = NOW()", 'issi', [$pid, $step, $json, $currentUserId]);
    pcOut(['success' => true, 'duties' => $duties]);
}

if ($action === 'step_status') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $step = $_POST['step'] ?? '';
    $to = $_POST['status'] ?? '';
    if (!array_key_exists($step, PC_STEPS) || !in_array($to, ['done', 'na', ''], true)) pcOut(['success' => false, 'message' => 'Invalid request.']);
    if (!pcProject($conn, $pid)) pcOut(['success' => false, 'message' => 'Project not found.']);
    $steps = pcSteps($conn, $pid);
    $keys = array_keys(PC_STEPS);
    $pos = array_search($step, $keys, true);

    if ($to === '') {
        // reopen: bawal kung may sumunod na hakbang na sarado na
        foreach (array_slice($keys, $pos + 1) as $k) {
            if ($steps[$k]['status'] !== '') pcOut(['success' => false, 'message' => 'Reopen the later steps first (Step ' . (array_search($k, $keys, true) + 1) . ' is already closed).']);
        }
    } else {
        if ($steps[$step]['status'] !== '') pcOut(['success' => false, 'message' => 'This step is already closed.']);
        if ($msg = pcPrevStepsDone($steps, $step)) pcOut(['success' => false, 'message' => $msg]);
        if ($to === 'na' && !PC_STEPS[$step]) pcOut(['success' => false, 'message' => 'This step is always required.']);
        if ($to === 'done' && $step === 'turnover') {
            $tv = pcOne($conn, "SELECT turned_over_at FROM noblepc_turnover WHERE project_id = ?", 'i', [$pid]);
            if (!$tv || !$tv['turned_over_at']) pcOut(['success' => false, 'message' => 'Complete the turnover (client signature) first.']);
        }
        if ($to === 'done' && $step === 'punch') {
            $open = (int) (pcOne($conn, "SELECT COUNT(*) AS n FROM noblepc_punch WHERE project_id = ? AND status <> 'Verified'", 'i', [$pid])['n'] ?? 0);
            if ($open) pcOut(['success' => false, 'message' => "There are still $open punch list item(s) that are not verified."]);
        }
        if ($to === 'done' && $step === 'delivery') {
            $open = (int) (pcOne($conn, "SELECT COUNT(*) AS n FROM noblepc_delivery WHERE project_id = ? AND status <> 'Delivered'", 'i', [$pid])['n'] ?? 0);
            if ($open) pcOut(['success' => false, 'message' => "There are still $open delivery receipt(s) without proof of receipt."]);
        }
    }
    $status = $to === '' ? null : $to;
    $by = $to === '' ? null : $currentUserId;
    pcRun($conn, "INSERT INTO noblepc_step (project_id, step_key, status, completed_at, completed_by, updated_by, updated_at) VALUES (?, ?, ?, IF(? IS NULL, NULL, NOW()), ?, ?, NOW())
                  ON DUPLICATE KEY UPDATE status = VALUES(status), completed_at = VALUES(completed_at), completed_by = VALUES(completed_by), updated_by = VALUES(updated_by), updated_at = NOW()",
        'isssii', [$pid, $step, $status, $status, $by, $currentUserId]);
    pcOut(['success' => true, 'steps' => pcSteps($conn, $pid)]);
}

if ($action === 'complete_turnover') {
    pcRequirePost();
    $pid = intval($_POST['project_id'] ?? 0);
    $tv = pcOne($conn, "SELECT * FROM noblepc_turnover WHERE project_id = ?", 'i', [$pid]);
    if (!$tv) pcOut(['success' => false, 'message' => 'Save the turnover letter first.']);
    if ($tv['turned_over_at']) pcOut(['success' => false, 'message' => 'This project is already turned over.']);
    $open = (int) (pcOne($conn, "SELECT COUNT(*) AS n FROM noblepc_punch WHERE project_id = ? AND status <> 'Verified'", 'i', [$pid])['n'] ?? 0);
    if ($open > 0) pcOut(['success' => false, 'message' => "There are still $open punch list item(s) that are not verified."]);
    if (($_POST['confirm'] ?? '') !== '1') pcOut(['success' => false, 'message' => 'Please confirm the client has signed.']);
    if ($msg = pcPrevStepsDone(pcSteps($conn, $pid), 'turnover')) pcOut(['success' => false, 'message' => $msg]);
    $accepted = pcValidDate($_POST['accepted_at'] ?? '') ?: date('Y-m-d');

    $conn->begin_transaction();
    pcRun($conn, "UPDATE noblepc_turnover SET turned_over_at = ?, completed_by = ?, updated_at = NOW() WHERE project_id = ?", 'sii', [$accepted, $currentUserId, $pid]);
    // isara ang proyekto at markahan ang huling control point
    $p = pcProject($conn, $pid);
    $checks = json_decode((string) ($p['checklist'] ?? ''), true) ?: [];
    $checks['turnover'] = $checks['turnover'] ?? date('Y-m-d H:i:s');
    $checks['quality'] = $checks['quality'] ?? date('Y-m-d H:i:s');
    $json = json_encode($checks);
    pcRun($conn, "UPDATE noblepc_project SET status = 'Closed', checklist = ?, updated_by = ?, updated_at = NOW() WHERE id = ?", 'sii', [$json, $currentUserId, $pid]);
    $conn->commit();
    pcOut(['success' => true]);
}

pcOut(['success' => false, 'message' => 'Unknown action.']);
