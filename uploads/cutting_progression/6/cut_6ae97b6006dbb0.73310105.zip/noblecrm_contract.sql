-- Contract Agreement (ginagawa sa system)
-- Daloy: Accounting Head (gawa + pirma) → Sales + Designer (pirma) → Client (link: e-sign + ID) → Superadmin / GM (huling pirma)
-- Isang contract kada inquiry. Kapag ibinalik para itama, babalik sa 'Draft' at uulitin ang pirmahan.

CREATE TABLE IF NOT EXISTS noblecrm_contract (
    id                     INT AUTO_INCREMENT PRIMARY KEY,
    inquiry_id             INT NOT NULL,
    final_id               INT NULL,
    status                 VARCHAR(30) NOT NULL DEFAULT 'Draft',  -- Draft | For Staff Signing | For Client Signing | For GM Signing | Completed
    owner_name             VARCHAR(150) NOT NULL,
    project_name           VARCHAR(150) NOT NULL,
    address                VARCHAR(255) NULL,
    contact_number         VARCHAR(50) NULL,
    start_date             DATE NULL,
    completion_date        DATE NULL,
    contract_amount        DECIMAL(14,2) NOT NULL DEFAULT 0,
    dp_percent             TINYINT UNSIGNED NOT NULL DEFAULT 50,
    delivery_percent       TINYINT UNSIGNED NOT NULL DEFAULT 20,
    install_percent        TINYINT UNSIGNED NOT NULL DEFAULT 20,
    retention_percent      TINYINT UNSIGNED NOT NULL DEFAULT 10,
    dp_paid                TINYINT(1) NOT NULL DEFAULT 0,
    validity_days          SMALLINT UNSIGNED NOT NULL DEFAULT 30,
    remarks                TEXT NULL,          -- huling dahilan ng pagbalik (correction)
    returned_by            INT NULL,
    returned_at            DATETIME NULL,
    created_by             INT NULL,
    created_at             DATETIME NULL,
    updated_at             DATETIME NULL,
    issued_at              DATETIME NULL,      -- petsa sa "this month of ... year ..."

    acct_signed_by         INT NULL,
    acct_signed_at         DATETIME NULL,
    acct_signature_path    VARCHAR(255) NULL,

    sales_user_id          INT NULL,
    sales_signed_at        DATETIME NULL,
    sales_signature_path   VARCHAR(255) NULL,

    designer_user_id       INT NULL,
    designer_signed_at     DATETIME NULL,
    designer_signature_path VARCHAR(255) NULL,

    client_token           CHAR(48) NULL,
    client_signed_name     VARCHAR(150) NULL,
    client_signature_path  VARCHAR(255) NULL,
    client_id_path         VARCHAR(255) NULL,
    client_signed_at       DATETIME NULL,
    client_ip              VARCHAR(45) NULL,

    gm_signed_by           INT NULL,
    gm_signed_at           DATETIME NULL,
    gm_signature_path      VARCHAR(255) NULL,

    UNIQUE KEY uq_contract_inquiry (inquiry_id),
    UNIQUE KEY uq_contract_token (client_token),
    KEY idx_contract_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
