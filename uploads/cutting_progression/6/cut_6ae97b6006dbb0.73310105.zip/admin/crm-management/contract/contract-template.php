<?php
// contract-template.php — Contract Agreement ng NobleHome (template + helpers)
// Ginagamit ng: contracts.php / contractsajax.php (staff), contract-pdf.php (PDF), contract-sign.php (client link)
//
// ⚠️ Ang mga clause ay kinopya mula sa papel na contract ng NobleHome.
//    Kung may babaguhin sa wording, dito lang (nhcRenderContract) — lahat ng page ay susunod.

if (defined('NHC_LOADED')) {
    return;
}
define('NHC_LOADED', true);

const NHC_STATUSES = ['Draft', 'For Staff Signing', 'For Client Signing', 'For GM Signing', 'Completed'];

// Logo sa letterhead (palitan kung iba ang path ng logo ninyo). Kapag wala, text lang ang lalabas.
const NHC_LOGO_CANDIDATES = [
    '/icon/logo.png',
    '/icon/logo.webp',
];

// Folder ng client signature + ID (naka-block sa direct access — sa ajax lang mabubuksan)
const NHC_PRIVATE_DIR = '/uploads/crm-contract-private/';

const NHC_COMPANY = [
    'name'    => 'NOBLEHOME CONSTRUCTION CORPORATION',
    'address' => '1181MC Premiere Bldg., EDSA Balintawak Quezon City',
    'contact' => 'noblehomeconst.ph@gmail.com / Tel. No. 02-88221295 / Cell. No. 0968-591-6544',
];

function nhcEsc($v): string
{
    return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8');
}

function nhcMoney($v): string
{
    return number_format((float) $v, 2);
}

function nhcDateLong(?string $d): string
{
    if (!$d || $d === '0000-00-00') return '____________';
    $t = strtotime($d);
    return $t ? date('F j, Y', $t) : '____________';
}

function nhcDateShort(?string $d): string
{
    if (!$d) return '';
    $t = strtotime($d);
    return $t ? date('m/d/Y', $t) : '';
}

/** 0–100 → "Ten", "Twenty-five", ... (para sa "Ten percent (10%)") */
function nhcPercentWords(int $n): string
{
    $ones = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
        'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    $tens = [2 => 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
    if ($n >= 100) return 'One hundred';
    if ($n < 20) return ucfirst($ones[max(0, $n)]);
    $w = $tens[intdiv($n, 10)] . ($n % 10 ? '-' . $ones[$n % 10] : '');
    return ucfirst($w);
}

function nhcDpAmount(array $c): float
{
    return round((float) $c['contract_amount'] * (int) $c['dp_percent'] / 100, 2);
}

function nhcBalance(array $c): float
{
    $total = (float) $c['contract_amount'];
    return !empty($c['dp_paid']) ? round($total - nhcDpAmount($c), 2) : $total;
}

/** Buong row ng contract + pangalan ng mga pumirma. */
function nhcLoad(mysqli $conn, string $where, string $types, array $params): ?array
{
    $sql = "
        SELECT c.*, i.control_no, i.client_name, i.sales_staff_id, i.designer_id,
               ar.name AS acct_name, sr.name AS sales_name, dr.name AS designer_name, gr.name AS gm_name
        FROM noblecrm_contract c
        JOIN noblecrminquiry i ON i.id = c.inquiry_id
        LEFT JOIN noblerole ar ON ar.id = c.acct_signed_by
        LEFT JOIN noblerole sr ON sr.id = c.sales_user_id
        LEFT JOIN noblerole dr ON dr.id = c.designer_user_id
        LEFT JOIN noblerole gr ON gr.id = c.gm_signed_by
        WHERE {$where}
        LIMIT 1";
    $st = $conn->prepare($sql);
    $st->bind_param($types, ...$params);
    $st->execute();
    $row = $st->get_result()->fetch_assoc();
    $st->close();
    return $row ?: null;
}

/** Larawan → data URI (para sa PDF at para hindi ma-expose ang private na path). */
function nhcImgData(?string $relPath): string
{
    if (!$relPath) return '';
    $abs = ROOT_PATH . '/' . ltrim($relPath, '/');
    if (!is_file($abs) || filesize($abs) > 8 * 1024 * 1024) return '';
    $info = @getimagesize($abs);
    if (!$info || empty($info['mime'])) return '';
    return 'data:' . $info['mime'] . ';base64,' . base64_encode((string) file_get_contents($abs));
}

function nhcLogoData(): string
{
    foreach (NHC_LOGO_CANDIDATES as $p) {
        $d = nhcImgData($p);
        if ($d !== '') return $d;
    }
    return '';
}

/** Lahat ng larawan ng isang contract bilang data URI. */
function nhcImages(array $c): array
{
    return [
        'logo'     => nhcLogoData(),
        'acct'     => nhcImgData($c['acct_signature_path'] ?? null),
        'sales'    => nhcImgData($c['sales_signature_path'] ?? null),
        'designer' => nhcImgData($c['designer_signature_path'] ?? null),
        'client'   => nhcImgData($c['client_signature_path'] ?? null),
        'gm'       => nhcImgData($c['gm_signature_path'] ?? null),
    ];
}

function nhcCss(): string
{
    return <<<CSS
    .nhc-doc { font-family: "DejaVu Serif", Cambria, Georgia, "Times New Roman", serif; color: #111; font-size: 11.5pt; line-height: 1.45; }
    .nhc-doc p { margin: 0 0 7pt 0; text-align: justify; }
    .nhc-head { text-align: center; border-bottom: 1px solid #b45309; padding-bottom: 6pt; margin-bottom: 10pt; }
    .nhc-head td { vertical-align: middle; }
    .nhc-head .co { font-family: "DejaVu Sans", Arial, sans-serif; font-weight: bold; font-size: 13pt; letter-spacing: .3pt; }
    .nhc-head .sub { font-family: "DejaVu Sans", Arial, sans-serif; font-size: 8pt; color: #444; font-style: italic; }
    .nhc-title { text-align: center; font-weight: bold; font-size: 14pt; margin: 6pt 0 12pt; letter-spacing: .5pt; }
    .nhc-art { font-weight: bold; margin: 12pt 0 5pt; text-transform: uppercase; }
    .nhc-sub { font-weight: bold; margin: 8pt 0 4pt 8pt; }
    .nhc-ind { margin-left: 16pt !important; }
    .nhc-list { margin: 0 0 7pt 0; padding-left: 26pt; }
    .nhc-list li { margin-bottom: 3pt; text-align: justify; }
    .nhc-fill { font-weight: bold; text-decoration: underline; }
    .nhc-page { page-break-before: always; }
    .nhc-sign { width: 100%; border-collapse: collapse; margin-top: 8pt; }
    .nhc-sign td { width: 50%; vertical-align: bottom; padding: 10pt 12pt 6pt 0; }
    .nhc-sigbox { height: 52pt; position: relative; }
    .nhc-sigbox img { max-height: 52pt; max-width: 170pt; }
    .nhc-signame { border-top: 1px solid #111; font-weight: bold; text-transform: uppercase; padding-top: 2pt; font-family: "DejaVu Sans", Arial, sans-serif; font-size: 10pt; }
    .nhc-sigrole { font-style: italic; font-size: 10pt; }
    .nhc-sigdate { font-size: 10pt; }
    .nhc-pending { color: #9ca3af; font-style: italic; font-size: 9pt; }
    .nhc-info td { padding: 1.5pt 0; font-size: 10.5pt; vertical-align: top; }
    .nhc-info td.k { font-weight: bold; white-space: nowrap; padding-right: 6pt; }
    CSS;
}

/** Buong HTML document para sa dompdf (letterhead sa bawat page). */
function nhcPdfHtml(array $c, array $img): string
{
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>'
        . '@page { margin: 118px 56px 56px 56px; }'
        . 'body { margin: 0; }'
        . '#nhc-fixed-head { position: fixed; top: -100px; left: 0; right: 0; }'
        . '#nhc-fixed-foot { position: fixed; bottom: -36px; left: 0; right: 0; text-align: center; font-family: "DejaVu Sans", Arial, sans-serif; font-size: 7.5pt; color: #777; }'
        . nhcCss()
        . '</style></head><body>'
        . '<div id="nhc-fixed-head">' . nhcHeaderHtml($img) . '</div>'
        . '<div id="nhc-fixed-foot">Control No. ' . nhcEsc($c['control_no'] ?? '') . ' &middot; Contract Agreement</div>'
        . nhcRenderContract($c, $img, true)
        . '</body></html>';
}

function nhcHeaderHtml(array $img): string
{
    $logo = $img['logo'] ?? '';
    $logoCell = $logo !== '' ? '<td style="width:62pt;text-align:right;padding-right:8pt"><img src="' . $logo . '" style="height:46pt"></td>' : '';
    return '<table class="nhc-head" style="width:100%;border-collapse:collapse"><tr>' . $logoCell . '<td>'
        . '<div class="co">' . nhcEsc(NHC_COMPANY['name']) . '</div>'
        . '<div class="sub">' . nhcEsc(NHC_COMPANY['address']) . '</div>'
        . '<div class="sub">' . nhcEsc(NHC_COMPANY['contact']) . '</div>'
        . '</td>' . ($logo !== '' ? '<td style="width:62pt"></td>' : '') . '</tr></table>';
}

/** Isang linya ng pirma (signature image + pangalan + posisyon + petsa). */
function nhcSignCell(string $img, ?string $name, string $role, ?string $signedAt, string $pendingText): string
{
    $sig = $img !== '' ? '<img src="' . $img . '" alt="signature">' : '<span class="nhc-pending">' . nhcEsc($pendingText) . '</span>';
    return '<div class="nhc-sigbox">' . $sig . '</div>'
        . '<div class="nhc-signame">' . nhcEsc($name ?: '______________________') . '</div>'
        . '<div class="nhc-sigrole">' . nhcEsc($role) . '</div>'
        . '<div class="nhc-sigdate">Date: ' . nhcEsc($signedAt ? nhcDateShort($signedAt) : '__________') . '</div>';
}

/**
 * Buong contract (HTML). $img = nhcImages($c) o katulad.
 * $c ay row ng noblecrm_contract (+ names galing nhcLoad), o draft values mula sa form.
 */
function nhcRenderContract(array $c, array $img, bool $repeatHeader = false): string
{
    $e = 'nhcEsc';
    $issued = $c['issued_at'] ?? null ?: ($c['created_at'] ?? null) ?: date('Y-m-d');
    $month = strtoupper(date('F', strtotime($issued)));
    $year = date('Y', strtotime($issued));
    $amount = nhcMoney($c['contract_amount']);
    $dpPct = (int) $c['dp_percent'];
    $delPct = (int) $c['delivery_percent'];
    $insPct = (int) $c['install_percent'];
    $retPct = (int) $c['retention_percent'];
    $retWords = nhcPercentWords($retPct);
    $validity = (int) ($c['validity_days'] ?? 30);
    $dp = nhcMoney(nhcDpAmount($c));
    $paid = !empty($c['dp_paid']);
    $completion = nhcDateLong($c['completion_date'] ?? null);
    $start = nhcDateLong($c['start_date'] ?? null);
    $head = nhcHeaderHtml($img);

    $h = '<div class="nhc-doc">';
    $h .= $repeatHeader ? '' : $head; // PDF: naka-fixed ang header sa bawat page (nhcPdfHtml)
    $h .= '<div class="nhc-title">CONTRACT AGREEMENT</div>';

    $h .= '<p><b>THIS AGREEMENT</b> is made and entered into this month of <span class="nhc-fill">' . $e($month) . '</span> year <span class="nhc-fill">' . $e($year) . '</span> by and between '
        . '<span class="nhc-fill">' . $e(strtoupper((string) $c['owner_name'])) . '</span> (here in after called "Owner"), and <span class="nhc-fill">NOBLEHOME CONSTRUCTION CORPORATION</span>, '
        . '(hereinafter called "Contractor"), for the Construction Project known as: <span class="nhc-fill">' . $e(strtoupper((string) $c['project_name'])) . '</span>. The Owner and Contractor agree as follows:</p>';

    $h .= '<div class="nhc-art">Article 1 The Work:</div>';
    $h .= '<p>The Contractor shall complete all the work on <span class="nhc-fill">' . $e($completion) . '</span> as specified in the <i>Scope of Work</i> included and also contained in the quotation attached hereto and incorporated herein.</p>';

    $h .= '<div class="nhc-art">Article 2 Time of Commencement and Completion:</div>';
    $h .= '<p class="nhc-ind">2.1 The Work to be performed under this Contract shall be commenced upon receipt of a Notice to Proceed and completed by <span class="nhc-fill">' . $e($completion) . '</span>. Start date is anticipated to be on <span class="nhc-fill">' . $e($start) . '</span>.</p>';
    $h .= '<p class="nhc-ind">2.2 All work at site shall be performed on appropriate time and available schedule of the owner. Any suspension of work shall be authorized in writing by both the Owner and the Contractor. The Contractor shall be entitled to a commensurate extension of the Scheduled Completion Date. Any un-authorized suspension by the Contractor shall constitute a breach of contract, and the Owner shall be entitled to liquidated damages under Article 5.3 for each day of such unauthorized suspension.</p>';

    $h .= '<div class="nhc-art">Article 3 Contract Amount and Basis:</div>';
    $h .= '<p>The Owner shall pay the Contractor the amount of <span class="nhc-fill">Php ' . $e($amount) . '</span> for the complete, satisfactory, and turnkey performance of all Work described in the Scope of Work, Drawings, and Specifications attached to this Contract. No change to the Contract Price or the Scope of Work shall be effective unless authorized by a written Change Order signed by both the Owner and the Contractor. The Contract Price shall not be increased or decreased except by a valid Change Order.</p>';
    $h .= '<p>A Change Order may be issued only for: (a) additions or deletions of work that are not already included in the Scope of Work or Drawings attached to this Contract; (b) changes in materials or specifications requested in writing by the Owner. No Change Order shall be binding on the Owner unless it has been reviewed and approved in writing by the Owner prior to the commencement of any changed work. The Owner reserves the right to reject any Change Order, in whole or in part, for any reason. The Contractor shall be entitled to a reasonable extension of the Scheduled Completion Date for any Change Order that adds significant work. Such extension shall be specified in the Change Order and shall be mutually agreed in writing.</p>';

    $h .= '<div class="nhc-art">Article 4 Progress Payments:</div>';
    $h .= '<p>Based upon Applications for Payment submitted to the Owner by the Contractor and Certificates for Payment issued by the Contractor to the Owner, the Owner shall make progress payments to the Contractor as follows:</p>';
    $h .= '<p>' . $e($retWords) . ' percent (' . $retPct . '%) of each amount certified for payment shall be retained by the Owner until final payment.</p>';
    $h .= '<ol class="nhc-list">'
        . '<li>' . $dpPct . '% Down payment is required to start production of the order.</li>'
        . '<li>' . $delPct . '% Prior to delivery and installation</li>'
        . '<li>' . $insPct . '% for installation procedure</li>'
        . '<li>' . $retPct . '% Retention.</li>'
        . '<li>Cheque or deposit or bank transfer are to be payable only to <span class="nhc-fill">Noblehome Construction Corp.</span></li>'
        . '<li>Prices are valid ' . $validity . ' days from date of quotation.</li>'
        . '</ol>';

    $h .= '<div class="nhc-art">Article 5 Delay</div>';
    $h .= '<p class="nhc-ind">5.1 All of the Work will be completed and ready for final payment by the date specified in this Agreement. Failure of the party to perform its obligations within the time frame stipulated in the contract, such delay may constitute a breach of contract, unless legally excused.</p>';
    $h .= '<p class="nhc-ind">5.2 Excusable Delays are those arising from events beyond the control of the obligated party, such as acts of God, force majeure, or government-imposed restrictions. These delays may entitle the contractor to a time extension, provided that timely written notice and sufficient documentation are submitted in accordance with the terms of the contract.</p>';
    $h .= '<p class="nhc-ind">5.3 In the event that the Contractor fails to complete the Work within the agreed timeline for reasons other than Excusable Delays, the Owner shall be entitled to liquidated damages. These damages shall be calculated at a rate of one-tenth of one percent (0.1%) of the total contract price for each calendar day of delay until the Work is satisfactorily completed and accepted. The Owner may deduct such liquidated damages from any unpaid progress payments or the final retention amount due to the Contractor. Conversely, if the delay is caused by the Owner\'s failure to provide site access or necessary approvals, the Contractor shall be granted a commensurate extension of time.</p>';
    $h .= '<p class="nhc-ind">5.4 Non-Excusable Delays result from the fault or negligence of the contractor or client, such as inadequate project management, labor shortages, or failure to secure necessary permits. These may subject the responsible party to liquidated damages, penalties, or other remedies.</p>';

    $h .= '<div class="nhc-art">Article 6 Payment:</div>';
    $h .= '<p class="nhc-ind">6.1 Payments shall be made as provided in Article 4 of this Contract.</p>';
    $h .= '<p class="nhc-ind">6.2 Final payment shall not be due until (1) the Contractor has delivered to the Owner a progressive report, a clean irrevocable letter of credit, cash or other security satisfactory to the Owner indemnifying Owner against any claim which has been asserted by anyone for labor, materials, equipment or otherwise arising out of the contract or on account of any claim which either Owner or Contractor believes may be asserted, (2) the Owner has inspected and approved the Work as complying with the contract, (3) written consent of surety, if any is given, (4) the Owner and Contractor have complied with all requirements for Final Settlement imposed by applicable law.</p>';
    $h .= '<p class="nhc-ind">6.3 In case of default payment, <b><i>NOBLEHOME CONSTRUCTION CORPORATION</i></b> reserves the right to pursue legal options available, to recover full payment, including but not limited to charges for damages (if any), in case <b><i>NOBLEHOME CONSTRUCTION CORPORATION</i></b> opts to pullout said product covered by this contract.</p>';
    $h .= '<p class="nhc-ind">6.4 In the event that either party defaults in the performance of any of its obligations under this Contract and such default is not cured within the applicable notice and cure period provided in this Contract, the non-defaulting party shall be entitled to recover from the defaulting party reasonable attorneys\' fees and out-of-pocket costs of collection or enforcement incurred in connection with such default.</p>';
    $h .= '<p class="nhc-ind">6.5 Note that, items specified in this contract shall remain the property of <b><i>NOBLEHOME CONSTRUCTION CORP.</i></b> until the company or in behalf of its duly authorized representative had received full payment for the items specified in this contract. Check payments are subject to clearing by the depository bank to effect full payment of the items purchased.</p>';
    $h .= '<p class="nhc-ind">6.6 After completion of the Work, provided the Contract be then fully performed, subject to the provisions of Article 16 herein, the Owner shall publish a Notice of Final Settlement twice at least 30 work days prior to the date of Final Settlement. The Owner shall withhold from final payments any amounts as required.</p>';
    $h .= '<p class="nhc-ind">6.7 Final payment, comprising the remaining balance of the Contract Amount and the ' . $e(strtolower($retWords)) . ' percent (' . $retPct . '%) retention, shall be released by the Owner within Thirty (30) days after the Contractor has achieved final completion of the Work, corrected all punch-list items, and submitted a final VAT invoice. The Contractor shall, as a condition precedent to final payment, provide the Owner with a release of liens or an affidavit certifying that all labor, materials, and subcontractors involved in the project have been fully paid. All payments shall be made via cheque, deposit, or bank transfer payable only to <b>Noblehome Construction Corp.</b> as specified in Article 4.</p>';
    $h .= '<p class="nhc-ind">6.8 DP: Php ' . $e($dp) . ' (Represents ' . $dpPct . '% Down Payment of the total contract price to initiate production and mobilization).' . ($paid ? ' The said amount has been paid.' : '') . '</p>';

    $h .= '<div class="nhc-art">Article 7 Changes in the Work:</div>';
    $h .= '<p class="nhc-ind">7.1 The Owner without invalidating the Contract may order Changes in the Work consisting of additions, deletions, or modifications with the Contract Sum and the Contract Time being adjusted accordingly.</p>';
    $h .= '<p class="nhc-ind">7.2 All such changes in the Work shall be authorized by written Change Order signed by the Owner.</p>';
    $h .= '<p class="nhc-ind">7.3 The Contract Sum and the Contract Time may be changed only by Change Order.</p>';
    $h .= '<p class="nhc-ind">7.4 The cost or credit to the Owner, if any, from a Change in the Work shall be determined by unit prices if specified in the contract documents, or by mutual agreement.</p>';

    $h .= '<div class="nhc-art">Article 8 Termination of Contract</div>';
    $h .= '<div class="nhc-sub">BY THE CONTRACTOR</div>';
    $h .= '<p>8.1 If the Owner fails to pay any certified progress billing within thirty (30) days from receipt, through no fault of the Contractor, the Contractor shall give fourteen (14) days\' written notice to pay. The Owner shall have the right to cure such default within said period.</p>';
    $h .= '<p>If the Owner fails to cure, the Contractor may suspend the Works after giving a further seven (7) days\' notice, and may terminate the Contract upon continued non-payment.</p>';
    $h .= '<p>In case of termination due to the Owner\'s default, the Contractor shall be entitled only to payment for <b>properly completed and certified work, less retention and any applicable deductions under the Contract.</b> Costs not yet incorporated into the Works shall be subject to reasonable verification and approval by the Owner.</p>';
    $h .= '<p>Payments previously made shall be <b>credited against the total amount due. Any excess shall be refunded, and any deficiency shall remain payable. No automatic forfeiture shall apply,</b> and all financial adjustments shall be proportionate to the actual progress of the Works, as certified by the Project Architect/Engineer or, in case of dispute, determined in accordance with the dispute resolution provisions of this Contract.</p>';
    $h .= '<div class="nhc-sub">BY THE OWNER</div>';
    $h .= '<p>8.2 If the Contractor defaults or neglects to carry out the Work in accordance with the Contract Documents or fails to perform any provision of the Contract, the Owner may, after fourteen days\' written notice to the Contractor and without prejudice to any other remedy Owner may have, make good such deficiencies and may deduct the cost thereof from the payment then or thereafter due the Contractor or, at Owner\'s option, may terminate Contractor\'s work under the Contract and take possession of the site and of all materials, equipment, tools, and construction equipment and machinery thereon owned by the Contractor and may finish the Work by whatever method Owner may deem expedient, and if the unpaid balance of the Contract Sum exceeds the expense of finishing the Work, such excess shall not be paid to the Contractor. If the Owner terminates the Contract and completes the remaining work, any excess cost over the unpaid balance shall not be due or payable to the Contractor, but if such expense exceeds such unpaid balance, the Contractor shall pay the difference to the Owner. These rights and remedies are in addition to any right to damages or other rights and remedies allowed by law.</p>';

    $h .= '<div class="nhc-art">Article 9 Installation of Appliances/Accessories</div>';
    $h .= '<ol class="nhc-list">'
        . '<li>Installations are only included for the above-mentioned items stated and purchased from <i>NOBLEHOME CONSTRUCTION CORP.</i></li>'
        . '<li>Any other appliances installations may be allowed with prior approval from <i>NOBLEHOME CONSTRUCTION CORP.</i></li>'
        . '<li>It is expressly acknowledged by the customer that request for installation of other appliances that are not purchased and supplied by NOBLEHOME CONSTRUCTION CORP. may incur additional labor charges and administrative fees as determined by the company. The customer further agrees that NOBLEHOME CONSTRUCTION CORP. shall not be held liable for any damages, malfunctions, or warranty voidance that may result from the installation or integration of these third-party appliances into the existing infrastructure. Any such installation services provided by the company are performed at the customer\'s sole risk, and the customer assumes all responsibility for the quality, safety, and operational integrity of the products being installed. The Contractor shall be fully liable for any direct physical damage to the Owner\'s property. The Owner-Supplied Items, or the existing works caused solely by the Contractor\'s negligence, faulty workmanship, or failure to follow manufacturer\'s instructions during the installation process.</li>'
        . '<li>This limited warranty for Modular Cabinets covers factory defects in material and workmanship, and damage caused by wrong/unqualified installation and expressly excludes damage caused by abuse, misuse, lies not in conformity with recommended capacities and force majeure. During the Warranty Period, the Contractor shall repair or replace any defective Work within 7 days without any fees.</li>'
        . '<li>1 Year Warranty for Cabinet and Accessories Only. During the Warranty Period, the Contractor shall, at its sole cost and expense, repair or replace any defective portion of the work following within 7 work days:'
        . '<div style="margin-left:14pt">(a) fails to conform to the specifications and drawings attached to this Contract;<br>(b) exhibits defects in materials, factory workmanship, or installation.</div></li>'
        . '<li>The Contractor acknowledges that the Project site contains existing furniture, fixtures, and equipment owned by the Owner (collectively, the "Owner\'s Property"), which are not part of the Work to be performed under this Contract. The Contractor shall take all necessary and reasonable precautions to protect the Owner\'s Property from damage, dust, debris, paint, moisture, and any other harm that may arise from the construction activities. In the event that the Owner\'s Property is damaged due to the Contractor\'s failure to comply with its obligations under this Article, the Contractor shall pay to the Owner liquidated damages in the amount of twenty-five percent (25%) of the actual replacement or repair value of the damaged item.</li>'
        . '</ol>';

    // ── Attachments + pirmahan ──
    $h .= '<div style="page-break-inside: avoid">';
    $h .= '<div class="nhc-art">Attachments:</div>';
    $h .= '<ol class="nhc-list"><li>Quotation: Comprehensive breakdown of materials, labor, and unit costs.</li><li>Workscope</li><li>2d Lay-out / Design with Specifications.</li></ol>';

    $h .= '<div class="nhc-art" style="text-align:center;margin-top:14pt">Client Sales Contact</div>';
    $clientSig = ($img['client'] ?? '') !== '' ? '<img src="' . $img['client'] . '" alt="client signature" style="max-height:52pt;max-width:200pt">' : '<span class="nhc-pending">Waiting for client signature</span>';
    $h .= '<table style="width:100%;border-collapse:collapse;margin:6pt 0 8pt"><tr>'
        . '<td style="width:62%;vertical-align:bottom;padding-right:14pt"><div style="font-size:10pt">CLIENT NAME AND SIGNATURE:</div><div class="nhc-sigbox">' . $clientSig . '</div>'
        . '<div class="nhc-signame">' . $e($c['client_signed_name'] ?? '') . '&nbsp;</div></td>'
        . '<td style="vertical-align:bottom"><div style="font-size:10pt">DATE:</div><div class="nhc-sigbox"></div><div class="nhc-signame">' . $e(!empty($c['client_signed_at']) ? nhcDateLong($c['client_signed_at']) : '') . '&nbsp;</div></td>'
        . '</tr></table>';

    $h .= '<table class="nhc-info" style="border-collapse:collapse">'
        . '<tr><td class="k">ADDRESS:</td><td>' . $e(strtoupper((string) ($c['address'] ?? ''))) . '</td></tr>'
        . '<tr><td class="k">CONTACT NO:</td><td>' . $e($c['contact_number'] ?? '') . '</td></tr>'
        . '<tr><td class="k">DOWNPAYMENT:</td><td>PHP ' . $e($dp) . ($paid ? ' <i>(PAID)</i>' : '') . '</td></tr>'
        . '<tr><td class="k">TOTAL CONTRACT AMOUNT:</td><td>PHP ' . $e($amount) . '</td></tr>'
        . '<tr><td class="k">BALANCE:</td><td>PHP ' . $e(nhcMoney(nhcBalance($c))) . '</td></tr>'
        . '</table>';

    $h .= '<div class="nhc-art" style="margin-top:14pt">Signed by:</div>';
    $h .= '<table class="nhc-sign"><tr>'
        . '<td>' . nhcSignCell($img['sales'] ?? '', $c['sales_name'] ?? null, 'Sales Coordinator', $c['sales_signed_at'] ?? null, 'Waiting for Sales') . '</td>'
        . '<td>' . nhcSignCell($img['designer'] ?? '', $c['designer_name'] ?? null, 'Designer', $c['designer_signed_at'] ?? null, 'Waiting for Designer') . '</td>'
        . '</tr><tr>'
        . '<td>' . nhcSignCell($img['acct'] ?? '', $c['acct_name'] ?? null, 'Accounting Head', $c['acct_signed_at'] ?? null, 'Waiting for Accounting Head') . '</td>'
        . '<td>' . nhcSignCell($img['gm'] ?? '', $c['gm_name'] ?? null, 'General Manager', $c['gm_signed_at'] ?? null, 'Waiting for General Manager') . '</td>'
        . '</tr></table>';
    $h .= '</div>';

    $h .= '</div>';
    return $h;
}
